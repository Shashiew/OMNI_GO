/* Versioned local-first persistence and IndexedDB attachment helpers. */
(function (global) {
  'use strict';
  const KEY = 'omni-go-data-v1';
  const DB_NAME = 'omni-go-attachments-v1';
  const STORE = 'attachments';
  function load() {
    const raw = global.localStorage.getItem(KEY);
    if (raw == null) return { state: global.OMNIModel.defaultState(), fresh: true };
    let parsed;
    try { parsed = JSON.parse(raw); }
    catch (err) { const e = new Error('Saved workspace data could not be read. Your original data has not been overwritten. Export the raw recovery copy from Settings before resetting the workspace.'); e.name = 'CorruptWorkspaceError'; e.raw = raw; throw e; }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      const e = new Error('Saved workspace has an unexpected format. Original data has not been overwritten.'); e.name = 'CorruptWorkspaceError'; e.raw = raw; throw e;
    }
    return { state: global.OMNIModel.normalizeState(parsed), fresh: false };
  }
  let lastServerSave = Promise.resolve();
  function save(state) {
    // Isolated interaction harness fallback; production uses the local JSON file written by server.py.
    if (global.__OMNI_TEST_MODE) { global.localStorage.setItem(KEY, JSON.stringify(state)); return true; }
    const snapshot = JSON.stringify(state);
    lastServerSave = lastServerSave.catch(() => {}).then(() => fetch('/api/state', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: snapshot }))
      .then(async response => { if (!response.ok) throw new Error(`Local file save failed (HTTP ${response.status}). Keep the server window open and check folder permissions.`); return response.json(); })
      .then(result => { try { global.localStorage.removeItem(KEY); } catch (_) {} return result; });
    lastServerSave.catch(err => { console.error('OMNI-GO file persistence:', err); global.dispatchEvent(new CustomEvent('omni-storage-error', { detail: err.message || 'Local file save failed.' })); });
    return true;
  }
  async function loadServer() {
    if (global.__OMNI_TEST_MODE) return { exists: false, state: null };
    const response = await fetch('/api/state', { cache: 'no-store' });
    if (!response.ok) throw new Error('Could not read the local workspace file.');
    return response.json();
  }
  function flush() { return lastServerSave; }
  function validateImport(parsed) {
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('The selected file is not a workspace object.');
    if (!Number.isInteger(Number(parsed.schemaVersion)) || Number(parsed.schemaVersion) < 1) throw new Error('The backup is missing a supported schemaVersion.');
    const required = ['subjects','timetable','tasks','reminders','notes','habits','exams','syllabus','coursesOnline','library','anime','movies','games','workoutLogs','sportsLogs','expenses'];
    const missing = required.filter(k => !Array.isArray(parsed[k]));
    if (missing.length) throw new Error(`The backup is missing expected collections: ${missing.join(', ')}.`);
    return global.OMNIModel.normalizeState(parsed);
  }
  function exportData(state) {
    return JSON.stringify({ ...state, schemaVersion: 1, exportMetadata: { exportedAt: new Date().toISOString(), app: 'OMNI-GO', attachmentsIncluded: false } }, null, 2);
  }
  function openDb() {
    return new Promise((resolve, reject) => {
      if (!global.indexedDB) return reject(new Error('This browser does not support IndexedDB attachments.'));
      const req = global.indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => { const db = req.result; if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: 'id' }); };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error('Could not open attachment storage.'));
    });
  }
  async function putAttachment(record) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(record);
      tx.oncomplete = () => { db.close(); resolve(record.id); };
      tx.onerror = () => { const err = tx.error; db.close(); reject(err || new Error('Attachment save failed.')); };
      tx.onabort = () => { const err = tx.error; db.close(); reject(err || new Error('Attachment save was cancelled.')); };
    });
  }
  async function getAttachment(id) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readonly'); const req = tx.objectStore(STORE).get(id);
      req.onsuccess = () => { db.close(); resolve(req.result || null); };
      req.onerror = () => { const err = req.error; db.close(); reject(err || new Error('Attachment could not be read.')); };
    });
  }
  async function deleteAttachment(id) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite'); tx.objectStore(STORE).delete(id);
      tx.oncomplete = () => { db.close(); resolve(); };
      tx.onerror = () => { const err = tx.error; db.close(); reject(err || new Error('Attachment could not be deleted.')); };
    });
  }
  global.OMNIStorage = { KEY, load, save, loadServer, flush, validateImport, exportData, putAttachment, getAttachment, deleteAttachment };
})(window);
