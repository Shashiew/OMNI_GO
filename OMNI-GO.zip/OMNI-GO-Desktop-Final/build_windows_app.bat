@echo off
setlocal EnableExtensions
set "PROJECT_DIR=%~dp0"
cd /d "%PROJECT_DIR%"
title Build and Install OMNI-GO

echo ==========================================================
echo  OMNI-GO Desktop Builder
echo  One build: desktop app + Windows system-media support
echo  Installs app and creates Desktop/Start Menu shortcuts
 echo ==========================================================
echo.

for %%F in (index.html style.css app.js storage.js data-model.js server.py desktop_app.py Install-OMNI-GO.bat package_tester.py) do (
  if not exist "%PROJECT_DIR%%%F" (
    echo ERROR: Required project file is missing: %%F
    echo Extract the entire ZIP before running this builder.
    goto :error
  )
)
if not exist "%PROJECT_DIR%assets\omni-go.ico" (
  echo ERROR: Required app icon is missing: assets\omni-go.ico
  goto :error
)

where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python 3.10 or newer was not found.
    echo Install Python from https://www.python.org/downloads/windows/
    echo Enable Add Python to PATH during setup.
    goto :error
  )
  set "PY=python"
)

if exist ".build-temp" rmdir /s /q ".build-temp"
if exist "build" rmdir /s /q "build"
if exist "dist\OMNI-GO" rmdir /s /q "dist\OMNI-GO"
mkdir ".build-temp" 2>nul
%PY% -m venv ".build-temp\venv"
if errorlevel 1 goto :error
call ".build-temp\venv\Scripts\activate.bat"
python -m pip install --upgrade pip
if errorlevel 1 goto :error

echo Installing ALL desktop dependencies, including Windows system-media controls...
echo This is automatic and is part of OMNI-GO; there is no optional-media choice.
python -m pip install "pywebview[winforms]>=6,<7" "pyinstaller>=6,<7" "pystray>=0.19.5,<0.20" "Pillow>=10,<13" winsdk
if errorlevel 1 goto :error

echo.
echo Building OMNI-GO.exe. This may take several minutes...
python -m PyInstaller --noconfirm --clean --windowed --onedir --name OMNI-GO ^
  --contents-directory _internal ^
  --distpath "%PROJECT_DIR%dist" ^
  --workpath "%PROJECT_DIR%.build-temp\work" ^
  --specpath "%PROJECT_DIR%.build-temp" ^
  --collect-all webview ^
  --collect-all pythonnet ^
  --collect-all clr_loader ^
  --collect-all pystray ^
  --collect-all PIL ^
  --collect-all winsdk ^
  --hidden-import winsdk.windows.media.control ^
  --hidden-import winsound ^
  --hidden-import clr ^
  --icon "%PROJECT_DIR%assets\omni-go.ico" ^
  --add-data "%PROJECT_DIR%index.html;." ^
  --add-data "%PROJECT_DIR%style.css;." ^
  --add-data "%PROJECT_DIR%app.js;." ^
  --add-data "%PROJECT_DIR%storage.js;." ^
  --add-data "%PROJECT_DIR%data-model.js;." ^
  --add-data "%PROJECT_DIR%README.md;." ^
  --add-data "%PROJECT_DIR%assets;assets" ^
  "%PROJECT_DIR%desktop_app.py"
if errorlevel 1 goto :error
if not exist "%PROJECT_DIR%dist\OMNI-GO\OMNI-GO.exe" (
  echo ERROR: PyInstaller did not create dist\OMNI-GO\OMNI-GO.exe.
  goto :error
)
if not exist "%PROJECT_DIR%dist\OMNI-GO\_internal" (
  echo ERROR: PyInstaller did not create the _internal runtime folder.
  goto :error
)

if exist ".build-temp" rmdir /s /q ".build-temp"
if exist "build" rmdir /s /q "build"

rem Install a per-user copy so shortcuts stay valid even if the source ZIP is moved.
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\OMNI-GO"
if not exist "%LOCALAPPDATA%\Programs" mkdir "%LOCALAPPDATA%\Programs" 2>nul
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%" 2>nul
robocopy "%PROJECT_DIR%dist\OMNI-GO" "%INSTALL_DIR%" /MIR /R:2 /W:1 /NFL /NDL /NJH /NJS /NC /NS /NP
set "ROBOCOPY_EXIT=%ERRORLEVEL%"
if %ROBOCOPY_EXIT% GEQ 8 (
  echo ERROR: Build succeeded, but app installation copy failed.
  echo Close any running OMNI-GO instance and run the builder again.
  goto :error
)
set "OMNIGO_INSTALL_DIR=%INSTALL_DIR%"
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; $d=$env:OMNIGO_INSTALL_DIR; $e=Join-Path $d 'OMNI-GO.exe'; if(-not (Test-Path -LiteralPath $e -PathType Leaf)){throw 'OMNI-GO.exe not found'}; $desktop=[Environment]::GetFolderPath('Desktop'); if([string]::IsNullOrWhiteSpace($desktop)){$desktop=Join-Path $env:USERPROFILE 'Desktop'}; $startMenu=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\OMNI-GO'; New-Item -ItemType Directory -Force -Path $desktop,$startMenu | Out-Null; $shell=New-Object -ComObject WScript.Shell; foreach($p in @((Join-Path $desktop 'OMNI-GO.lnk'),(Join-Path $startMenu 'OMNI-GO.lnk'))){$s=$shell.CreateShortcut($p);$s.TargetPath=$e;$s.WorkingDirectory=$d;$s.IconLocation=$e+',0';$s.Description='OMNI-GO Personal Command Center';$s.Save()}"
if errorlevel 1 (
  echo ERROR: App was copied, but shortcut creation failed.
  goto :error
)

rem Create a self-contained shareable package for a new tester. It contains no personal data.
set "RELEASE_DIR=%PROJECT_DIR%release\OMNI-GO-Tester-Package"
if exist "%RELEASE_DIR%" rmdir /s /q "%RELEASE_DIR%"
if not exist "%PROJECT_DIR%release" mkdir "%PROJECT_DIR%release" 2>nul
mkdir "%RELEASE_DIR%\OMNI-GO" 2>nul
robocopy "%PROJECT_DIR%dist\OMNI-GO" "%RELEASE_DIR%\OMNI-GO" /MIR /R:2 /W:1 /NFL /NDL /NJH /NJS /NC /NS /NP
set "ROBOCOPY_EXIT=%ERRORLEVEL%"
if %ROBOCOPY_EXIT% GEQ 8 (
  echo WARNING: App built and installed, but the tester package could not be staged.
  goto :installed_only
)
copy /Y "%PROJECT_DIR%Install-OMNI-GO.bat" "%RELEASE_DIR%Install-OMNI-GO.bat" >nul
(
echo # OMNI-GO
echo.
echo OMNI-GO is a personal command center for tasks, study, attendance, reminders, notes, workouts, media and everyday tracking.
echo.
echo ## Install
echo 1. Extract the entire ZIP to a folder.
echo 2. Double-click Install-OMNI-GO.bat.
echo 3. The installer creates Desktop and Start Menu shortcuts automatically.
echo.
echo Windows system-media controls are included. No Python installation is needed for testers.
echo Personal data is stored in %%LOCALAPPDATA%%\OMNI-GO\data on this PC.
echo Keep the OMNI-GO folder and _internal folder together.
echo Reminders continue while the app is open or minimized to the system tray, but not after fully exiting.
) > "%RELEASE_DIR%\README.md"
%PY% "%PROJECT_DIR%package_tester.py" "%RELEASE_DIR%" "%PROJECT_DIR%OMNI-GO-Tester-App.zip"
if errorlevel 1 (
  echo WARNING: App built and installed, but could not create OMNI-GO-Tester-App.zip.
) else (
  echo Created shareable new-user package: %PROJECT_DIR%OMNI-GO-Tester-App.zip
)

:installed_only
echo.
echo Build and install complete!
echo Installed app: %INSTALL_DIR%\OMNI-GO.exe
echo Desktop shortcut: OMNI-GO.lnk
echo Start Menu shortcut: Programs\OMNI-GO\OMNI-GO.lnk
echo Share this file with a new tester: %PROJECT_DIR%OMNI-GO-Tester-App.zip
echo Workspace data is stored separately in %%LOCALAPPDATA%%\OMNI-GO\data.
echo Windows system-media controls are included automatically.
echo.
choice /C YN /N /M "Launch OMNI-GO now? (Y/N): "
if errorlevel 2 goto :done
start "" "%INSTALL_DIR%\OMNI-GO.exe"
:done
pause
exit /b 0

:error
echo.
echo Build/install failed. Read the first ERROR line above.
echo Windows system-media support remains a required build dependency.
echo The source project and your personal data were not intentionally deleted.
if exist ".build-temp\venv\Scripts\deactivate.bat" call ".build-temp\venv\Scripts\deactivate.bat"
pause
exit /b 1
