"""Create the OMNI-GO tester ZIP from a staged release folder using Python's stdlib."""
from pathlib import Path
import sys
import zipfile

def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: package_tester.py <release-folder> <output-zip>", file=sys.stderr)
        return 2
    root = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    if not root.is_dir():
        print(f"Release folder does not exist: {root}", file=sys.stderr)
        return 2
    files = sorted(p for p in root.rglob("*") if p.is_file() and not p.is_symlink())
    if not files:
        print("Release folder contains no files.", file=sys.stderr)
        return 2
    output.parent.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=8) as archive:
            for path in files:
                archive.write(path, path.relative_to(root).as_posix())
        with zipfile.ZipFile(output, "r") as archive:
            bad = archive.testzip()
            if bad:
                raise zipfile.BadZipFile(f"Failed CRC check: {bad}")
    except (OSError, zipfile.BadZipFile) as exc:
        try:
            output.unlink(missing_ok=True)
        except OSError:
            pass
        print(f"Could not create tester package: {exc}", file=sys.stderr)
        return 1
    print(f"Created {output} ({len(files)} files).")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
