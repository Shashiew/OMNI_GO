@echo off
setlocal EnableExtensions
set "PACKAGE_DIR=%~dp0"
set "SOURCE_DIR=%PACKAGE_DIR%OMNI-GO"
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\OMNI-GO"
title Install OMNI-GO

echo ==========================================================
echo  Install OMNI-GO
echo  Creates Desktop and Start Menu shortcuts automatically.
echo ==========================================================
echo.
if not exist "%SOURCE_DIR%\OMNI-GO.exe" (
  echo ERROR: The OMNI-GO application files were not found.
  echo Extract the entire ZIP, then run Install-OMNI-GO.bat again.
  goto :error
)
if not exist "%SOURCE_DIR%\_internal" (
  echo ERROR: The application runtime folder is missing.
  echo Extract the entire ZIP again. Do not move files out of the OMNI-GO folder.
  goto :error
)
if not exist "%LOCALAPPDATA%\Programs" mkdir "%LOCALAPPDATA%\Programs" 2>nul
if not exist "%LOCALAPPDATA%\Programs" (
  echo ERROR: Could not create the per-user application folder.
  goto :error
)
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%" 2>nul
robocopy "%SOURCE_DIR%" "%INSTALL_DIR%" /MIR /R:2 /W:1 /NFL /NDL /NJH /NJS /NC /NS /NP
set "ROBOCOPY_EXIT=%ERRORLEVEL%"
if %ROBOCOPY_EXIT% GEQ 8 (
  echo ERROR: Could not copy application files. Close any running OMNI-GO window and retry.
  goto :error
)
set "OMNIGO_INSTALL_DIR=%INSTALL_DIR%"
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; $d=$env:OMNIGO_INSTALL_DIR; $e=Join-Path $d 'OMNI-GO.exe'; if(-not (Test-Path -LiteralPath $e -PathType Leaf)){throw 'OMNI-GO.exe not found'}; $desktop=[Environment]::GetFolderPath('Desktop'); if([string]::IsNullOrWhiteSpace($desktop)){$desktop=Join-Path $env:USERPROFILE 'Desktop'}; $startMenu=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\OMNI-GO'; New-Item -ItemType Directory -Force -Path $desktop,$startMenu | Out-Null; $shell=New-Object -ComObject WScript.Shell; foreach($p in @((Join-Path $desktop 'OMNI-GO.lnk'),(Join-Path $startMenu 'OMNI-GO.lnk'))){$s=$shell.CreateShortcut($p);$s.TargetPath=$e;$s.WorkingDirectory=$d;$s.IconLocation=$e+',0';$s.Description='OMNI-GO Personal Command Center';$s.Save()}"
if errorlevel 1 (
  echo ERROR: The app copied, but Windows could not create its shortcuts.
  goto :error
)
echo.
echo OMNI-GO is installed for this Windows user.
echo App folder: %INSTALL_DIR%
echo Shortcuts: Desktop and Start Menu ^> OMNI-GO
echo Your personal data is stored separately in %%LOCALAPPDATA%%\OMNI-GO\data.
echo System-media support is included; no optional-media prompt is shown.
echo.
choice /C YN /N /M "Launch OMNI-GO now? (Y/N): "
if errorlevel 2 goto :done
start "" "%INSTALL_DIR%\OMNI-GO.exe"
:done
pause
exit /b 0
:error
echo.
echo Installation failed. Your package files were not deleted.
pause
exit /b 1
