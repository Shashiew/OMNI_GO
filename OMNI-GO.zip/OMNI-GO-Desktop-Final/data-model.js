/* OMNI-GO data model. Pure helpers only; no DOM or storage side effects. */
(function (global) {
  'use strict';
  const COLLECTIONS = [
    'subjects','timetable','courses','attendanceLog','dailyAttendance','workoutCheckins','tasks','reminders','notes','quickNoteCards',
    'habits','exams','syllabus','coursesOnline','library','anime','movies','games','gymPlan',
    'gymDayMuscles','workoutLogs','sportsLogs','expenses','customTools','progressHistory','activityHistory'
  ];
  const ARRAY_COLLECTIONS = [
    'subjects','timetable','tasks','reminders','notes','quickNoteCards','habits','exams','syllabus',
    'coursesOnline','library','anime','movies','games','workoutLogs','sportsLogs','expenses','customTools'
  ];
  function defaultState() {
    return {
      schemaVersion: 1,
      profile: { name: '', city: '', birthday: '', email: '', phone: '', avatar: '', focus: 25, shortBreak: 5, longBreak: 15 },
      subjects: [], timetable: [], courses: [], attendanceLog: {}, dailyAttendance: {}, attendanceManual: {}, attendanceCalculation: 'weighted',
      tasks: [], reminders: [], notes: [], quickNoteCards: [], habits: [], exams: [], syllabus: [], coursesOnline: [],
      library: [], anime: [], movies: [], games: [], gymPlan: {}, gymDayMuscles: {}, workoutCheckins: {}, workoutLogs: [], sportsLogs: [],
      expenses: [], customTools: [], progressHistory: { tasks: {}, studyMinutes: {}, habits: {}, attendance: {}, workouts: {} },
      activityHistory: [], discovery: { animeUrl: '', movieUrl: '', seriesUrl: '', animeLabel: 'Anime discovery', movieLabel: 'Movie discovery', seriesLabel: 'Series discovery' },
      settings: { ambient: true, reminders: true, compact: false, clockFormat: 'locale', reducedMotion: 'system' }
    };
  }
  function id(prefix) {
    const random = global.crypto && typeof global.crypto.randomUUID === 'function'
      ? global.crypto.randomUUID().replace(/-/g, '').slice(0, 12)
      : Math.random().toString(36).slice(2, 14) + Date.now().toString(36);
    return `${prefix || 'item'}_${random}`;
  }
  function localDateKey(date) {
    const d = date instanceof Date ? date : new Date(date || Date.now());
    if (Number.isNaN(d.getTime())) return '';
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  }
  function normalizeSubjects(items) {
    const out = [], seen = new Set();
    for (const raw of Array.isArray(items) ? items : []) {
      const name = String(raw && raw.name || '').trim();
      const key = name.toLocaleLowerCase();
      if (!name || seen.has(key)) continue;
      seen.add(key);
      out.push({ id: String(raw.id || id('sub')), name, createdAt: raw.createdAt || new Date().toISOString(), updatedAt: raw.updatedAt || new Date().toISOString() });
    }
    return out;
  }
  function normalizeState(incoming) {
    const base = defaultState();
    if (!incoming || typeof incoming !== 'object' || Array.isArray(incoming)) throw new Error('The workspace file must contain a JSON object.');
    const src = incoming;
    const merged = Object.assign(base, src);
    merged.schemaVersion = 1;
    merged.profile = Object.assign(base.profile, src.profile && typeof src.profile === 'object' ? src.profile : {});
    merged.settings = Object.assign(base.settings, src.settings && typeof src.settings === 'object' ? src.settings : {});
    merged.discovery = Object.assign(base.discovery, src.discovery && typeof src.discovery === 'object' ? src.discovery : {});
    for (const key of ARRAY_COLLECTIONS) if (!Array.isArray(src[key])) merged[key] = [];
    merged.subjects = normalizeSubjects(merged.subjects);
    merged.attendanceLog = src.attendanceLog && typeof src.attendanceLog === 'object' && !Array.isArray(src.attendanceLog) ? src.attendanceLog : {};
    merged.dailyAttendance = src.dailyAttendance && typeof src.dailyAttendance === 'object' && !Array.isArray(src.dailyAttendance) ? src.dailyAttendance : {};
    merged.workoutCheckins = src.workoutCheckins && typeof src.workoutCheckins === 'object' && !Array.isArray(src.workoutCheckins) ? src.workoutCheckins : {};
    merged.attendanceManual = src.attendanceManual && typeof src.attendanceManual === 'object' && !Array.isArray(src.attendanceManual) ? src.attendanceManual : {};
    merged.gymPlan = src.gymPlan && typeof src.gymPlan === 'object' ? src.gymPlan : {};
    merged.gymDayMuscles = src.gymDayMuscles && typeof src.gymDayMuscles === 'object' ? src.gymDayMuscles : {};
    merged.progressHistory = Object.assign(base.progressHistory, src.progressHistory && typeof src.progressHistory === 'object' ? src.progressHistory : {});
    for (const key of ['tasks','studyMinutes','habits','attendance','workouts']) {
      if (!merged.progressHistory[key] || typeof merged.progressHistory[key] !== 'object') merged.progressHistory[key] = {};
    }
    merged.activityHistory = Array.isArray(src.activityHistory) ? src.activityHistory : [];
    merged.profile.focus = clampNumber(merged.profile.focus, 1, 180, 25);
    merged.profile.shortBreak = clampNumber(merged.profile.shortBreak, 1, 60, 5);
    merged.profile.longBreak = clampNumber(merged.profile.longBreak, 1, 120, 15);
    return merged;
  }
  function clampNumber(value, min, max, fallback) {
    const n = Number(value);
    return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
  }
  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }
  function safeUrl(value) {
    try { const u = new URL(String(value || '').trim()); return ['http:','https:'].includes(u.protocol) ? u.href : ''; }
    catch (_) { return ''; }
  }
  function attendanceSummary(state, subjectId) {
    const rows = Object.values(state.attendanceLog || {}).filter(r => r && r.subjectId === subjectId && (r.status === 'present' || r.status === 'absent'));
    const present = rows.filter(r => r.status === 'present').length;
    const total = rows.length;
    return { present, absent: total - present, total, percent: total ? present / total * 100 : null };
  }
  function overallAttendance(state) {
    const summaries = state.subjects.map(s => attendanceSummary(state, s.id)).filter(s => s.total > 0);
    if (!summaries.length) return null;
    if (state.attendanceCalculation === 'equal') return summaries.reduce((sum, s) => sum + s.percent, 0) / summaries.length;
    const total = summaries.reduce((sum, s) => sum + s.total, 0);
    return total ? summaries.reduce((sum, s) => sum + s.present, 0) / total * 100 : null;
  }
  function addProgress(state, type, date, delta) {
    if (!state.progressHistory[type]) state.progressHistory[type] = {};
    const key = date || localDateKey();
    state.progressHistory[type][key] = Math.max(0, Number(state.progressHistory[type][key] || 0) + Number(delta || 0));
    if (state.progressHistory[type][key] === 0) delete state.progressHistory[type][key];
  }
  function recordActivity(state, type, label, date) {
    state.activityHistory = Array.isArray(state.activityHistory) ? state.activityHistory : [];
    state.activityHistory.unshift({ id: id('activity'), type, label: String(label || type), date: date || new Date().toISOString(), createdAt: new Date().toISOString() });
    state.activityHistory = state.activityHistory.slice(0, 200);
  }
  global.OMNIModel = { COLLECTIONS, ARRAY_COLLECTIONS, defaultState, id, localDateKey, normalizeSubjects, normalizeState, escapeHtml, safeUrl, attendanceSummary, overallAttendance, addProgress, recordActivity };
})(window);
