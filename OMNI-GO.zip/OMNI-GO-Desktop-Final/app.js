/* OMNI-GO app orchestration. Rendering is state-driven; user content is escaped. */
(function () {
  'use strict';
  const M = window.OMNIModel;
  const S = window.OMNIStorage;
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const esc = M.escapeHtml;
  const WEEKDAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
  const NAV = [
    { section:'WORKSPACE', items:[
      ['today','◷','Today'],['dashboard','⌂','Dashboard'],['tasks','☷','Tasks'],['reminders','♧','Reminders'],['notes','▤','Notes'],['timetable','▦','Timetable'],['habits','◇','Habits'],['timer','◷','Study Timer'],['attendance','♟','Attendance'],['exams','▣','Exams'],['courses','⌘','Online Courses'],['library','▣','My Library']
    ]},
    { section:'LIFE & PLAY', items:[
      ['anime','✦','Anime Tracker'],['movies','▣','Movies & Series'],['games','♧','Games'],['sports','⚑','Sports & Gym'],['finance','₹','Finance'],['tools','⊞','Tools']
    ]},
    { section:'INSIGHTS & SETTINGS', items:[
      ['progressGraph','⌁','Progress Graph'],['settings','⚙','Settings']
    ]}
  ];
  const ROUTES = Object.fromEntries(NAV.flatMap(g => g.items.map(([key, icon, label]) => [key,{key,icon,label}])));
  const COLLECTION = { tasks:'tasks', reminders:'reminders', notes:'notes', habits:'habits', exams:'exams', courses:'coursesOnline', library:'library', anime:'anime', movies:'movies', games:'games', finance:'expenses', tools:'customTools' };
  const SCHEMAS = {
    tasks:[
      {key:'title',label:'Task title',required:true,placeholder:'What needs to get done?'},
      {key:'description',label:'Description',type:'textarea',full:true,placeholder:'Helpful detail (optional)'},
      {key:'dueAt',label:'Due date & time',type:'datetime-local'},
      {key:'priority',label:'Priority',type:'select',options:[['low','Low'],['medium','Medium'],['high','High'],['urgent','Urgent']],default:'medium'},
      {key:'category',label:'Category',placeholder:'Study, personal, project…'}
    ],
    reminders:[
      {key:'title',label:'Reminder title',required:true,placeholder:'What should you remember?'},
      {key:'dueAt',label:'Date & time',type:'datetime-local',required:true},
      {key:'category',label:'Category',placeholder:'Personal, college…'},
      {key:'priority',label:'Priority',type:'select',options:[['low','Low'],['medium','Medium'],['high','High']],default:'medium'},
      {key:'repeat',label:'Repeat',type:'select',options:[['none','Does not repeat'],['daily','Daily'],['weekly','Weekly']],default:'none'},
      {key:'details',label:'Details',type:'textarea',full:true,placeholder:'Optional details'}
    ],
    notes:[
      {key:'title',label:'Note title',required:true,placeholder:'A title you will recognize'},
      {key:'subject',label:'Subject / category',placeholder:'Cryptography, ideas…'},
      {key:'body',label:'Note body',type:'textarea',full:true,placeholder:'Capture the important bits…'},
      {key:'url',label:'Related link',type:'url',full:true,placeholder:'https://…'}
    ],
    habits:[
      {key:'title',label:'Habit name',required:true,placeholder:'Read 10 pages'},
      {key:'icon',label:'Icon / emoji',type:'select',options:[['✦','✦ Sparkle'],['📚','📚 Books'],['💧','💧 Water'],['🏃','🏃 Running'],['💪','💪 Fitness'],['🧘','🧘 Mindfulness'],['🛏️','🛏️ Sleep'],['🥗','🥗 Nutrition'],['🧹','🧹 Cleaning'],['📝','📝 Study'],['🎯','🎯 Focus'],['🎨','🎨 Creative'],['🎮','🎮 Gaming'],['🎵','🎵 Music'],['🚶','🚶 Walking'],['🦷','🦷 Dental care'],['💊','💊 Medication'],['🌱','🌱 Growth'],['☀️','☀️ Morning'],['🌙','🌙 Evening'],['🧠','🧠 Learning'],['🧪','🧪 Practice'],['🧑‍💻','🧑‍💻 Coding'],['🎧','🎧 Listening'],['🧼','🧼 Self-care'],['🥤','🥤 Hydration'],['🪴','🪴 Plants'],['🐕','🐕 Pet care'],['🧺','🧺 Chores'],['🛡️','🛡️ Safety'],['💰','💰 Saving'],['🚴','🚴 Cycling'],['🏊','🏊 Swimming'],['⚽','⚽ Sports'],['🎹','🎹 Music practice'],['✍️','✍️ Writing'],['🗣️','🗣️ Language']],default:'✦'},
      {key:'category',label:'Category',placeholder:'Health, learning…'}
    ],
    exams:[
      {key:'title',label:'Exam / assessment',required:true,placeholder:'Mid-semester exam'},
      {key:'subject',label:'Subject',type:'subject'},
      {key:'dateTime',label:'Date & time',type:'datetime-local',required:true},
      {key:'location',label:'Room / location',placeholder:'Room 204'},
      {key:'importance',label:'Importance',type:'select',options:[['normal','Normal'],['important','Important'],['critical','Critical']],default:'normal'},
      {key:'notes',label:'Notes',type:'textarea',full:true,placeholder:'Topics or reminders'}
    ],
    courses:[
      {key:'title',label:'Course title',required:true,placeholder:'Course or certification'},
      {key:'provider',label:'Provider',placeholder:'Coursera, Cisco…'},
      {key:'url',label:'Course URL',type:'url',placeholder:'https://…'},
      {key:'status',label:'Status',type:'select',options:[['planned','Planned'],['in-progress','In progress'],['completed','Completed'],['paused','Paused']],default:'planned'},
      {key:'progress',label:'Progress (%)',type:'number',min:0,max:100,default:0},
      {key:'dueDate',label:'Target date',type:'date'},
      {key:'notes',label:'Notes',type:'textarea',full:true}
    ],
    library:[
      {key:'title',label:'Item title',required:true,placeholder:'Reference, file, or useful link'},
      {key:'type',label:'Type',type:'select',options:[['link','Link'],['document','Document'],['image','Image'],['video','Video'],['other','Other']],default:'link'},
      {key:'category',label:'Category',placeholder:'Study, project…'},
      {key:'url',label:'URL',type:'url',full:true,placeholder:'https://…'},
      {key:'description',label:'Description',type:'textarea',full:true}
    ],
    anime:[
      {key:'title',label:'Anime title',required:true,placeholder:'Title'},
      {key:'status',label:'Status',type:'select',options:[['Planning','Planning'],['Watching','Watching'],['Completed','Completed'],['Paused','Paused']],default:'Planning'},
      {key:'watched',label:'Episodes watched',type:'number',min:0,default:0},
      {key:'total',label:'Total episodes',type:'number',min:0,placeholder:'Unknown if blank'},
      {key:'rating',label:'Rating / 10',type:'number',min:0,max:10},
      {key:'url',label:'Watch / information URL',type:'url',full:true},
      {key:'notes',label:'Notes',type:'textarea',full:true}
    ],
    movies:[
      {key:'title',label:'Title',required:true,placeholder:'Movie or series'},
      {key:'type',label:'Type',type:'select',options:[['Movie','Movie'],['Series','Series']],default:'Movie'},
      {key:'status',label:'Status',type:'select',options:[['Watchlist','Watchlist'],['Watching','Watching'],['Completed','Completed'],['Paused','Paused']],default:'Watchlist'},
      {key:'rating',label:'Rating / 10',type:'number',min:0,max:10},
      {key:'url',label:'Information / watch URL',type:'url',full:true},
      {key:'notes',label:'Notes',type:'textarea',full:true}
    ],
    games:[
      {key:'title',label:'Game title',required:true,placeholder:'Game name'},
      {key:'platform',label:'Platform',placeholder:'PC, Switch…'},
      {key:'url',label:'Web link',type:'url',full:true,placeholder:'https://…'},
      {key:'localPath',label:'Windows game path (.exe or .lnk)',full:true,placeholder:'C:\\Games\\MyGame\\MyGame.exe',help:'Use a local Windows .exe or .lnk path. Play is user-triggered and only works in the Windows desktop build.'},
      {key:'notes',label:'Notes',type:'textarea',full:true}
    ],
    finance:[
      {key:'description',label:'Description',required:true,placeholder:'What was this for?'},
      {key:'type',label:'Entry type',type:'select',options:[['expense','Expense'],['income','Income']],default:'expense'},
      {key:'amount',label:'Amount (₹)',type:'number',min:0.01,step:'0.01',required:true},
      {key:'category',label:'Category',placeholder:'Food, travel, books…'},
      {key:'date',label:'Date',type:'date',required:true,default: M.localDateKey(new Date())}
    ],
    tools:[
      {key:'title',label:'Custom tool name',required:true,placeholder:'A shortcut or utility'},
      {key:'description',label:'Description',type:'textarea',full:true},
      {key:'url',label:'Optional URL action',type:'url',full:true,placeholder:'https://…'}
    ]
  };
  let state, currentRoute='today', filters={}, subjectSearch='', classSearch='', attendanceSearch='', dailyAttendanceDate='', examTab='exams', graphRange=7, graphMetric='tasks';
  let corruptRaw=null, persistenceBlocked=false, pendingImport=null, modalDirty=false, modalReturnFocus=null, modalScrollY=0;
  let timerMode='focus', timerRemaining=25*60, timerRunning=false, timerDeadline=0, timerInterval=null, timerTheater=false;
  let theaterCanvas=null, theaterCtx=null, theaterFrame=0, theaterStars=[], theaterShootingStars=[], theaterSurfaceForms=[], theaterOceanGrain=[], theaterNextShootingAt=0, theaterPointer={x:-1000,y:-1000,down:false}, theaterEventsBound=false;
  let desktopCloseBehavior='ask', alarmAudioContext=null, alarmSoundInterval=null, activeReminderAlarm=null, reminderAlarmQueue=[], queuedReminderAlarmKeys=new Set();
  let calculatorExpression='', calculatorResult='', calculatorError='';
  let weatherState={city:'',status:'idle',place:'',current:null,error:'',updatedAt:0};
  let weatherRequestToken=0;
  const notificationSent = new Set();
  window.addEventListener('omni-storage-error',event=>toast(`Workspace file save failed: ${event.detail}. Check that the project folder is writable and keep the server running.`, 'error'));
  try { const loaded = S.load(); state=loaded.state; } catch (err) { state=M.defaultState(); if (err.raw) { corruptRaw=err.raw; persistenceBlocked=true; } console.error(err); }
  dailyAttendanceDate = localDate();
  timerRemaining = durationForMode('focus');

  function durationForMode(mode) { return Math.max(1, Number(mode==='focus' ? state.profile.focus : mode==='short' ? state.profile.shortBreak : state.profile.longBreak) || 1) * 60; }
  function localDate(date=new Date()) { return M.localDateKey(date); }
  function parseDate(v) { const d = new Date(v); return Number.isNaN(d.getTime()) ? null : d; }
  function fmtDate(value, opts={weekday:'short',month:'short',day:'numeric'}) { const d=parseDate(value); return d ? d.toLocaleDateString(undefined,opts) : 'No date'; }
  function fmtDateTime(value) { const d=parseDate(value); return d ? `${d.toLocaleDateString(undefined,{month:'short',day:'numeric'})} · ${d.toLocaleTimeString(undefined,{hour:'numeric',minute:'2-digit'})}` : 'No date set'; }
  function fmtTime(value) { if (!value) return ''; const [h,m]=value.split(':').map(Number); if (!Number.isFinite(h)||!Number.isFinite(m)) return value; const d=new Date(); d.setHours(h,m,0,0); return d.toLocaleTimeString(undefined,{hour:'numeric',minute:'2-digit'}); }
  function weekdayIndex(date=new Date()) { return (date.getDay()+6)%7; }
  function dateForWeekday(index) { const now=new Date(); const monday=new Date(now); monday.setDate(now.getDate()-weekdayIndex(now)); monday.setHours(12,0,0,0); monday.setDate(monday.getDate()+index); return monday; }
  function titleCase(s='') { return String(s).replace(/[-_]/g,' ').replace(/\b\w/g,c=>c.toUpperCase()); }
  function toast(message,type='success') { const region=$('#toastRegion'); if(!region) return; const el=document.createElement('div'); el.className=`toast ${type}`; el.innerHTML=`<span class="toast-mark">${type==='success'?'✓':type==='error'?'!':'i'}</span><span>${esc(message)}</span>`; region.appendChild(el); setTimeout(()=>el.remove(),4300); }
  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function commit(mutator, successMessage='Saved.') {
    if (persistenceBlocked) { toast('Saved data is damaged; export the recovery copy in Settings before starting a fresh workspace. No changes were written.', 'error'); return false; }
    const next=clone(state);
    try { mutator(next); const normalized=M.normalizeState(next); S.save(normalized); state=normalized; refreshShell(); renderPage(); if(successMessage) toast(successMessage); return true; }
    catch(err) { console.error(err); toast(err.message || 'Could not save this change. Your previous saved state is unchanged.','error'); return false; }
  }
  function safeDownload(name, content, mime='application/json') { const blob=new Blob([content],{type:mime}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),1000); }
  function countReminders() { return state.reminders.filter(r=>!r.completed).length; }
  function refreshShell() {
    $('#breadcrumb').textContent=ROUTES[currentRoute]?.label || 'Today';
    $('#profileLabel').textContent=state.profile.name?.trim() ? state.profile.name.trim() : 'Your profile';
    $('#avatarMark').textContent=(state.profile.name?.trim()?.[0] || 'U').toUpperCase();
    $('#reminderDot').hidden=!state.reminders.some(r=>!r.completed && r.dueAt && new Date(r.dueAt)<=new Date());
    $$('.nav-item').forEach(el=>{ const active=el.dataset.route===currentRoute; el.classList.toggle('active',active); if(active)el.setAttribute('aria-current','page');else el.removeAttribute('aria-current'); });
    const counts={tasks:state.tasks.filter(t=>!t.completed).length,reminders:countReminders(),exams:state.exams.filter(e=>!e.completed&&e.dateTime&&new Date(e.dateTime)>=new Date()).length};
    for(const key of Object.keys(counts)){const badge=$(`[data-nav-count="${key}"]`);if(badge){badge.textContent=counts[key];badge.hidden=counts[key]===0;}}
    document.body.classList.toggle('compact',!!state.settings.compact);
    $('.ambient-a').hidden=$('.ambient-b').hidden=!state.settings.ambient;
    if(state.settings.reducedMotion==='reduce')document.documentElement.style.scrollBehavior='auto';
  }
  function renderNav() {
    $('#navigation').innerHTML=NAV.map(group=>`<div class="nav-section">${esc(group.section)}</div>${group.items.map(([key,icon,label])=>`<button class="nav-item" data-action="navigate" data-route="${key}"><span class="nav-icon" aria-hidden="true">${icon}</span><span class="nav-label">${esc(label)}</span>${['tasks','reminders','exams'].includes(key)?`<span class="nav-count" data-nav-count="${key}" hidden>0</span>`:''}</button>`).join('')}`).join('');
  }
  function btn(label, action, attrs='', cls='btn') { return `<button type="button" class="${cls}" data-action="${action}" ${attrs}>${label}</button>`; }
  function pageHeader(eyebrow,title,description,actions='') { return `<div class="page-heading"><div><div class="eyebrow">${esc(eyebrow)}</div><h1>${esc(title)}</h1><p>${esc(description)}</p></div><div class="heading-actions">${actions}</div></div>`; }
  function panelHead(title,subtitle='',actions='') { return `<div class="panel-heading"><div><h2>${esc(title)}</h2>${subtitle?`<p>${esc(subtitle)}</p>`:''}</div>${actions}</div>`; }
  function emptyState(icon,title,copy,action='') { return `<div class="empty-state"><div class="empty-icon">${icon}</div><h3>${esc(title)}</h3><p>${esc(copy)}</p>${action}</div>`; }
  function badge(text, cls='') { return `<span class="badge ${cls}">${esc(text)}</span>`; }
  function statCard(icon,label,value,helper,route='') { return `<button class="stat-card ${route?'clickable':''}" ${route?`data-action="navigate" data-route="${route}"`:''} ${route?'type="button"':'type="button" disabled aria-disabled="true"'}><span class="stat-icon">${icon}</span><span class="stat-copy"><span class="stat-label">${esc(label)}</span><span class="stat-number">${esc(value)}</span><span class="stat-helper">${esc(helper)}</span></span></button>`; }
  function navigate(route) { if(!ROUTES[route]) { toast(`That page is not available: ${route}`,'error'); return; } currentRoute=route; document.body.classList.remove('sidebar-open','timer-theater'); timerTheater=false; stopTheaterVisual(); refreshShell(); renderPage(); window.scrollTo({top:0,behavior:state.settings.reducedMotion==='reduce'?'auto':'smooth'}); }
  function renderPage() {
    const root=$('#pageRoot'); if(!root)return;
    let output='';
    switch(currentRoute){
      case 'today': output=renderToday(); break;
      case 'dashboard': output=renderDashboard(); break;
      case 'tasks': output=renderTasks(); break;
      case 'reminders': output=renderReminders(); break;
      case 'notes': output=renderCollectionPage('notes'); break;
      case 'timetable': output=renderTimetable(); break;
      case 'habits': output=renderHabits(); break;
      case 'timer': output=renderTimerPage(); break;
      case 'attendance': output=renderAttendance(); break;
      case 'exams': output=renderExams(); break;
      case 'courses': case 'library': case 'anime': case 'movies': case 'games': output=renderCollectionPage(currentRoute); break;
      case 'sports': output=renderSports(); break;
      case 'finance': output=renderFinance(); break;
      case 'tools': output=renderTools(); break;
      case 'progressGraph': output=renderProgressGraph(); break;
      case 'settings': output=renderSettings(); break;
      default: output=emptyState('◇','Page unavailable','This route does not have a registered page.');
    }
    root.innerHTML=output;
    refreshShell();
    if(currentRoute==='timer') syncTimerUI();
    if(currentRoute==='tools') syncCalculatorUI();
  }

  function todayClasses(date=new Date()) {
    const key=localDate(date), day=weekdayIndex(date);
    return state.timetable.filter(c => c.date ? c.date===key : Number(c.day)===day).sort((a,b)=>String(a.start||'').localeCompare(String(b.start||'')));
  }
  function classSubject(c) { return state.subjects.find(s=>s.id===c.subjectId)?.name || c.subjectName || 'Removed subject'; }
  function attendanceRecord(classId,date=localDate()) { return state.attendanceLog[`${classId}|${date}`] || null; }
  function classTiming(c,date) {
    const today=localDate(), minutesNow=(new Date()).getHours()*60+(new Date()).getMinutes(), parseTime=t=>{const parts=String(t||'').split(':').map(Number);return parts.length===2&&parts.every(Number.isFinite)?parts[0]*60+parts[1]:-1;};
    if(date!==today)return {label:date<today?'Past date':'Scheduled',cls:date<today?'':'blue'};
    const start=parseTime(c.start),end=parseTime(c.end);if(start>=0&&end>=0&&minutesNow>=start&&minutesNow<end)return {label:'In progress',cls:'green'};if(end>=0&&minutesNow>=end)return {label:'Passed',cls:''};return {label:'Upcoming',cls:'blue'};
  }
  function classCard(c,date=localDate(),compact=false) {
    const record=attendanceRecord(c.id,date),timing=classTiming(c,date);
    return `<div class="class-card"><div class="inline-actions" style="justify-content:space-between"><strong>${esc(classSubject(c))}</strong>${badge(timing.label,timing.cls)}</div><small>${esc(fmtTime(c.start))} – ${esc(fmtTime(c.end))}${c.room?` · ${esc(c.room)}`:''}</small><small>${esc(c.classType||'Lecture')}${c.note?` · ${esc(c.note)}`:''}</small>${compact?'':`<div class="class-actions">${btn(record?.status==='present'?'✓ Present':'Present','mark-attendance',`data-class-id="${esc(c.id)}" data-status="present" data-date="${date}"`,'btn btn-small')}${btn(record?.status==='absent'?'✓ Absent':'Absent','mark-attendance',`data-class-id="${esc(c.id)}" data-status="absent" data-date="${date}"`,'btn btn-small btn-quiet')}${btn('Edit','edit-class',`data-id="${esc(c.id)}"`,'btn btn-small btn-quiet')}${btn('Delete','delete-class',`data-id="${esc(c.id)}"`,'btn btn-small btn-danger')}</div>`}</div>`;
  }
  function taskRow(t,compact=false) {
    const priority=String(t.priority||'medium').toLowerCase();
    return `<div class="task-row ${t.completed?'is-complete':''}"><input class="task-check" type="checkbox" aria-label="Mark ${esc(t.title)} complete" data-action="toggle-task" data-id="${esc(t.id)}" ${t.completed?'checked':''}><div class="task-main"><div class="task-title">${esc(t.title)}</div><div class="task-sub">${t.dueAt?`${esc(fmtDateTime(t.dueAt))} · `:''}${esc(t.category||'General')}</div></div>${compact?'':`<span class="priority-dot ${esc(priority)}">${esc(titleCase(priority))}</span>`}</div>`;
  }
  function reminderRow(r) {
    const overdue=!r.completed && r.dueAt && new Date(r.dueAt)<new Date();
    return `<div class="simple-row"><span class="stat-icon" style="width:35px;height:35px;border-radius:10px;font-size:15px">◷</span><div class="task-main"><div class="task-title">${esc(r.title)}</div><div class="task-sub">${esc(fmtDateTime(r.dueAt))} · ${esc(r.category||'Reminder')} ${r.repeat&&r.repeat!=='none'?`· repeats ${esc(r.repeat)}`:''}</div></div>${overdue?badge('Overdue','red'):''}<div class="inline-actions">${btn('Done','complete-reminder',`data-id="${esc(r.id)}"`,'btn btn-small')}${btn('+10m','snooze-reminder',`data-id="${esc(r.id)}"`,'btn btn-small btn-quiet')}</div></div>`;
  }
  function habitRow(h,date=localDate()) {
    const done=(h.completedDates||[]).includes(date);
    return `<div class="simple-row"><button class="habit-check ${done?'done':''}" data-action="toggle-habit" data-id="${esc(h.id)}" aria-label="${done?'Undo':'Complete'} habit ${esc(h.title)}">${done?'✓':esc(h.icon||'◇')}</button><div class="task-main"><div class="task-title">${esc(h.title)}</div><div class="task-sub">${esc(h.category||'Daily habit')}</div></div><span class="muted-2 micro">${done?'DONE TODAY':'NOT YET'}</span></div>`;
  }
  function weatherDescription(code) {
    const table={0:['Clear sky','☀️'],1:['Mainly clear','🌤️'],2:['Partly cloudy','⛅'],3:['Overcast','☁️'],45:['Fog','🌫️'],48:['Rime fog','🌫️'],51:['Light drizzle','🌦️'],53:['Drizzle','🌦️'],55:['Dense drizzle','🌧️'],56:['Freezing drizzle','🌧️'],57:['Heavy freezing drizzle','🌧️'],61:['Light rain','🌦️'],63:['Rain','🌧️'],65:['Heavy rain','🌧️'],66:['Freezing rain','🌧️'],67:['Heavy freezing rain','🌧️'],71:['Light snow','🌨️'],73:['Snow','🌨️'],75:['Heavy snow','❄️'],77:['Snow grains','❄️'],80:['Rain showers','🌦️'],81:['Showers','🌧️'],82:['Heavy showers','⛈️'],85:['Snow showers','🌨️'],86:['Heavy snow showers','❄️'],95:['Thunderstorm','⛈️'],96:['Thunderstorm with hail','⛈️'],99:['Severe thunderstorm with hail','⛈️']};
    return table[Number(code)]||['Conditions unavailable','🌡️'];
  }
  function weatherWidgetMarkup() {
    const city=String(state.profile.city||'').trim();
    if(!city)return `<div id="weatherWidget" class="weather-widget"><span class="weather-icon">🌦️</span><span class="weather-copy"><strong>Local weather</strong><small>Add a city or place in Settings to see current weather.</small></span></div>`;
    if(weatherState.city.toLowerCase()!==city.toLowerCase()||weatherState.status==='loading')return `<div id="weatherWidget" class="weather-widget"><span class="weather-icon">🌍</span><span class="weather-copy"><strong>Weather for ${esc(city)}</strong><small>${weatherState.status==='error'&&weatherState.city.toLowerCase()===city.toLowerCase()?esc(weatherState.error):'Looking up current conditions…'}</small></span><button class="weather-refresh" data-action="refresh-weather" aria-label="Refresh weather">↻</button></div>`;
    if(weatherState.status==='error')return `<div id="weatherWidget" class="weather-widget"><span class="weather-icon">🌦️</span><span class="weather-copy"><strong>Weather unavailable</strong><small>${esc(weatherState.error||'Could not fetch current conditions.')}</small></span><button class="weather-refresh" data-action="refresh-weather" aria-label="Retry weather">↻</button></div>`;
    if(weatherState.current){const d=weatherState.current,desc=weatherDescription(d.weather_code);return `<div id="weatherWidget" class="weather-widget"><span class="weather-icon">${desc[1]}</span><span class="weather-copy"><strong>${Math.round(Number(d.temperature_2m))}°C · ${esc(desc[0])}</strong><small>${esc(weatherState.place||city)} · Feels ${Math.round(Number(d.apparent_temperature))}°C · Wind ${Math.round(Number(d.wind_speed_10m))} km/h</small></span><button class="weather-refresh" data-action="refresh-weather" aria-label="Refresh weather">↻</button></div>`;}
    return `<div id="weatherWidget" class="weather-widget"><span class="weather-icon">🌦️</span><span class="weather-copy"><strong>Weather for ${esc(city)}</strong><small>Current conditions have not loaded yet.</small></span><button class="weather-refresh" data-action="refresh-weather" aria-label="Refresh weather">↻</button></div>`;
  }
  function updateWeatherWidget() { const root=$('#weatherWidget');if(root)root.outerHTML=weatherWidgetMarkup(); }
  async function loadWeatherForCity(rawCity, force=false) {
    const city=String(rawCity||'').trim();const token=++weatherRequestToken;
    if(!city){weatherState={city:'',status:'idle',place:'',current:null,error:'',updatedAt:0};updateWeatherWidget();return;}
    if(!force&&weatherState.city.toLowerCase()===city.toLowerCase()&&weatherState.current&&Date.now()-weatherState.updatedAt<15*60*1000){updateWeatherWidget();return;}
    weatherState={city,status:'loading',place:'',current:null,error:'',updatedAt:0};updateWeatherWidget();
    try{
      // Resolve weather through the loopback Python helper. This avoids browsers/extensions
      // blocking direct cross-origin requests and lets the UI show the real upstream error.
      const response=await fetch(`/api/weather?city=${encodeURIComponent(city)}`,{headers:{Accept:'application/json'},cache:'no-store'});
      let payload=null;
      try{payload=await response.json();}catch(_){payload=null;}
      if(token!==weatherRequestToken)return;
      if(!response.ok||!payload?.ok){
        const message=payload?.error||`Weather lookup failed (HTTP ${response.status}).`;
        throw new Error(message);
      }
      if(!payload.current||!Number.isFinite(Number(payload.current.temperature_2m)))throw new Error('The weather service returned no current conditions for this place.');
      weatherState={city,status:'ready',place:payload.place||city,current:payload.current,error:'',updatedAt:Date.now()};
    }catch(err){
      if(token!==weatherRequestToken)return;
      const rawMessage=String(err?.message||'');
      const friendlyMessage=/failed to fetch|networkerror|load failed|fetch failed/i.test(rawMessage)
        ? 'Could not reach OMNI-GO’s local weather helper. Keep the OMNI-GO server running and retry.'
        : rawMessage||'Weather is not available right now.';
      weatherState={city,status:'error',place:'',current:null,error:friendlyMessage,updatedAt:0};
    }
    updateWeatherWidget();
  }

  function renderToday() {
    const now=new Date(), dateKey=localDate(now), classes=todayClasses(now), pending=state.tasks.filter(t=>!t.completed).sort((a,b)=>(a.dueAt||'9999').localeCompare(b.dueAt||'9999')).slice(0,4), reminders=state.reminders.filter(r=>!r.completed).sort((a,b)=>(a.dueAt||'9999').localeCompare(b.dueAt||'9999')).slice(0,3), habits=state.habits.filter(h=>h.active!==false).slice(0,4);
    const dueReminders=state.reminders.filter(r=>!r.completed&&r.dueAt&&r.dueAt.slice(0,10)===dateKey).length;
    const overall=overallAttendanceDisplay(); const tasksDone=state.tasks.filter(t=>t.completed && (t.completedAt||'').slice(0,10)===dateKey).length; const dueTasks=state.tasks.filter(t=>(t.dueAt||'').slice(0,10)===dateKey).length;
    return `<div class="workspace-grid"><div class="span-8"><div class="hero"><div class="hero-copy"><div class="eyebrow">TODAY · YOUR NEXT CHAPTER STARTS HERE</div><h1>${state.profile.name?.trim()?`Hey, ${esc(state.profile.name.trim())}`:'Hey there'} <span>👋</span></h1><p>Keep going. Small steps still move you forward.</p><div class="hero-pills"><span class="hero-chip">✦ One day at a time</span><span class="hero-chip">↗ Make it count</span></div></div><div class="hero-time"><div class="hero-date" id="heroDate">${esc(now.toLocaleDateString(undefined,{weekday:'short',month:'short',day:'2-digit',year:'numeric'}))}</div><div class="hero-clock" id="heroClock">${esc(now.toLocaleTimeString(undefined,{hour:'numeric',minute:'2-digit'}))}</div><div class="hero-location">${state.profile.city?.trim()?esc(state.profile.city):'Your location label'} · <button class="btn-link" data-action="navigate" data-route="settings">Edit in Settings</button></div>${weatherWidgetMarkup()}</div></div></div><div class="span-4"><div class="panel quote-panel"><div class="quote-text">“Same Player.<br>Bigger Goals.”</div><div class="quote-crown">♛</div></div></div></div>
      <div class="stat-grid">${statCard('☷','Tasks Done Today',String(tasksDone),`${dueTasks} due today · ${state.tasks.filter(t=>!t.completed).length} pending`,'tasks')}${statCard('◷','Study Time',`${Number(state.progressHistory.studyMinutes[dateKey]||0)} min`,'Tracked focus time','progressGraph')}${statCard('♨','Task Streak',`${taskStreak()} days`,'Current task-completion streak','progressGraph')}${statCard('▥','Attendance',overall==null?'—':`${overall.toFixed(1)}%`,'Target: 75%','attendance')}${statCard('▦','Exams Left',String(state.exams.filter(e=>e.dateTime&&new Date(e.dateTime)>=new Date()).length),'Start early. Stress less.','exams')}${statCard('▶','Anime Watchlist',String(state.anime.filter(a=>a.status==='Planning'||a.status==='Watching').length),'Titles on your list','anime')}</div>
      <div class="workspace-grid"><section class="panel panel-pad span-4">${panelHead("Today's Tasks",'Move the needle',btn('+ Add','add-record','data-route="tasks"','btn btn-primary btn-small'))}${pending.length?pending.map(t=>taskRow(t,true)).join(''):`${emptyState('✓','Your slate is clear.','Add a task to give your day a little direction.',btn('Add a task','add-record','data-route="tasks"','btn btn-small btn-primary'))}`}<div class="divider"></div><div class="inline-actions" style="justify-content:space-between"><span class="muted-2 micro">${tasksDone} completed today</span>${btn('View all tasks ↗','navigate','data-route="tasks"','btn-link')}</div></section>
      <section class="panel panel-pad span-4 focus-widget">${panelHead('Focus Timer','Deep work session',btn('⛶','toggle-theater','','icon-btn')+btn('⚙','timer-settings','','icon-btn'))}${timerTabs()}${timerRing()}<div class="timer-controls">${btn(timerRunning?'Ⅱ Pause':'▶ Start',timerRunning?'pause-timer':'start-timer','','btn btn-primary')}${btn('↻','reset-timer','','icon-btn')}${btn('⇥','skip-timer','','icon-btn')}${btn('⛶','toggle-theater','','icon-btn theater-exit')}</div><div class="timer-hint">Small focus blocks compound into big wins.</div></section>
      <section class="panel media-card span-4"><div class="media-art"><span class="media-stamp">◇ YOUR MEDIA HUB</span></div><div class="media-body"><div class="panel-eyebrow">LOCAL MUSIC PLAYER</div><div class="media-track"><div class="media-disc">♫</div><div class="media-track-copy"><strong id="mediaTrackTitle">Choose music from your PC</strong><small id="mediaTrackSub">MP3, WAV, OGG and browser-supported audio</small></div></div><input id="mediaFiles" type="file" accept="audio/*" multiple hidden><audio id="mediaAudio" preload="metadata"></audio><div class="media-controls">${btn('＋ Choose music','media-choose','','btn btn-primary')}${btn('⏮ Previous','media-prev','','btn')}${btn('▶ Play','media-play','','btn')}${btn('Next ⏭','media-next','','btn')}</div><div class="media-progress"><span id="mediaCurrent">0:00</span><input id="mediaSeek" type="range" min="0" max="1000" value="0" aria-label="Seek through current track"><span id="mediaDuration">0:00</span></div><div class="media-note" id="mediaStatus">This player plays files you select. Controlling arbitrary Windows apps requires a separate OS media integration.</div></div></section></div>
      <div class="workspace-grid"><section class="panel panel-pad span-7">${panelHead("Today's Timetable",`${classes.length} class${classes.length===1?'':'es'} on the schedule`,btn('Manage timetable ↗','navigate','data-route="timetable"','btn-link'))}${classes.length?classes.map(c=>classCard(c,dateKey)).join(''):emptyState('▦','No classes scheduled today','Add subjects and build your weekly timetable to see classes here.',btn('Set up timetable','navigate','data-route="timetable"','btn btn-primary btn-small'))}</section>
      <section class="panel panel-pad span-5">${panelHead('Reminders','Keep the important things close',btn('Reminder center ↗','navigate','data-route="reminders"','btn-link'))}${reminders.length?reminders.map(reminderRow).join(''):emptyState('◷','Nothing waiting on you','Add a reminder and it will show up here.',btn('Add reminder','add-record','data-route="reminders"','btn btn-primary btn-small'))}</section></div>
      <div class="workspace-grid"><section class="panel panel-pad span-12">${panelHead("Today's Habits",'Build consistency one check-in at a time',btn('+ Add habit','add-record','data-route="habits"','btn btn-small btn-primary'))}${habits.length?habits.map(h=>habitRow(h,dateKey)).join(''):emptyState('◇','Start with one small habit','Choose something simple enough to repeat.',btn('Create a habit','add-record','data-route="habits"','btn btn-small btn-primary'))}</section></div>`;
  }
  function taskStreak() {
    const dates=state.progressHistory.tasks||{}; let d=new Date(),streak=0;
    for(let i=0;i<366;i++){const key=localDate(d);if(Number(dates[key]||0)>0){streak++;d.setDate(d.getDate()-1);}else if(i===0){d.setDate(d.getDate()-1);if(Number(dates[localDate(d)]||0)>0){streak++;d.setDate(d.getDate()-1);}else break;}else break;}
    return streak;
  }
  function timerTabs() { return `<div class="timer-tabs">${[['focus','Focus'],['short','Short Break'],['long','Long Break']].map(([v,l])=>`<button class="timer-tab ${timerMode===v?'active':''}" data-action="timer-mode" data-mode="${v}">${l}</button>`).join('')}</div>`; }
  function timerRing() { const total=durationForMode(timerMode),pct=Math.max(0,Math.min(100,((total-timerRemaining)/total)*100)); return `<div class="timer-ring" style="--timer-progress:${pct}%"><div class="timer-ring-inner"><div class="timer-digits" id="timerDigits">${formatTimer(timerRemaining)}</div><div class="timer-label">${timerMode==='focus'?'Focus':timerMode==='short'?'Short break':'Long break'}</div></div></div>`; }
  function formatTimer(seconds) { const s=Math.max(0,Math.floor(seconds));return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`; }
  function renderDashboard() {
    const overall=overallAttendanceDisplay(); const pending=state.tasks.filter(t=>!t.completed).length; const recent=state.activityHistory.slice(0,7);
    const quick=[['＋','Add a task','tasks'],['◷','Add a reminder','reminders'],['▦','Build timetable','timetable'],['♟','Log attendance','attendance'],['◇','Check habits','habits'],['⌁','See progress','progressGraph']];
    return `${pageHeader('OVERVIEW','Dashboard','Your broader workspace at a glance — all figures come from records you have actually added.',btn('Open Today','navigate','data-route="today"','btn btn-primary'))}
      <div class="stat-grid">${statCard('☷','Pending Tasks',String(pending),'Open task list','tasks')}${statCard('◷','Study Minutes',String(Object.values(state.progressHistory.studyMinutes).reduce((a,b)=>a+Number(b||0),0)),'From completed focus sessions','progressGraph')}${statCard('◇','Habits',String(state.habits.filter(h=>h.active!==false).length),'Your active routines','habits')}${statCard('▥','Attendance',overall==null?'—':`${overall.toFixed(1)}%`,'From recorded class logs','attendance')}${statCard('▦','Upcoming Exams',String(state.exams.filter(e=>e.dateTime&&new Date(e.dateTime)>=new Date()).length),'Assessments ahead','exams')}${statCard('₹','Expenses',currency(state.expenses.filter(e=>e.type!=='income').reduce((a,e)=>a+Number(e.amount||0),0)),'Logged expenses','finance')}</div>
      <div class="workspace-grid"><section class="panel panel-pad span-7">${panelHead('Start with a quick action','Jump straight into what you need')}<div class="record-grid">${quick.map(([i,l,r])=>`<button class="record-card" style="text-align:left;cursor:pointer" data-action="navigate" data-route="${r}"><span class="stat-icon">${i}</span><span class="record-title">${l}</span><span class="record-subtitle">Open ${esc(ROUTES[r].label)}</span></button>`).join('')}</div></section>
      <section class="panel panel-pad span-5">${panelHead('Recent activity','A short trail of your real actions')}${recent.length?recent.map(a=>`<div class="simple-row"><span class="stat-icon" style="width:31px;height:31px;font-size:13px">✦</span><div class="task-main"><div class="task-title">${esc(a.label)}</div><div class="task-sub">${esc(titleCase(a.type))} · ${esc(fmtDateTime(a.date))}</div></div></div>`).join(''):emptyState('✦','Nothing logged yet','Completing tasks, focus sessions, habits and workouts will build your activity trail.')}</section></div>
      <div class="workspace-grid"><section class="panel panel-pad span-12">${panelHead('First-run setup','No demo data. Add only the things that belong to you.')}<div class="record-grid">${[['01','Subjects & timetable','Set up your subjects once, then use them in attendance too.','timetable'],['02','Your priorities','Add a few tasks and reminders for this week.','tasks'],['03','Focus habits','Create a habit and try one focus session.','timer'],['04','Make a backup','Export your workspace from Settings when you have data.','settings']].map(([n,t,d,r])=>`<article class="record-card"><span class="eyebrow">STEP ${n}</span><div class="record-title">${t}</div><div class="record-desc">${d}</div>${btn('Open ↗','navigate',`data-route="${r}"`,'btn btn-small btn-quiet')}</article>`).join('')}</div></section></div>`;
  }
  function renderTasks() {
    const q=(filters.tasks||'').toLowerCase(), tab=filters.tasksTab||'pending';
    const rows=state.tasks.filter(t=>(tab==='all'||(tab==='completed'?!!t.completed:!t.completed))&&(`${t.title} ${t.description||''} ${t.category||''}`.toLowerCase().includes(q))).sort((a,b)=>Number(a.completed)-Number(b.completed)||(a.dueAt||'9999').localeCompare(b.dueAt||'9999'));
    return `${pageHeader('GET THINGS DONE','Tasks','Turn your plans into small, finishable steps.',btn('+ Add task','add-record','data-route="tasks"','btn btn-primary'))}<div class="panel panel-pad">${panelHead('Your task list',`${state.tasks.filter(t=>!t.completed).length} pending · ${state.tasks.filter(t=>t.completed).length} completed`)}<div class="toolbar"><div class="search-box"><span>⌕</span><input class="form-control" data-filter-route="tasks" value="${esc(filters.tasks||'')}" placeholder="Search tasks…" aria-label="Search tasks"></div><div class="filter-tabs">${[['pending','Pending'],['completed','Completed'],['all','All']].map(([v,l])=>`<button class="filter-tab ${tab===v?'active':''}" data-action="task-filter" data-filter="${v}">${l}</button>`).join('')}</div></div>${rows.length?`<div>${rows.map(t=>`${taskRow(t)}<div class="record-actions" style="padding:0 0 7px">${btn('Edit','edit-record',`data-route="tasks" data-id="${esc(t.id)}"`,'btn btn-small btn-quiet')}${btn('Delete','delete-record',`data-route="tasks" data-id="${esc(t.id)}"`,'btn btn-small btn-danger')}</div>`).join('')}</div>`:emptyState('☷',q?'No matching tasks':'Nothing in this view',q?'Try a different search phrase.':tab==='completed'?'Completed tasks will collect here.':'Add a task to decide what matters next.',btn('+ Add task','add-record','data-route="tasks"','btn btn-small btn-primary'))}</div>`;
  }
  function renderReminders() {
    const q=(filters.reminders||'').toLowerCase(), shelf=filters.remindersTab||'upcoming', now=new Date();
    const rows=state.reminders.filter(r=>`${r.title} ${r.category||''} ${r.details||''}`.toLowerCase().includes(q)).filter(r=>shelf==='all'||(shelf==='completed'?r.completed:shelf==='overdue'?!r.completed&&r.dueAt&&new Date(r.dueAt)<now:shelf==='upcoming'?!r.completed&&r.dueAt&&new Date(r.dueAt)>=now&&new Date(r.dueAt)<=new Date(now.getTime()+24*60*60*1000):shelf==='scheduled'?!r.completed&&(!r.dueAt||new Date(r.dueAt)>new Date(now.getTime()+24*60*60*1000)):!r.completed)).sort((a,b)=>(a.dueAt||'9999').localeCompare(b.dueAt||'9999'));
    return `${pageHeader('REMEMBER WHAT MATTERS','Reminder Center','Reminders behave like alarms while OMNI-GO is running. No browser notification permission is required.',btn('+ Add reminder','add-record','data-route="reminders"','btn btn-primary'))}<div class="panel panel-pad">${panelHead('Your reminders','Alarms ring in the app; the Windows desktop build can also alert from the system tray.',btn('Test alarm sound','test-alarm','','btn btn-small btn-quiet'))}<div class="toolbar"><div class="search-box"><span>⌕</span><input class="form-control" data-filter-route="reminders" value="${esc(filters.reminders||'')}" placeholder="Search reminders…" aria-label="Search reminders"></div><div class="filter-tabs">${[['upcoming','Upcoming'],['overdue','Overdue'],['scheduled','Scheduled'],['completed','Completed'],['all','All']].map(([v,l])=>`<button class="filter-tab ${shelf===v?'active':''}" data-action="reminder-filter" data-filter="${v}">${l}</button>`).join('')}</div></div>${rows.length?`<div class="record-grid">${rows.map(r=>reminderCard(r)).join('')}</div>`:emptyState('◷','No reminders here','Create one with a date and time, or change this filter.',btn('+ Add reminder','add-record','data-route="reminders"','btn btn-primary btn-small'))}<div class="info-note" style="margin-top:15px">When a reminder is due, OMNI-GO opens an alarm panel and repeats a sound until you snooze, complete, or dismiss it. In the Windows desktop app, reminders can also alert while the app is minimized to the system tray. Alarms cannot run after you fully exit OMNI-GO.</div></div>`;
  }
  function reminderCard(r) {
    const overdue=!r.completed&&r.dueAt&&new Date(r.dueAt)<new Date();
    return `<article class="record-card"><div class="record-top"><div><div class="record-title">${esc(r.title)}</div><div class="record-subtitle">${esc(fmtDateTime(r.dueAt))}</div></div>${r.completed?badge('Completed','green'):overdue?badge('Overdue','red'):badge(titleCase(r.priority||'medium'),r.priority==='high'?'orange':'')}</div>${r.details?`<div class="record-desc">${esc(r.details)}</div>`:''}<div class="record-meta">${badge(r.category||'General')}${r.repeat&&r.repeat!=='none'?badge(`Repeats ${r.repeat}`,'blue'):''}</div><div class="record-actions">${r.completed?btn('Reopen','toggle-reminder',`data-id="${esc(r.id)}"`,'btn btn-small'):btn('Complete','complete-reminder',`data-id="${esc(r.id)}"`,'btn btn-small btn-primary')}${!r.completed?btn('Snooze 10m','snooze-reminder',`data-id="${esc(r.id)}"`,'btn btn-small btn-quiet'):''}${btn('Edit','edit-record',`data-route="reminders" data-id="${esc(r.id)}"`,'btn btn-small btn-quiet')}${btn('Delete','delete-record',`data-route="reminders" data-id="${esc(r.id)}"`,'btn btn-small btn-danger')}</div></article>`;
  }
  function renderCollectionPage(route) {
    const config={notes:['NOTES & CAPTURE','Notes','Keep the ideas, links, and details worth coming back to.','Capture note'],courses:['LEARN SOMETHING','Online Courses','Keep course links and your own progress in one place.','Add course'],library:['YOUR ARCHIVE','My Library','A shelf for useful links, files, and references.','Save item'],anime:['LIFE & PLAY','Anime Tracker','Follow your watchlist and episode progress. Discovery links are optional and configurable.','Add anime'],movies:['LIFE & PLAY','Movies & Series','Keep a personal watchlist without pretending a catalog is built in.','Add title'],games:['LIFE & PLAY','Games','Save a Windows game executable or shortcut, then press Play when you want to launch it.','Add game']}[route];
    const collection=COLLECTION[route], rows=state[collection]||[], q=(filters[route]||'').toLowerCase();
    let filtered=rows.filter(r=>Object.values(r).filter(v=>typeof v==='string'||typeof v==='number').join(' ').toLowerCase().includes(q));if(route==='notes'&&filters.notesSubject)filtered=rows.filter(r=>String(r.subject||'').trim().toLowerCase()===String(filters.notesSubject).trim().toLowerCase());
    let lead='';
    if(route==='anime'||route==='movies') { const type=route==='anime'?'animeUrl':'movieUrl'; const label=route==='anime'?'Anime discovery':'Movie discovery'; const url=state.discovery[type]; lead=`<div class="info-note" style="margin-bottom:13px">${url?`Configured discovery: <a href="${esc(M.safeUrl(url))}" target="_blank" rel="noopener noreferrer">${esc(state.discovery[route==='anime'?'animeLabel':'movieLabel']||label)} ↗</a>`:`No discovery site configured yet. Set a safe HTTP(S) link in Settings when you choose one.`} ${btn('Configure ↗','navigate','data-route="settings"','btn btn-small btn-quiet')}</div>`; }
    if(route==='notes') lead=`<div class="info-note" style="margin-bottom:13px">Notes are saved in the local project workspace file. Note attachments use browser storage; JSON backups do not include their binary contents.</div>`;
    if(route==='library') lead=`<div class="info-note" style="margin-bottom:13px">Upload PDFs, Office documents, images and videos directly into this library. File bytes are saved to <code>data/library_files</code> next to the app, not inside browser storage.</div>`;
    return `${pageHeader(config[0],config[1],config[2],btn(`+ ${config[3]}`,'add-record',`data-route="${route}"`,'btn btn-primary'))}${lead}<div class="panel panel-pad">${panelHead(config[1],`${rows.length} saved ${rows.length===1?'item':'items'}`)}<div class="toolbar"><div class="search-box"><span>⌕</span><input class="form-control" data-filter-route="${route}" value="${esc(filters[route]||'')}" placeholder="Search ${config[1].toLowerCase()}…" aria-label="Search ${config[1]}"></div>${route==='notes'?btn('Quick capture','add-record','data-route="notes" data-quick="true"','btn btn-small btn-quiet'):''}</div>${filtered.length?`<div class="record-grid">${filtered.map(r=>renderRecordCard(route,r)).join('')}</div>`:emptyState(route==='notes'?'▤':route==='anime'?'✦':route==='games'?'♧':'▣',q?'No matching records':`Your ${config[1].toLowerCase()} is empty`,q?'Try another search phrase.':'Add your first item to start building this part of your workspace.',btn(`+ ${config[3]}`,'add-record',`data-route="${route}"`,'btn btn-primary btn-small'))}</div>`;
  }
  function renderRecordCard(route,r) {
    const c=COLLECTION[route], title=r.title||r.description||'Untitled'; let subtitle='',description='',tags=[];
    if(route==='notes'){subtitle=[r.subject,`Updated ${fmtDate(r.updatedAt||r.createdAt,{month:'short',day:'numeric'})}`].filter(Boolean).join(' · ');description=r.body||'';if(r.url)tags.push(`<a class="badge blue" href="${esc(M.safeUrl(r.url)||'#')}" target="_blank" rel="noopener noreferrer">Open link ↗</a>`);}
    if(route==='courses'){subtitle=[r.provider,r.status?titleCase(r.status):'',r.dueDate?`Target ${fmtDate(r.dueDate,{month:'short',day:'numeric'})}`:''].filter(Boolean).join(' · ');description=r.notes||'';tags.push(badge(`${Number(r.progress||0)}% progress`,'blue'));}
    if(route==='library'){subtitle=[titleCase(r.type||'item'),r.category].filter(Boolean).join(' · ');description=r.description||'';if(Array.isArray(r.attachments)&&r.attachments.length)tags.push(badge(`${r.attachments.length} file${r.attachments.length===1?'':'s'}`,'blue'));}
    if(route==='anime'){subtitle=titleCase(r.status||'Planning');description=r.notes||'';if(r.total)tags.push(badge(`${Number(r.watched||0)} / ${Number(r.total)} eps`,'blue'));if(r.rating!==''&&r.rating!=null)tags.push(badge(`★ ${r.rating}/10`));}
    if(route==='movies'){subtitle=[r.type,titleCase(r.status||'Watchlist')].filter(Boolean).join(' · ');description=r.notes||'';if(r.rating!==''&&r.rating!=null)tags.push(badge(`★ ${r.rating}/10`));}
    if(route==='games'){subtitle=r.platform||'Platform not set';description=r.notes||'';if(r.localPath)tags.push(badge('Launch path saved','blue'));}
    return `<article class="record-card"><div class="record-top"><div><div class="record-title">${esc(title)}</div><div class="record-subtitle">${esc(subtitle)}</div></div>${route==='courses'?badge(r.status==='completed'?'Done':titleCase(r.status||'planned'),r.status==='completed'?'green':''):''}</div>${description?`<div class="record-desc">${esc(description.length>420?description.slice(0,420)+'…':description)}</div>`:''}${tags.length?`<div class="record-meta">${tags.join('')}</div>`:''}<div class="record-actions">${r.url&&M.safeUrl(r.url)?`<a class="btn btn-small btn-quiet" href="${esc(M.safeUrl(r.url))}" target="_blank" rel="noopener noreferrer">Open ↗</a>`:''}${(route==='notes'||route==='library')&&Array.isArray(r.attachments)&&r.attachments.length?btn(`Files (${r.attachments.length})`,'show-attachments',`data-id="${esc(r.id)}" data-route="${route}"`,'btn btn-small btn-quiet'):''}${route==='games'?(r.localPath?btn('▶ Play','launch-game',`data-id="${esc(r.id)}"`,'btn btn-small btn-primary'):btn('Set path','edit-record',`data-route="games" data-id="${esc(r.id)}"`,'btn btn-small btn-primary')):''}${btn('Edit','edit-record',`data-route="${route}" data-id="${esc(r.id)}"`,'btn btn-small btn-quiet')}${btn('Delete','delete-record',`data-route="${route}" data-id="${esc(r.id)}"`,'btn btn-small btn-danger')}</div></article>`;
  }
  function renderHabits() {
    const date=localDate(), active=state.habits.filter(h=>h.active!==false), done=active.filter(h=>(h.completedDates||[]).includes(date)).length;
    return `${pageHeader('SMALL THINGS, OFTEN','Habits','Build consistency without pretending a streak exists before you start.',btn('+ Add habit','add-record','data-route="habits"','btn btn-primary'))}<div class="stat-grid">${statCard('◇','Active Habits',String(active.length),'Routines you are tracking','habits')}${statCard('✓','Completed Today',`${done} / ${active.length}`,'Based on today’s check-ins','habits')}${statCard('✦','Check-in Date',fmtDate(date,{month:'short',day:'numeric'}),'Uses your local calendar','today')}</div><div class="panel panel-pad">${panelHead('Daily check-in','A single check per habit per local date is recorded.')}<div class="toolbar"><div class="search-box"><span>⌕</span><input class="form-control" data-filter-route="habits" value="${esc(filters.habits||'')}" placeholder="Search habits…"></div></div>${active.length?active.filter(h=>`${h.title} ${h.category||''}`.toLowerCase().includes((filters.habits||'').toLowerCase())).map(h=>`<div class="simple-row"><button class="habit-check ${(h.completedDates||[]).includes(date)?'done':''}" data-action="toggle-habit" data-id="${esc(h.id)}">${(h.completedDates||[]).includes(date)?'✓':esc(h.icon||'◇')}</button><div class="task-main"><div class="task-title">${esc(h.title)}</div><div class="task-sub">${esc(h.category||'General')} · ${habitStreak(h).current} day current streak · best ${habitStreak(h).best}</div></div>${btn('Edit','edit-record',`data-route="habits" data-id="${esc(h.id)}"`,'btn btn-small btn-quiet')}${btn('Delete','delete-record',`data-route="habits" data-id="${esc(h.id)}"`,'btn btn-small btn-danger')}</div>`).join(''):emptyState('◇','No habits yet','Start with a small routine you can realistically repeat.',btn('+ Add a habit','add-record','data-route="habits"','btn btn-primary btn-small'))}</div>`;
  }
  function habitStreak(h) {
    const set=new Set(h.completedDates||[]);let current=0,best=0,run=0, d=new Date();
    for(let i=0;i<730;i++){const key=localDate(d);if(set.has(key)){run++;best=Math.max(best,run);}else{if(i<366)best=Math.max(best,run);run=0;}d.setDate(d.getDate()-1);}
    d=new Date();if(!set.has(localDate(d)))d.setDate(d.getDate()-1);for(let i=0;i<366&&set.has(localDate(d));i++){current++;d.setDate(d.getDate()-1);}return {current,best};
  }
  function renderTimetable() {
    const q=(classSearch||'').toLowerCase(), days=WEEKDAYS.map((day,index)=>({day,index,date:dateForWeekday(index)}));
    const matching=(dayIndex,date)=>state.timetable.filter(c=>c.date?c.date===localDate(date):Number(c.day)===dayIndex).filter(c=>`${classSubject(c)} ${c.room||''} ${c.classType||''} ${c.note||''} ${c.start||''} ${c.end||''} ${WEEKDAYS[Number(c.day)]||''}`.toLowerCase().includes(q)).sort((a,b)=>String(a.start||'').localeCompare(String(b.start||'')));
    return `${pageHeader('YOUR WEEK, IN ONE VIEW','Timetable','Set up subjects first. The same subject list is used by Attendance, so you only create each subject once.',btn('+ Add Class','add-class','','btn btn-primary'))}
      <div class="workspace-grid"><section class="panel panel-pad span-12">${panelHead('Step 1 · Subjects','Add a list of subjects once, then use them for weekly classes and attendance.',btn('＋ Add / Edit Subjects','manage-subjects','','btn btn-small btn-primary'))}${state.subjects.length?`<div class="subject-list">${state.subjects.map(s=>`<span class="subject-chip">${esc(s.name)}<span class="chip-actions"><button data-action="edit-subject" data-id="${esc(s.id)}" aria-label="Rename ${esc(s.name)}">✎</button><button data-action="delete-subject" data-id="${esc(s.id)}" aria-label="Remove ${esc(s.name)}">×</button></span></span>`).join('')}</div>`:emptyState('▦','Add your subjects to get started','Enter subject names one per line, or separate them with commas or semicolons.',btn('Add Subjects','manage-subjects','','btn btn-primary btn-small'))}</section></div>
      <section class="panel panel-pad">${panelHead('Step 2 · Weekly schedule','Add as many lecture, lab, tutorial, or extra-class blocks as your day needs. Each class has its own time and attendance marker; classes are shown in Monday–Sunday order.',btn('+ Add Class / Extra Class','add-class','','btn btn-primary btn-small'))}<div class="toolbar"><div class="search-box"><span>⌕</span><input class="form-control" id="classSearch" value="${esc(classSearch)}" data-filter-timetable="true" placeholder="Search subject, day, room, type, or time…" aria-label="Search timetable"></div><span class="muted-2 small">${state.timetable.length} class${state.timetable.length===1?'':'es'} saved</span></div>${!state.subjects.length?`<div class="info-note" style="margin-bottom:12px">The builder needs at least one subject. Add one above to enable class planning.</div>`:''}<div class="week-grid">${days.map(({day,index,date})=>{const classes=matching(index,date);return `<div class="day-column"><div class="day-head"><div class="day-name">${day.toUpperCase()}</div><div class="day-date">${esc(date.toLocaleDateString(undefined,{month:'short',day:'numeric'}))}${localDate(date)===localDate()?' · TODAY':''}</div></div><div class="day-content">${classes.length?classes.map(c=>classCard(c,localDate(date))).join(''):emptyState('·','No classes','',btn('+ Add','add-class',`data-day="${index}"`,'btn btn-small btn-quiet'))}</div></div>`;}).join('')}</div><div class="divider"></div><div class="inline-actions">${btn('Open Attendance ↗','navigate','data-route="attendance"','btn btn-small btn-quiet')}${btn('Add Subjects','manage-subjects','','btn btn-small btn-quiet')}</div></section>`;
  }
  function openSubjectManager() {
    const existing=state.subjects.length?`<div class="field full"><label class="field-label">Existing subjects</label><div class="subject-list">${state.subjects.map(s=>`<span class="subject-chip">${esc(s.name)}<span class="chip-actions"><button type="button" data-action="edit-subject" data-id="${esc(s.id)}">✎</button><button type="button" data-action="delete-subject" data-id="${esc(s.id)}">×</button></span></span>`).join('')}</div></div>`:`<div class="info-note">No subjects yet. Add names below — they will immediately appear in Attendance too.</div>`;
    openModal('Add / Edit Subjects','Use one name per line. Commas and semicolons also work.',`<div class="field-grid"><div class="field full"><label class="field-label" for="subjectNames">Subject names</label><textarea class="form-control" id="subjectNames" name="names" rows="5" placeholder="Computer Networks\nCryptography\nOperating Systems\nData Structures"></textarea><span class="field-help">Names are trimmed and duplicates are removed, ignoring letter case.</span></div>${existing}</div>`,'add-subjects','Add Subjects');
  }
  function openSubjectEditor(id) {
    const subj=state.subjects.find(s=>s.id===id); if(!subj)return;
    openModal('Rename subject','Renaming updates the subject label in the timetable and new attendance views; historical records retain their identity.',`<div class="field"><label class="field-label" for="subjectName">Subject name</label><input class="form-control" id="subjectName" name="name" required value="${esc(subj.name)}" maxlength="120"></div>`,'subject-edit','Save subject',{id});
  }
  function openClassEditor(id, initialDay=null) {
    if(!state.subjects.length){toast('Add at least one subject before building a timetable.','info');openSubjectManager();return;}
    const c=id?state.timetable.find(x=>x.id===id):null; if(id&&!c)return;
    const subjectOptions=state.subjects.map(s=>[s.id,s.name]);
    const fields=[
      {key:'subjectId',label:'Subject',type:'select',options:subjectOptions,required:true,default:c?.subjectId||state.subjects[0].id},
      {key:'day',label:'Weekday',type:'select',options:WEEKDAYS.map((d,i)=>[String(i),d]),default:String(c?.day??initialDay??weekdayIndex()),required:true},
      {key:'start',label:'Start time',type:'time',default:c?.start||'09:00',required:true},
      {key:'end',label:'End time',type:'time',default:c?.end||'10:00',required:true},
      {key:'room',label:'Room / building',placeholder:'Optional'},
      {key:'classType',label:'Class type',type:'select',options:[['Lecture','Lecture'],['Lab','Lab'],['Tutorial','Tutorial'],['Extra Class','Extra Class']],default:c?.classType||'Lecture'},
      {key:'date',label:'Specific date (optional)',type:'date',help:'Leave blank for a weekly repeating class. Add a date for a one-off extra class.'},
      {key:'note',label:'Note (optional)',type:'text',full:true}
    ];
    const vals=c?{...c}:{}; if(c?.date) vals.date=c.date;
    openModal(c?'Edit class':'Add class / extra class',c?'Changes keep the same class ID.':'A date makes this a one-off class; leaving it blank repeats weekly.',fieldsHtml(fields,vals),c?'class-edit':'class-add',c?'Save changes':'Add class',{id:c?.id||'',day:initialDay});
  }
  function attendanceDisplay(subjectId) {
    const auto=M.attendanceSummary(state,subjectId), manual=state.attendanceManual[subjectId];
    if(manual && manual.mode==='percent')return {present:null,absent:null,total:null,percent:Number(manual.percent),mode:'manual'};
    if(manual && manual.mode==='count')return {present:Number(manual.attended),absent:Math.max(0,Number(manual.total)-Number(manual.attended)),total:Number(manual.total),percent:Number(manual.total)>0?Number(manual.attended)/Number(manual.total)*100:null,mode:'manual-count'};
    return {...auto,mode:'logged'};
  }
  function overallAttendanceDisplay() {
    const arr=state.subjects.map(s=>attendanceDisplay(s.id)).filter(s=>s.percent!=null);
    if(!arr.length)return null;
    if(state.attendanceCalculation==='equal')return arr.reduce((a,s)=>a+s.percent,0)/arr.length;
    const weighted=arr.reduce((a,s)=>a+(s.total? s.percent*s.total:s.percent),0),den=arr.reduce((a,s)=>a+(s.total||1),0);return den?weighted/den:null;
  }
  function dailyAttendanceSummary() {
    const rows=Object.values(state.dailyAttendance||{}).filter(r=>r&&['present','absent','holiday'].includes(r.status));
    const present=rows.filter(r=>r.status==='present').length, absent=rows.filter(r=>r.status==='absent').length, holiday=rows.filter(r=>r.status==='holiday').length, counted=present+absent;
    return {present,absent,holiday,counted,percent:counted?present/counted*100:null,rows:rows.sort((a,b)=>(b.date||'').localeCompare(a.date||''))};
  }
  function renderAttendance() {
    const q=(attendanceSearch||'').toLowerCase(), overall=overallAttendanceDisplay(), daily=dailyAttendanceSummary();
    const selectedDay=(state.dailyAttendance||{})[dailyAttendanceDate];
    const subjects=state.subjects.filter(s=>`${s.name} ${attendanceDisplay(s.id).percent??''}`.toLowerCase().includes(q));
    const logEntries=Object.entries(state.attendanceLog).filter(([,r])=>r&&['present','absent'].includes(r.status)).sort((a,b)=>(b[1].date||'').localeCompare(a[1].date||''));
    const dailyHistory=daily.rows;
    const dailyPanel=`<section class="panel panel-pad span-12">${panelHead('Daily attendance','Mark your overall college day once. Present/Absent counts toward the daily percentage; Holiday is excluded. Class-by-class attendance remains separate below.')}
      <div class="daily-attendance-editor"><div class="field"><label class="field-label" for="dailyAttendanceDate">School date</label><input class="form-control" type="date" id="dailyAttendanceDate" data-action="daily-attendance-date" value="${esc(dailyAttendanceDate)}" max="${esc(localDate())}"></div><div class="daily-attendance-selected"><span class="muted-2 micro">SELECTED DATE STATUS</span><strong>${selectedDay?esc(titleCase(selectedDay.status)):'Not marked yet'}</strong><span class="small muted">${esc(fmtDate(dailyAttendanceDate,{weekday:'long',month:'short',day:'numeric',year:'numeric'}))}</span></div><div class="inline-actions daily-attendance-actions">${btn('✓ Present day','mark-daily-attendance',`data-date="${esc(dailyAttendanceDate)}" data-status="present"`,'btn btn-primary')}${btn('× Absent day','mark-daily-attendance',`data-date="${esc(dailyAttendanceDate)}" data-status="absent"`,'btn btn-quiet')}${btn('◇ Holiday / no class','mark-daily-attendance',`data-date="${esc(dailyAttendanceDate)}" data-status="holiday"`,'btn btn-small btn-quiet')}${selectedDay?btn('Clear marker','clear-daily-attendance',`data-date="${esc(dailyAttendanceDate)}"`,'btn btn-small btn-danger'):''}</div></div>
      <div class="stat-grid daily-attendance-stats">${statCard('✓','Present Days',String(daily.present),'Marked college days','attendance')}${statCard('×','Absent Days',String(daily.absent),'Marked college days','attendance')}${statCard('◇','Holidays',String(daily.holiday),'Excluded from percentage','attendance')}${statCard('▥','Daily Attendance',daily.percent==null?'—':`${daily.percent.toFixed(1)}%`,'Present ÷ counted days','attendance')}</div>
      ${dailyHistory.length?`<div class="table-wrap"><table class="data-table"><thead><tr><th>Date</th><th>Marker</th><th class="number">Action</th></tr></thead><tbody>${dailyHistory.slice(0,45).map(r=>`<tr><td>${esc(fmtDate(r.date,{weekday:'short',month:'short',day:'numeric',year:'numeric'}))}</td><td>${badge(titleCase(r.status),r.status==='present'?'green':r.status==='absent'?'red':'blue')}</td><td class="number"><button class="btn btn-small btn-quiet" data-action="select-daily-attendance-date" data-date="${esc(r.date)}">View</button></td></tr>`).join('')}</tbody></table></div>`:emptyState('▤','No daily markers yet','Choose a date above and mark Present, Absent or Holiday. You can record older days one at a time.')}
      <div class="info-note" style="margin-top:12px">Daily attendance is a separate day-count calculation. Subject attendance below is calculated from individual class occurrences, so marking a whole day will not accidentally add attendance to every subject.</div></section>`;
    return `${pageHeader('SHOW UP, TRACK IT','Attendance','Track both overall college days and each individual class. Daily markers and class-wise records are calculated separately.',btn('Mark today','select-daily-attendance-date',`data-date="${esc(localDate())}"`,'btn btn-primary')+btn('+ Add Subject','manage-subjects','','btn btn-quiet'))}<div class="stat-grid">${statCard('♟','Overall Class Attendance',overall==null?'—':`${overall.toFixed(1)}%`,'Target: 75%','attendance')}${statCard('✓','Present Classes',String(logEntries.filter(([,r])=>r.status==='present').length),'Recorded occurrences','attendance')}${statCard('×','Absent Classes',String(logEntries.filter(([,r])=>r.status==='absent').length),'Recorded occurrences','attendance')}</div><div class="workspace-grid">${dailyPanel}<section class="panel panel-pad span-7">${panelHead('Subject summary','Shares the subject list with Timetable.',btn('Manage subjects','manage-subjects','','btn btn-small btn-quiet'))}<div class="toolbar"><div class="search-box"><span>⌕</span><input class="form-control" data-filter-attendance="true" value="${esc(attendanceSearch)}" placeholder="Search subjects…"></div><label class="small muted">Overall calculation <select class="form-control" data-action="attendance-calculation" style="display:inline-block;width:auto;min-height:32px;padding:5px 8px"><option value="weighted" ${state.attendanceCalculation!=='equal'?'selected':''}>Weighted by classes</option><option value="equal" ${state.attendanceCalculation==='equal'?'selected':''}>Equal subject average</option></select></label></div>${subjects.length?subjects.map(s=>{const sum=attendanceDisplay(s.id),pct=sum.percent,fill=pct==null?'':pct<65?'red':pct<75?'orange':'green';return `<div class="attendance-row"><div class="attendance-head"><div><div class="attendance-subject">${esc(s.name)}</div><div class="attendance-details">${sum.mode==='manual'?'Manual percentage':sum.mode==='manual-count'?'Manual count totals':`${sum.present} present · ${sum.absent} absent · ${sum.total} logged`}</div></div><div class="text-right"><div class="attendance-number">${pct==null?'—':`${pct.toFixed(1)}%`}</div><div class="muted-2 micro">${pct==null?'No records yet':pct>=75?'On target':'Below 75% target'}</div></div></div><div class="progress-track"><div class="progress-fill ${fill}" style="width:${pct==null?0:Math.max(0,Math.min(100,pct))}%"></div></div><div class="attendance-details"><span>${sum.mode.startsWith('manual')?'Aggregate editing does not create dated class logs.':'Log exact class occurrences in Today or Timetable.'}</span><div class="attendance-actions">${btn('Manual totals','manual-attendance',`data-id="${esc(s.id)}"`,'btn btn-small btn-quiet')}${btn('Clear manual','clear-manual-attendance',`data-id="${esc(s.id)}"`,'btn btn-small btn-quiet')}</div></div></div>`;}).join(''):emptyState('♟','No subjects to track','Add a subject here or in Timetable. Both pages share the same list.',btn('Add Subjects','manage-subjects','','btn btn-primary btn-small'))}</section><section class="panel panel-pad span-5">${panelHead('Recent class records','Dated attendance history. Marking the same class twice updates one record.')}${logEntries.length?logEntries.slice(0,18).map(([key,r])=>`<div class="simple-row"><span class="stat-icon" style="width:34px;height:34px;font-size:13px">${r.status==='present'?'✓':'×'}</span><div class="task-main"><div class="task-title">${esc(r.subjectName||state.subjects.find(s=>s.id===r.subjectId)?.name||'Removed subject')}</div><div class="task-sub">${esc(fmtDate(r.date,{weekday:'short',month:'short',day:'numeric',year:'numeric'}))} · ${esc(r.className||'Class')}</div></div>${badge(titleCase(r.status),r.status==='present'?'green':'red')}</div>`).join(''):emptyState('▤','No class attendance logged','Use Present or Absent on a class in Today or Timetable to create the first record.')}</section></div>`;
  }
  function openManualAttendance(id) {
    const subj=state.subjects.find(s=>s.id===id);if(!subj)return;
    const manual=state.attendanceManual[id]||{};
    const fields=[{key:'mode',label:'Manual mode',type:'select',options:[['percent','Manual percentage'],['count','Attended / total count']],default:manual.mode||'percent'},
      {key:'percent',label:'Attendance percentage',type:'number',min:0,max:100,step:'0.1',default:manual.percent??''},
      {key:'attended',label:'Attended classes',type:'number',min:0,default:manual.attended??0},
      {key:'total',label:'Total classes',type:'number',min:0,default:manual.total??0}];
    openModal(`Manual totals · ${subj.name}`,'This changes the summary only. It does not create or alter dated class records.',fieldsHtml(fields,manual),'manual-attendance-save','Save manual totals',{id});
  }
  function subjectLabel(value) { return state.subjects.find(s=>s.id===value)?.name || value || 'Subject not set'; }
  function prepareForExam(id) { const exam=state.exams.find(e=>e.id===id);if(!exam)return;const subject=state.subjects.find(s=>s.id===exam.subject)?.name || String(exam.subject||'').trim();navigate('notes');filters.notes=subject;filters.notesSubject=subject;renderPage();const matches=state.notes.filter(n=>String(n.subject||'').trim().toLowerCase()===subject.toLowerCase());toast(matches.length?`Showing notes related to ${subject}.`:`No notes tagged ${subject} yet. Add your notes and set their subject to ${subject}.`,matches.length?'success':'info'); }
  function renderExams() {
    const tab=examTab; const q=(filters.exams||'').toLowerCase();
    const exams=state.exams.filter(e=>`${e.title} ${e.subject||''} ${e.notes||''}`.toLowerCase().includes(q)).sort((a,b)=>(a.dateTime||'9999').localeCompare(b.dateTime||'9999'));
    const syllabus=state.syllabus.filter(e=>`${e.title||e.topic||''} ${e.subject||''} ${e.notes||''}`.toLowerCase().includes(q));
    return `${pageHeader('PREPARE WITH LESS PANIC','Exams & Syllabus','Track exam dates and break the syllabus into topics you can actually finish.',btn(tab==='exams'?'+ Add Exam':'+ Add Syllabus',tab==='exams'?'add-record':'add-syllabus',tab==='exams'?'data-route="exams"':'','btn btn-primary'))}<div class="panel panel-pad">${panelHead('Study planning','Exams and topic completion use your saved records.') }<div class="toolbar"><div class="filter-tabs"><button class="filter-tab ${tab==='exams'?'active':''}" data-action="exam-tab" data-tab="exams">Exams (${state.exams.length})</button><button class="filter-tab ${tab==='syllabus'?'active':''}" data-action="exam-tab" data-tab="syllabus">Syllabus (${state.syllabus.length})</button></div><div class="search-box"><span>⌕</span><input class="form-control" data-filter-route="exams" value="${esc(filters.exams||'')}" placeholder="Search exams or topics…"></div></div>${tab==='exams'?(exams.length?`<div class="record-grid">${exams.map(e=>`<article class="record-card"><div class="record-top"><div><div class="record-title">${esc(e.title)}</div><div class="record-subtitle">${esc(subjectLabel(e.subject))} · ${esc(fmtDateTime(e.dateTime))}</div></div>${badge(e.importance==='critical'?'Critical':e.importance==='important'?'Important':'Normal',e.importance==='critical'?'red':e.importance==='important'?'orange':'')}</div>${e.location?`<div class="record-desc">${esc(e.location)}</div>`:''}${e.notes?`<div class="record-desc">${esc(e.notes)}</div>`:''}<div class="record-meta">${badge(e.dateTime&&new Date(e.dateTime)<new Date()?'Past date':'Upcoming',e.dateTime&&new Date(e.dateTime)<new Date()?'':'blue')}</div><div class="record-actions">${btn('Prepare','prepare-exam',`data-id="${esc(e.id)}"`,'btn btn-small btn-primary')}${btn('Edit','edit-record',`data-route="exams" data-id="${esc(e.id)}"`,'btn btn-small btn-quiet')}${btn('Delete','delete-record',`data-route="exams" data-id="${esc(e.id)}"`,'btn btn-small btn-danger')}</div></article>`).join('')}</div>`:emptyState('▣','No exams saved','Add exam dates and keep useful notes in one place.',btn('+ Add Exam','add-record','data-route="exams"','btn btn-primary btn-small'))):(syllabus.length?`<div class="record-grid">${syllabus.map(s=>`<article class="record-card"><div class="record-top"><div><div class="record-title">${esc(s.topic||s.title||'Untitled topic')}</div><div class="record-subtitle">${esc(s.subject||'Unassigned subject')} · ${esc(s.unit||'No unit set')}</div></div><input type="checkbox" class="task-check" style="width:20px;height:20px" aria-label="Mark topic complete" data-action="toggle-syllabus" data-id="${esc(s.id)}" ${s.completed?'checked':''}></div>${s.notes?`<div class="record-desc">${esc(s.notes)}</div>`:''}${s.url&&M.safeUrl(s.url)?`<a href="${esc(M.safeUrl(s.url))}" target="_blank" rel="noopener noreferrer">Open resource ↗</a>`:''}<div class="record-actions">${badge(s.completed?'Completed':'In progress',s.completed?'green':'')}${btn('Edit','edit-syllabus',`data-id="${esc(s.id)}"`,'btn btn-small btn-quiet')}${btn('Delete','delete-syllabus',`data-id="${esc(s.id)}"`,'btn btn-small btn-danger')}</div></article>`).join('')}</div>`:emptyState('▤','No syllabus topics yet','Add units and topics, then check them off as you learn.',btn('+ Add syllabus item','add-syllabus','','btn btn-primary btn-small')))}</div>`;
  }
  function openSyllabusEditor(id) {
    const item=id?state.syllabus.find(s=>s.id===id):null;
    const fields=[{key:'subject',label:'Subject',type:'subject'}, {key:'unit',label:'Unit / module',placeholder:'Unit 1'}, {key:'topic',label:'Topic',required:true,placeholder:'Topic to study'}, {key:'url',label:'Resource URL',type:'url',full:true}, {key:'notes',label:'Notes',type:'textarea',full:true}];
    openModal(item?'Edit syllabus topic':'Add syllabus topic','Progress is based on the topics you check off.',fieldsHtml(fields,item||{}),item?'syllabus-edit':'syllabus-add',item?'Save topic':'Add topic',{id:item?.id||''});
  }
  function renderTimerPage() {
    const total=durationForMode(timerMode), studyTotal=Object.values(state.progressHistory.studyMinutes).reduce((a,b)=>a+Number(b||0),0);
    return `${pageHeader('DEEP WORK SESSION','Study Timer','One countdown shared across the page and theater view. The planet-and-star scene stays active during focus and breaks.',btn('Timer settings','timer-settings','','btn btn-quiet'))}<div class="workspace-grid"><section class="panel panel-pad focus-widget span-7" style="min-height:470px">${panelHead('Focus room','Pick a mode, press Start, and let the clock do one job.',btn('⚙ Settings','timer-settings','','icon-btn'))}${timerTabs()}${timerRing()}<div class="timer-controls">${btn(timerRunning?'Ⅱ Pause':'▶ Start',timerRunning?'pause-timer':'start-timer','','btn btn-primary')}${btn('↻ Reset','reset-timer','','icon-btn')}${btn('⇥ Skip','skip-timer','','icon-btn')}${btn('⛶ Theater','toggle-theater','','btn btn-quiet')}</div><div class="timer-hint">You can switch tabs or open another page without creating a second timer.</div><div class="divider"></div><div class="inline-actions" style="justify-content:space-between"><span class="status-line"><i></i>${timerRunning?'Timer running':`Ready · ${Math.round(total/60)} minute${total/60===1?'':'s'}`}</span><span class="muted-2 small">Completed focus time: ${studyTotal} minutes</span></div></section><section class="panel panel-pad span-5">${panelHead('A calmer workflow','A few ways to make the timer work for you')}<div class="record-card"><div class="record-title">Focus</div><div class="record-desc">Protect one small block for a single task. Finish the whole block to log the minutes.</div></div><div class="record-card"><div class="record-title">Short break</div><div class="record-desc">Stand up, stretch, get water. Keep the break short enough to return easily.</div></div><div class="record-card"><div class="record-title">Long break</div><div class="record-desc">Use after a longer stretch of work. It is okay to change the durations in Timer settings.</div></div><div class="info-note">The timer runs while this page is open. Browser throttling, sleep, or closing the app may affect it; OMNI-GO does not claim an OS-level alarm.</div></section></div>`;
  }
  function renderFinance() {
    const q=(filters.finance||'').toLowerCase(), rows=state.expenses.filter(e=>`${e.description||''} ${e.category||''} ${e.type||''}`.toLowerCase().includes(q)).sort((a,b)=>(b.date||'').localeCompare(a.date||''));
    const income=state.expenses.filter(e=>e.type==='income').reduce((a,e)=>a+Number(e.amount||0),0), expense=state.expenses.filter(e=>e.type!=='income').reduce((a,e)=>a+Number(e.amount||0),0);
    return `${pageHeader('MONEY, MADE VISIBLE','Finance','A simple organizer for entries you enter yourself. Amounts are shown in Indian Rupees; this is not financial advice.',btn('+ Add entry','add-record','data-route="finance"','btn btn-primary'))}<div class="stat-grid">${statCard('↗','Income',currency(income),'All logged income','finance')}${statCard('↘','Expenses',currency(expense),'All logged expenses','finance')}${statCard('₹','Net',currency(income-expense),'Income minus expenses','finance')}</div><div class="panel panel-pad">${panelHead('Transactions',`${state.expenses.length} saved entries`)}<div class="toolbar"><div class="search-box"><span>⌕</span><input class="form-control" data-filter-route="finance" value="${esc(filters.finance||'')}" placeholder="Search description or category…"></div><select class="form-control" data-action="finance-filter" style="max-width:180px"><option value="all" ${(filters.financeType||'all')==='all'?'selected':''}>All types</option><option value="expense" ${filters.financeType==='expense'?'selected':''}>Expenses</option><option value="income" ${filters.financeType==='income'?'selected':''}>Income</option></select></div>${rows.filter(e=>(filters.financeType||'all')==='all'||e.type===filters.financeType).length?`<div class="table-wrap"><table class="data-table"><thead><tr><th>Date</th><th>Description</th><th>Category</th><th>Type</th><th class="number">Amount</th><th></th></tr></thead><tbody>${rows.filter(e=>(filters.financeType||'all')==='all'||e.type===filters.financeType).map(e=>`<tr><td>${esc(fmtDate(e.date,{month:'short',day:'numeric',year:'numeric'}))}</td><td>${esc(e.description)}</td><td>${esc(e.category||'—')}</td><td>${badge(e.type==='income'?'Income':'Expense',e.type==='income'?'green':'orange')}</td><td class="number">${e.type==='income'?'+':'−'}${esc(currency(e.amount))}</td><td><div class="inline-actions">${btn('Edit','edit-record',`data-route="finance" data-id="${esc(e.id)}"`,'btn btn-small btn-quiet')}${btn('×','delete-record',`data-route="finance" data-id="${esc(e.id)}"`,'btn btn-small btn-danger')}</div></td></tr>`).join('')}</tbody></table></div>`:emptyState('₹','No entries yet','Record a real transaction to start seeing your totals.',btn('+ Add entry','add-record','data-route="finance"','btn btn-primary btn-small'))}</div>`;
  }
  function currency(n) { return new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:2}).format(Number(n)||0); }
  function renderSports() {
    const days=WEEKDAYS, plan=state.gymPlan||{}, templates=[
      {id:'ppl3',label:'Push / Pull / Legs · 3 days',days:['Push','Pull','Legs','Rest','Rest','Rest','Rest']},
      {id:'ppl6',label:'Push / Pull / Legs · 6 days',days:['Push','Pull','Legs','Push','Pull','Legs','Rest']},
      {id:'ul4',label:'Upper / Lower · 4 days',days:['Upper','Lower','Rest','Upper','Lower','Rest','Rest']},
      {id:'fb3',label:'Full Body · 3 days',days:['Full Body','Rest','Full Body','Rest','Full Body','Rest','Rest']},
      {id:'arnold',label:'Arnold split · 6 days',days:['Chest + Back','Shoulders + Arms','Legs','Chest + Back','Shoulders + Arms','Legs','Rest']}
    ];
    const exercises=exerciseLibrary();
    const todayIndex=weekdayIndex(new Date()), todayKey=localDate(), todaysIds=[...new Set(Array.isArray(plan[todayIndex])?plan[todayIndex]:[])], todayCheckin=state.workoutCheckins?.[todayKey]||{checks:{},completed:false}, todaySplit=state.gymDayMuscles[todayIndex]||'';
    const todayNames=todaysIds.map(id=>exercises.find(e=>e.id===id)).filter(Boolean);
    const todayPanel=`<section class="panel panel-pad span-12 today-workout-panel">${panelHead('Today’s workout',`${WEEKDAYS[todayIndex]} · ${esc(todaySplit|| (todaysIds.length?'Planned split':'Rest / no split assigned'))} · ${todaysIds.length} exercise${todaysIds.length===1?'':'s'}`,btn('Edit today’s split','edit-todays-workout','','btn btn-small btn-quiet'))}${todayNames.length?`<div class="today-exercise-list">${todayNames.map((ex,i)=>`<label class="today-exercise-row ${todayCheckin.checks?.[ex.id]?'done':''}"><input type="checkbox" data-action="workout-exercise" data-exercise-id="${esc(ex.id)}" ${todayCheckin.checks?.[ex.id]?'checked':''} ${todayCheckin.completed?'disabled':''}><span class="today-exercise-name"><strong>${esc(ex.name)}</strong><small>${esc(ex.muscle)} · ${esc(ex.sets||'3 sets')} · ${esc(ex.reps||'8–12 reps')}${ex.rest?` · ${esc(ex.rest)} rest`:''}${ex.load?` · ${esc(ex.load)}`:''}</small></span><span class="muted-2 micro">${todayCheckin.checks?.[ex.id]?'DONE':'TODO'}</span></label>`).join('')}</div><div class="today-workout-footer"><span class="muted small">${todayNames.filter(ex=>todayCheckin.checks?.[ex.id]).length} / ${todayNames.length} exercises checked${todayCheckin.completed?` · Completed ${esc(fmtDateTime(todayCheckin.completedAt))}`:''}</span>${todayCheckin.completed?'<button type="button" class="btn btn-quiet" disabled>✓ Workout completed</button>':btn('✓ Complete today’s workout','complete-todays-workout','','btn btn-primary')}</div>`:`<div class="empty-state"><div class="empty-icon">♨</div><h3>${todaySplit&&todaySplit.toLowerCase()==='rest'?'Today is a rest day':'No exercises planned for today'}</h3><p>${todaySplit&&todaySplit.toLowerCase()==='rest'?'Recovery is part of the plan.':`Add exercises to ${WEEKDAYS[todayIndex]} and they’ll appear here as a checklist during your workout.`}</p>${btn('Plan today’s workout','edit-todays-workout','','btn btn-primary btn-small')}</div>`}</section>`;
    return `${pageHeader('TRAIN WITH A PLAN','Sports & Gym','See today’s exercise checklist, tick sets off as you go, and record completion once.',btn('＋ Plan Workout','workout-builder','','btn btn-primary'))}<div class="workspace-grid">${todayPanel}</div><div class="panel panel-pad">${panelHead('Weekly plan','Your planned exercises stay separate from completed workout logs.',btn('Apply split template','workout-template','','btn btn-small btn-quiet'))}<div class="workout-days">${days.map((d,i)=>{const ids=Array.isArray(plan[i])?plan[i]:[];const names=ids.map(id=>exercises.find(e=>e.id===id)?.name||state.customTools.find(e=>e.id===id)?.title).filter(Boolean);const planLabel=state.gymDayMuscles[i]||'';return `<div class="workout-day"><strong>${d}</strong><span>${names.length?esc(names.slice(0,3).join(', '))+(names.length>3?` +${names.length-3}`:''):planLabel?esc(planLabel):'Rest / no plan'}</span><div style="margin-top:8px">${btn('Edit','workout-builder',`data-day="${i}"`,'btn btn-small btn-quiet')}</div></div>`;}).join('')}</div><div class="divider"></div><div class="inline-actions">${btn('Log completed workout','log-workout','','btn btn-primary btn-small')}${btn('Log sports activity','log-sports','','btn btn-small btn-quiet')}${btn('View logs','workout-logs','','btn btn-small btn-quiet')}</div></div>
      <div class="workspace-grid" style="margin-top:14px"><section class="panel panel-pad span-7">${panelHead('Completed workout logs','Only completed logs count toward workout progress.')}${state.workoutLogs.length?state.workoutLogs.slice().sort((a,b)=>(b.date||'').localeCompare(a.date||'')).slice(0,10).map(w=>`<div class="simple-row"><span class="stat-icon" style="width:36px;height:36px">♨</span><div class="task-main"><div class="task-title">${esc(w.title||'Workout')}</div><div class="task-sub">${esc(fmtDate(w.date,{month:'short',day:'numeric',year:'numeric'}))} · ${(w.exerciseNames||[]).length} exercises${w.notes?` · ${esc(w.notes)}`:''}</div></div>${btn('Delete','delete-workout-log',`data-id="${esc(w.id)}"`,'btn btn-small btn-danger')}</div>`).join(''):emptyState('♨','No workouts logged yet','Once you complete a session, record it here. A planned session is not counted as completed.')}</section><section class="panel panel-pad span-5">${panelHead('Sports activity','Keep other sports sessions separate from gym programming.')}${state.sportsLogs.length?state.sportsLogs.slice().sort((a,b)=>(b.date||'').localeCompare(a.date||'')).slice(0,8).map(s=>`<div class="simple-row"><span class="stat-icon" style="width:36px;height:36px">⚑</span><div class="task-main"><div class="task-title">${esc(s.activity)}</div><div class="task-sub">${esc(fmtDate(s.date,{month:'short',day:'numeric'}))}${s.duration?` · ${esc(s.duration)} min`:''}</div></div>${btn('×','delete-sports-log',`data-id="${esc(s.id)}"`,'btn btn-small btn-danger')}</div>`).join(''):emptyState('⚑','No sports logged','Add a real session to build an activity history.',btn('Log activity','log-sports','','btn btn-small btn-primary'))}</section></div><div class="workspace-grid"><section class="panel panel-pad span-12">${panelHead('Exercise library','Select multiple items across muscle groups in the workout builder.')}${Object.entries(groupExercises(exercises)).map(([group,items])=>`<div class="simple-row"><div class="task-main"><div class="task-title">${esc(group)}</div><div class="task-sub">${items.map(e=>esc(e.name)).join(' · ')}</div></div><span class="muted-2 micro">${items.length} exercises</span></div>`).join('')}</section></div><div class="warning-note">Workout templates are general planning aids, not medical advice. Adapt exercises to your equipment, experience, injuries, and recovery. Arnold split includes six training days and should only be used if you can recover well.</div>`;
  }
  function exerciseLibrary() {
    const groups={Chest:['Push-up','Bench Press','Incline Dumbbell Press','Cable Fly'],Back:['Lat Pulldown','One-arm Dumbbell Row','Seated Row','Pull-up'],Shoulders:['Overhead Press','Lateral Raise','Face Pull','Rear Delt Fly'],Arms:['Biceps Curl','Hammer Curl','Triceps Extension','Preacher Curl'],Legs:['Squat','Romanian Deadlift','Lunge','Calf Raise'],Core:['Plank','Crunch','Russian Twist']};
    return Object.entries(groups).flatMap(([muscle,names])=>names.map(name=>{const timed=name==='Plank',special=name==='Crunch'?'12–20 reps':name==='Russian Twist'?'20 total reps':name==='Plank'?'30–60 sec':name==='Push-up'?'8–15 reps':name==='Pull-up'?'Controlled reps':'8–12 reps';return {id:`ex_${name.toLowerCase().replace(/[^a-z0-9]+/g,'_')}`,name,muscle,sets:'3 sets',reps:special,rest:muscle==='Core'?'45–60 sec':(['Lateral Raise','Face Pull','Rear Delt Fly','Cable Fly','Biceps Curl','Hammer Curl','Triceps Extension','Preacher Curl','Calf Raise'].includes(name)?'60 sec':'90 sec'),load:['Push-up','Plank','Crunch','Russian Twist','Pull-up'].includes(name)?'Bodyweight':'Comfortable load'};}));
  }
  function groupExercises(items) { return items.reduce((acc,e)=>{(acc[e.muscle]||(acc[e.muscle]=[])).push(e);return acc;},{}); }
  function openWorkoutBuilder(dayIndex=0) {
    const exercises=exerciseLibrary(), day=Number(dayIndex)||0, current=Array.isArray(state.gymPlan[day])?state.gymPlan[day]:[];
    const fields=`<div class="field"><label class="field-label" for="workoutDay">Workout day</label><select class="form-control" id="workoutDay" name="day">${WEEKDAYS.map((d,i)=>`<option value="${i}" ${day===i?'selected':''}>${d}</option>`).join('')}</select></div><div class="field"><label class="field-label">Select exercises</label><span class="field-help">Choose as many exercises as you need. Save once at the bottom.</span></div><div id="exercisePicker">${Object.entries(groupExercises(exercises)).map(([group,items])=>`<div class="muscle-group"><div class="muscle-group-head">${esc(group)}</div><div class="exercise-options">${items.map(e=>`<label class="exercise-option"><input type="checkbox" name="exerciseIds" value="${esc(e.id)}" ${current.includes(e.id)?'checked':''}><span>${esc(e.name)}</span></label>`).join('')}</div></div>`).join('')}</div><div class="field-grid"><div class="field"><label class="field-label" for="workoutNotes">Session notes (optional)</label><textarea class="form-control" id="workoutNotes" name="notes" rows="2" placeholder="Sets, reps, equipment or notes"></textarea></div><div class="field"><label class="field-label">Current plan</label><div class="info-note">Editing a day replaces only that day when you save. Other days are left untouched.</div></div></div>`;
    openModal('Plan Workout','Bulk-select exercises from the library. The picker stays open until you save or cancel.',fields,'workout-plan-save','Save workout',{day});
  }
  function workoutTemplateDefinitions() {
    const day=(focus,names=[])=>({focus,names});
    return {
      ppl3:{label:'Push / Pull / Legs — 3 days',days:[day('Push · Chest / shoulders / triceps',['Bench Press','Incline Dumbbell Press','Push-up','Overhead Press','Lateral Raise','Triceps Extension']),day('Pull · Back / biceps',['Lat Pulldown','One-arm Dumbbell Row','Seated Row','Face Pull','Biceps Curl','Hammer Curl']),day('Legs · Quads / glutes / core',['Squat','Romanian Deadlift','Lunge','Calf Raise','Plank']),day('Rest'),day('Rest'),day('Rest'),day('Rest')]},
      ppl6:{label:'Push / Pull / Legs — 6 days',days:[day('Push A · Chest / shoulders / triceps',['Bench Press','Incline Dumbbell Press','Push-up','Overhead Press','Lateral Raise','Triceps Extension']),day('Pull A · Back / biceps',['Lat Pulldown','One-arm Dumbbell Row','Seated Row','Face Pull','Biceps Curl','Hammer Curl']),day('Legs A · Lower body / core',['Squat','Romanian Deadlift','Lunge','Calf Raise','Plank']),day('Push B · Chest / shoulders / triceps',['Incline Dumbbell Press','Push-up','Overhead Press','Lateral Raise','Cable Fly','Triceps Extension']),day('Pull B · Back / rear delts / biceps',['Pull-up','One-arm Dumbbell Row','Seated Row','Rear Delt Fly','Hammer Curl','Preacher Curl']),day('Legs B · Lower body / core',['Squat','Romanian Deadlift','Lunge','Calf Raise','Crunch','Russian Twist']),day('Rest')]},
      ul4:{label:'Upper / Lower — 4 days',days:[day('Upper A · Balanced upper body',['Bench Press','Lat Pulldown','Overhead Press','One-arm Dumbbell Row','Biceps Curl','Triceps Extension']),day('Lower A · Lower body / core',['Squat','Romanian Deadlift','Lunge','Calf Raise','Plank']),day('Rest'),day('Upper B · Upper body variation',['Incline Dumbbell Press','Pull-up','Seated Row','Lateral Raise','Face Pull','Hammer Curl']),day('Lower B · Lower body / core',['Squat','Lunge','Romanian Deadlift','Calf Raise','Crunch']),day('Rest'),day('Rest')]},
      fb3:{label:'Full Body — 3 days',days:[day('Full Body A',['Squat','Bench Press','Lat Pulldown','Romanian Deadlift','Overhead Press','Plank']),day('Rest'),day('Full Body B',['Lunge','Incline Dumbbell Press','One-arm Dumbbell Row','Lateral Raise','Biceps Curl','Crunch']),day('Rest'),day('Full Body C',['Squat','Push-up','Seated Row','Romanian Deadlift','Calf Raise','Russian Twist']),day('Rest'),day('Rest')]},
      arnold:{label:'Arnold split — 6 days',days:[day('Chest + Back A',['Bench Press','Incline Dumbbell Press','Cable Fly','Lat Pulldown','One-arm Dumbbell Row','Pull-up']),day('Shoulders + Arms A',['Overhead Press','Lateral Raise','Rear Delt Fly','Biceps Curl','Preacher Curl','Triceps Extension']),day('Legs A',['Squat','Romanian Deadlift','Lunge','Calf Raise','Plank']),day('Chest + Back B',['Incline Dumbbell Press','Push-up','Cable Fly','Seated Row','Lat Pulldown','Pull-up']),day('Shoulders + Arms B',['Overhead Press','Lateral Raise','Face Pull','Hammer Curl','Preacher Curl','Triceps Extension']),day('Legs B',['Squat','Romanian Deadlift','Lunge','Calf Raise','Crunch','Russian Twist']),day('Rest')]}
    };
  }
  function workoutExerciseId(name) { return `ex_${String(name).toLowerCase().replace(/[^a-z0-9]+/g,'_')}`; }
  function templatePreviewMarkup(template) {
    const library=new Set(exerciseLibrary().map(e=>e.id));
    return template.days.map((entry,i)=>{const names=entry.names.filter(name=>library.has(workoutExerciseId(name)));return `<div class="workout-day"><strong>${esc(WEEKDAYS[i])} · ${esc(entry.focus)}</strong><span>${names.length?esc(names.join(' · ')):'Rest / recovery'}</span></div>`;}).join('');
  }
  function openWorkoutTemplate() {
    const templates=workoutTemplateDefinitions(), first=templates.ppl3;
    openModal('Build a full workout split','Templates assign actual exercises to every training day. Every exercise and day remains editable afterward.',`<div class="field-grid"><div class="field full"><label class="field-label" for="splitTemplate">Workout plan</label><select class="form-control" id="splitTemplate" name="template">${Object.entries(templates).map(([key,t])=>`<option value="${key}">${esc(t.label)}</option>`).join('')}</select></div><div class="field full"><label class="field-label" for="splitMode">Apply mode</label><select class="form-control" id="splitMode" name="mode"><option value="merge">Fill empty days and keep existing exercises</option><option value="replace">Replace the entire weekly plan</option></select></div><div class="field full"><div class="info-note">Each training day gets a different group of exercises, not just a muscle-group label. Use Edit on any day afterward to swap exercises, add sets/notes or make the plan fit your equipment.</div></div><div class="field full"><label class="field-label">Weekly workout preview</label><div id="templatePreview" class="workout-days">${templatePreviewMarkup(first)}</div></div></div>`,'workout-template-save','Apply workout plan');
  }
  function renderTools() {
    const custom=state.customTools;
    return `${pageHeader('USEFUL LITTLE UTILITIES','Tools','A safe scientific calculator and your own shortcuts. Calculator input is parsed as math — never executed as JavaScript.',btn('+ Custom tool','add-record','data-route="tools"','btn btn-primary'))}<div class="workspace-grid"><section class="panel panel-pad span-6">${panelHead('Scientific calculator','Keyboard and keypad supported. Trigonometry uses degrees.')}<div class="calculator"><input id="calcDisplay" class="calc-display" type="text" spellcheck="false" autocomplete="off" aria-label="Calculator expression" placeholder="0" value="${esc(calculatorExpression)}"><div id="calcResult" class="calc-result">${esc(calculatorError||calculatorResult||'Type an expression or use the keypad')}</div><div class="calc-keypad">${[['AC','clear'],['⌫','backspace'],['(', 'char'],[')','char'],['7','char'],['8','char'],['9','char'],['÷','op'],['4','char'],['5','char'],['6','char'],['×','op'],['1','char'],['2','char'],['3','char'],['−','op'],['0','char'],['.','char'],['%','char'],['+','op'],['^','char'],['√','func'],['π','const'],['=','equal']].map(([label,kind])=>`<button type="button" class="calc-key ${['÷','×','−','+','^'].includes(label)?'op':''} ${kind==='clear'?'clear':''} ${kind==='equal'?'equal':''}" data-action="calculator-key" data-key="${esc(label)}">${esc(label)}</button>`).join('')}</div><div class="field-help">Functions accepted by typing: sin(x), cos(x), tan(x), sqrt(x), abs(x), log(x), ln(x), pi, e. Percent as a suffix: 25% = 0.25.</div></div></section><section class="panel panel-pad span-6">${panelHead('Your custom tools','Save links or notes to tiny utilities you use often.')}${custom.length?`<div class="record-grid">${custom.map(c=>renderRecordCard('tools',c)).join('')}</div>`:emptyState('⊞','No custom tools yet','Add a named shortcut with an optional safe URL.',btn('+ Custom tool','add-record','data-route="tools"','btn btn-primary btn-small'))}<div class="info-note" style="margin-top:14px">The calculator accepts arithmetic, parentheses, powers, percentage suffixes, constants, and the documented functions. Unknown names and invalid expressions are rejected.</div></section></div>`;
  }
  function evaluateSafeExpression(input) {
    const src=String(input||'').trim(); if(!src)throw new Error('Enter a calculation first.'); if(src.length>180)throw new Error('Expression is too long.');
    const tokens=[];let i=0;
    while(i<src.length){if(/\s/.test(src[i])){i++;continue;}const rem=src.slice(i);let m;
      if((m=rem.match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?/i))){tokens.push({type:'num',value:Number(m[0])});i+=m[0].length;continue;}
      if((m=rem.match(/^[a-zA-Z]+/))){tokens.push({type:'name',value:m[0].toLowerCase()});i+=m[0].length;continue;}
      const c=src[i];if('+-*/^()%'.includes(c)){tokens.push({type:'op',value:c});i++;continue;}throw new Error(`Unsupported character: ${c}`);
    }
    let p=0;const peek=()=>tokens[p],take=()=>tokens[p++];
    function primary(){const t=take();if(!t)throw new Error('Expression ended too early.');let value;
      if(t.type==='num')value=t.value;
      else if(t.type==='name'){
        if(['pi','π'].includes(t.value))value=Math.PI;else if(t.value==='e')value=Math.E;
        else {if(peek()?.value!=='(')throw new Error(`Unknown constant or function: ${t.value}`);take();const x=add();if(take()?.value!==')')throw new Error('Missing closing parenthesis.');const f={sin:x=>Math.sin(x*Math.PI/180),cos:x=>Math.cos(x*Math.PI/180),tan:x=>Math.tan(x*Math.PI/180),sqrt:Math.sqrt,abs:Math.abs,log:Math.log10,ln:Math.log};if(!f[t.value])throw new Error(`Function not supported: ${t.value}`);value=f[t.value](x);}
      } else if(t.value==='('){value=add();if(take()?.value!==')')throw new Error('Missing closing parenthesis.');}else throw new Error('Expected a number or parenthesis.');
      while(peek()?.value==='%'){take();value/=100;}
      if(!Number.isFinite(value))throw new Error('That calculation is outside the supported numeric range.');return value;
    }
    function power(){let a=unary();if(peek()?.value==='^'){take();const b=power();a=Math.pow(a,b);}return a;}
    function unary(){if(peek()?.value==='+'){take();return unary();}if(peek()?.value==='-'){take();return -unary();}return primary();}
    function mul(){let a=power();while(peek()&&['*','/'].includes(peek().value)){const op=take().value,b=power();if(op==='/'&&b===0)throw new Error('Division by zero is undefined.');a=op==='*'?a*b:a/b;}return a;}
    function add(){let a=mul();while(peek()&&['+','-'].includes(peek().value)){const op=take().value,b=mul();a=op==='+'?a+b:a-b;}return a;}
    const answer=add();if(p<tokens.length)throw new Error(`Unexpected token: ${tokens[p].value}`);if(!Number.isFinite(answer))throw new Error('The result is not a finite number.');return Number(answer.toPrecision(12));
  }
  function syncCalculatorUI() { const display=$('#calcDisplay');if(display&&display.value!==calculatorExpression)display.value=calculatorExpression;const result=$('#calcResult');if(result)result.textContent=calculatorError||calculatorResult||'Type an expression or use the keypad'; }
  function calculatorKey(key) {
    calculatorError='';
    if(key==='AC'){calculatorExpression='';calculatorResult='';}
    else if(key==='⌫'){calculatorExpression=calculatorExpression.slice(0,-1);calculatorResult='';}
    else if(key==='='){try{calculatorResult=String(evaluateSafeExpression(calculatorExpression));calculatorError='';}catch(err){calculatorError=err.message;calculatorResult='';}}
    else if(key==='√'){calculatorExpression+='sqrt(';calculatorResult='';}
    else if(key==='π'){calculatorExpression+='pi';calculatorResult='';}
    else {const conv={'÷':'/','×':'*','−':'-'};calculatorExpression+=(conv[key]||key);calculatorResult='';}
    syncCalculatorUI();
  }
  function renderProgressGraph() {
    const keys=['tasks','studyMinutes','habits','attendance','workouts'], labels={tasks:'Tasks completed',studyMinutes:'Study minutes',habits:'Habits checked in',attendance:'Present classes',workouts:'Completed workouts'};
    const dates=[];for(let i=graphRange-1;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);dates.push(localDate(d));}
    const values=dates.map(d=>({date:d,value:Number((state.progressHistory[graphMetric]||{})[d]||0)}));
    const max=Math.max(1,...values.map(v=>v.value));
    return `${pageHeader('REAL RECORDS, REAL PROGRESS','Progress Graph','Charts use data from actual actions. Empty days stay empty; nothing is fabricated.',btn('Open Today','navigate','data-route="today"','btn btn-quiet'))}<div class="panel panel-pad">${panelHead('Choose a metric',`Current range: ${graphRange} days`)}<div class="toolbar"><select class="form-control" data-action="graph-metric" aria-label="Progress metric" style="max-width:240px">${keys.map(k=>`<option value="${k}" ${graphMetric===k?'selected':''}>${labels[k]}</option>`).join('')}</select><div class="filter-tabs">${[7,30,90].map(n=>`<button class="filter-tab ${graphRange===n?'active':''}" data-action="graph-range" data-range="${n}">${n} days</button>`).join('')}</div></div>${values.some(v=>v.value>0)?`<div class="chart-wrap"><div class="chart-bars">${values.map(v=>`<div class="chart-bar-col" title="${esc(v.date)}: ${v.value}"><span class="chart-value">${v.value?esc(v.value):''}</span><div class="chart-bar" style="height:${v.value?Math.max(3,v.value/max*78):2}%"></div></div>`).join('')}</div><div class="chart-labels">${values.map((v,i)=>`<span>${(graphRange<=7||i%Math.ceil(graphRange/7)===0||i===values.length-1)?esc(v.date.slice(5)):''}</span>`).join('')}</div><div class="divider"></div><div class="inline-actions" style="justify-content:space-between"><span class="muted small">${esc(labels[graphMetric])}</span><strong>${values.reduce((a,v)=>a+v.value,0)} total in range</strong></div><div class="table-wrap" style="margin-top:12px"><table class="data-table"><thead><tr><th>Date</th><th class="number">${esc(labels[graphMetric])}</th></tr></thead><tbody>${values.slice().reverse().map(v=>`<tr><td>${esc(fmtDate(v.date,{weekday:'short',month:'short',day:'numeric',year:'numeric'}))}</td><td class="number">${v.value}</td></tr>`).join('')}</tbody></table></div></div>`:emptyState('⌁','No activity recorded for this metric','Complete tasks, focus sessions, habits, attendance, or workouts to start building this graph.',btn('Go to '+({tasks:'Tasks',studyMinutes:'Study Timer',habits:'Habits',attendance:'Attendance',workouts:'Sports & Gym'}[graphMetric]),'navigate',`data-route="${({tasks:'tasks',studyMinutes:'timer',habits:'habits',attendance:'attendance',workouts:'sports'}[graphMetric])}"`,'btn btn-primary btn-small'))}</div>`;
  }
  const PRIVACY_TEXT=`<h3>Local file storage</h3><p>Ordinary workspace entries are stored in data/workspace.json inside the extracted project folder. Each successful save creates a timestamped JSON snapshot in data/backups/. This requires the local Python server and is not cloud sync. My Library file bytes are stored under data/library_files/; note attachments use browser IndexedDB.</p><h3>Device access</h3><p>Data is not encrypted at rest by OMNI-GO. Anyone who can use your unlocked device and browser profile may be able to open this workspace. Do not store passwords or high-risk secrets here.</p><h3>Weather lookup</h3><p>If you enter a city or place in Settings, OMNI-GO sends that text to Open-Meteo's geocoding service and requests current weather for the matched place. Weather lookup needs an internet connection and is not required for the core app. Open-Meteo provides free non-commercial access and weather data under CC BY 4.0; see open-meteo.com for terms and attribution.</p><h3>External links</h3><p>When you choose to open a discovery link or another URL, that third-party website has its own privacy policy and data practices.</p><h3>Backups and deletion</h3><p>Export creates a JSON copy of serializable workspace data. Binary attachments are not included. Reset replaces data/workspace.json with an empty workspace after deliberate confirmation; timestamped backups and My Library file bytes remain until separately removed. Note attachments stay in browser IndexedDB.</p>`;
  const TERMS_TEXT=`<h3>Personal organization use</h3><p>OMNI-GO is a personal planning tool for tasks, study, attendance, reminders, workouts and record keeping. You are responsible for the accuracy of information you enter and for keeping backups.</p><h3>Planning aids</h3><p>Attendance and finance features are organizational calculators. Workout templates are general information, not medical advice. Adapt exercise choices to your circumstances, equipment, experience, and recovery.</p><h3>Third-party content</h3><p>External sites have their own terms. OMNI-GO does not scrape their catalogs or claim that remote progress has been synced automatically.</p><h3>As-is and legal information</h3><p>The application is provided as-is to the extent allowed by applicable law. This plain-language document is a template, not legal advice.</p>`;
  const SECURITY_TEXT=`<h3>Data handling</h3><p>OMNI-GO uses no cloud account. Structured data is saved in the local project folder (data/workspace.json with timestamped copies in data/backups/) and binary library attachments in data/library_files/. Note attachments use browser IndexedDB. Data is not encrypted at rest.</p><h3>Device protection</h3><p>Use your operating-system screen lock and keep browser access restricted. Store backups carefully; exported JSON is readable text.</p><h3>Optional integrations</h3><p>This release serves on 127.0.0.1 only. Its optional game-launch endpoint accepts only user-submitted Windows .exe or .lnk paths and is guarded by local host/origin validation; it does not run arbitrary shell commands. Only use trusted game paths.</p><h3>Distribution</h3><p>An independent security review is recommended before any public or commercial distribution. The included local server is intended for personal local use.</p>`;
  function renderSettings() {
    const corrupt=corruptRaw!==null;
    return `${pageHeader('MAKE IT YOURS','Settings','Preferences, discovery links, data backups, and plain-language policy documents.',btn('Export backup','export-data','','btn btn-primary'))}<div class="workspace-grid"><section class="panel panel-pad span-6">${panelHead('Profile labels','This is a local workspace profile, not an authenticated account.',btn('Edit profile & preferences','edit-settings','','btn btn-small btn-primary'))}<div class="settings-list"><div class="settings-row"><div><strong>Display name</strong><p>${esc(state.profile.name||'Not set')}</p></div></div><div class="settings-row"><div><strong>City / location label</strong><p>${esc(state.profile.city||'Not set')}</p></div></div><div class="settings-row"><div><strong>Focus duration</strong><p>${state.profile.focus} minutes · short break ${state.profile.shortBreak} min · long break ${state.profile.longBreak} min</p></div></div><div class="settings-row"><div><strong>Visual ambience</strong><p>Subtle background glow and page polish.</p></div><input class="toggle" type="checkbox" data-action="setting-toggle" data-setting="ambient" ${state.settings.ambient?'checked':''} aria-label="Toggle ambient decoration"></div><div class="settings-row"><div><strong>Compact display</strong><p>Use denser spacing across the workspace.</p></div><input class="toggle" type="checkbox" data-action="setting-toggle" data-setting="compact" ${state.settings.compact?'checked':''} aria-label="Toggle compact display"></div><div class="settings-row"><div><strong>Reminder alarms</strong><p>When enabled, due reminders ring in the app. No browser notification permission is needed.</p></div><input class="toggle" type="checkbox" data-action="setting-toggle" data-setting="reminders" ${state.settings.reminders?'checked':''} aria-label="Toggle reminder checks"></div></div></section>
      <section class="panel panel-pad span-6">${panelHead('Discovery links','External sites open only after you choose a link.',btn('Edit links','edit-settings','','btn btn-small btn-quiet'))}<div class="settings-list">${[['animeUrl','animeLabel','Anime discovery'],['movieUrl','movieLabel','Movie discovery'],['seriesUrl','seriesLabel','Series discovery']].map(([url,label,desc])=>`<div class="settings-row"><div><strong>${esc(state.discovery[label]||desc)}</strong><p>${state.discovery[url]?`<a href="${esc(M.safeUrl(state.discovery[url])||'#')}" target="_blank" rel="noopener noreferrer">${esc(state.discovery[url])}</a>`:'Not configured'}</p></div>${state.discovery[url]?btn('Open ↗','open-url',`data-url="${esc(M.safeUrl(state.discovery[url])||'')}"`,'btn btn-small btn-quiet'):''}</div>`).join('')}</div><div class="divider"></div><div class="inline-actions">${btn('Open Anime Tracker','navigate','data-route="anime"','btn btn-small btn-quiet')}${btn('Open Movies & Series','navigate','data-route="movies"','btn btn-small btn-quiet')}</div></section></div>
      <div class="workspace-grid"><section class="panel panel-pad span-12">${panelHead('Desktop app behavior','This preference is available in the installed Windows desktop app. The first close asks once, then saves your choice.', '')}<div class="settings-row"><div><strong>When I close OMNI-GO</strong><p id="desktopCloseBehaviorHelp">Choose whether closing the window hides it in the tray or exits completely.</p></div><select class="form-control row-control" id="desktopCloseBehavior" data-action="desktop-close-behavior" aria-label="When I close OMNI-GO"><option value="ask" ${desktopCloseBehavior==='ask'?'selected':''}>Ask me next time</option><option value="tray" ${desktopCloseBehavior==='tray'?'selected':''}>Minimize to system tray</option><option value="quit" ${desktopCloseBehavior==='quit'?'selected':''}>Close app completely</option></select></div></section></div>
      <div class="workspace-grid"><section class="panel panel-pad span-12">${panelHead('Backup & recovery','Export regularly. JSON backups do not include note/library binary attachments.')}<div class="inline-actions">${btn('↓ Export workspace JSON','export-data','','btn btn-primary')}${btn('↑ Import backup','import-data','','btn btn-quiet')}${btn('Reset workspace','reset-workspace','','btn btn-danger')}</div>${corrupt?`<div class="warning-note" style="margin-top:13px"><strong>Saved workspace could not be parsed.</strong> The original value has not been overwritten. Export a raw recovery copy before deliberately starting fresh. ${btn('Export raw recovery copy','export-corrupt','','btn btn-small btn-quiet')} ${btn('Start fresh after backup','start-fresh','','btn btn-small btn-danger')}</div>`:''}<div class="info-note" style="margin-top:13px">Primary workspace data is saved to the local project folder: data/workspace.json. Every save also creates a timestamped copy in data/backups/. Keep this local server running. JSON backups do not include binary note/library attachments; data is not encrypted at rest.</div></section></div>
      <div class="workspace-grid"><section class="panel panel-pad span-12"><details open><summary class="record-title" style="cursor:pointer">Privacy Policy</summary><div class="policy-text">${PRIVACY_TEXT}</div></details><div class="divider"></div><details><summary class="record-title" style="cursor:pointer">Terms of Use</summary><div class="policy-text">${TERMS_TEXT}</div></details><div class="divider"></div><details><summary class="record-title" style="cursor:pointer">Security & Data Policy</summary><div class="policy-text">${SECURITY_TEXT}</div></details></section></div>`;
  }
  async function syncDesktopCloseBehavior(){
    try{if(!window.pywebview?.api?.get_close_behavior)return;const value=await window.pywebview.api.get_close_behavior();if(['ask','tray','quit'].includes(value))desktopCloseBehavior=value;const select=$('#desktopCloseBehavior');if(select)select.value=desktopCloseBehavior;const help=$('#desktopCloseBehaviorHelp');if(help)help.textContent='Closing the window follows this saved choice. Choosing Ask me next time shows the native prompt on the next close.';}catch(_){const help=$('#desktopCloseBehaviorHelp');if(help)help.textContent='Available only in the installed Windows desktop app; browser mode cannot control the system tray.';}
  }
  window.addEventListener('pywebviewready',syncDesktopCloseBehavior);
  setTimeout(syncDesktopCloseBehavior,800);
  function openSettingsEditor() {
    const fields=[
      {key:'name',label:'Display name',default:state.profile.name||''},{key:'city',label:'City / location label',default:state.profile.city||'',help:'Enter a city or place name to show current weather on Today. Weather lookup sends this text to Open-Meteo; internet is required.'},
      {key:'birthday',label:'Birthday (optional)',type:'date',default:state.profile.birthday||''},{key:'email',label:'Email label (optional)',type:'email',default:state.profile.email||''},
      {key:'phone',label:'Phone label (optional)',type:'tel',default:state.profile.phone||''},
      {key:'focus',label:'Focus minutes',type:'number',min:1,max:180,default:state.profile.focus},
      {key:'shortBreak',label:'Short break minutes',type:'number',min:1,max:60,default:state.profile.shortBreak},
      {key:'longBreak',label:'Long break minutes',type:'number',min:1,max:120,default:state.profile.longBreak},
      {key:'animeLabel',label:'Anime discovery label',default:state.discovery.animeLabel,group:'Discovery links'},
      {key:'animeUrl',label:'Anime discovery URL',type:'url',default:state.discovery.animeUrl||''},
      {key:'movieLabel',label:'Movie discovery label',default:state.discovery.movieLabel},
      {key:'movieUrl',label:'Movie discovery URL',type:'url',default:state.discovery.movieUrl||''},
      {key:'seriesLabel',label:'Series discovery label',default:state.discovery.seriesLabel},
      {key:'seriesUrl',label:'Series discovery URL',type:'url',default:state.discovery.seriesUrl||''}
    ];
    openModal('Profile, timer & discovery','Only labels and preferences are saved here. Discovery links must be full HTTP(S) URLs.',fieldsHtml(fields,{...state.profile,...state.discovery}),'settings-save','Save preferences');
  }
  function fieldsHtml(fields,values={}) {
    let html='<div class="field-grid">'; let currentGroup='';
    for(const f of fields){
      if(f.group && f.group!==currentGroup){html+=`<div class="field full"><div class="panel-eyebrow" style="margin-top:7px">${esc(f.group)}</div></div>`;currentGroup=f.group;}
      let val=values[f.key]!==undefined&&values[f.key]!==null?values[f.key]:(f.default!==undefined?f.default:'');
      if(f.type==='datetime-local'&&val){const d=parseDate(val);if(d&&!Number.isNaN(d.getTime()))val=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}T${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;}
      const full=f.full?' full':'';const label=`<label class="field-label" for="field-${esc(f.key)}">${esc(f.label)}${f.required?' *':''}</label>`;let control='';
      if(f.type==='textarea')control=`<textarea class="form-control" id="field-${esc(f.key)}" name="${esc(f.key)}" rows="4" ${f.required?'required':''} placeholder="${esc(f.placeholder||'')}">${esc(val)}</textarea>`;
      else if(f.type==='select')control=`<select class="form-control" id="field-${esc(f.key)}" name="${esc(f.key)}" ${f.required?'required':''}>${(f.options||[]).map(o=>`<option value="${esc(o[0])}" ${String(val)===String(o[0])?'selected':''}>${esc(o[1])}</option>`).join('')}</select>`;
      else if(f.type==='subject')control=`<select class="form-control" id="field-${esc(f.key)}" name="${esc(f.key)}"><option value="">(Not assigned)</option>${state.subjects.map(s=>`<option value="${esc(s.id)}" ${String(val)===String(s.id)?'selected':''}>${esc(s.name)}</option>`).join('')}</select>`;
      else if(f.type==='checkbox')control=`<label class="checkbox-field"><input type="checkbox" id="field-${esc(f.key)}" name="${esc(f.key)}" ${val?'checked':''}> ${esc(f.checkboxLabel||f.label)}</label>`;
      else {const type=f.type||'text'; const step=f.step||((type==='number'&&f.min===0.01)?'0.01':undefined);control=`<input class="form-control" id="field-${esc(f.key)}" name="${esc(f.key)}" type="${esc(type)}" value="${esc(val)}" ${f.required?'required':''} ${f.min!==undefined?`min="${esc(f.min)}"`:''} ${f.max!==undefined?`max="${esc(f.max)}"`:''} ${step?`step="${esc(step)}"`:''} ${f.placeholder?`placeholder="${esc(f.placeholder)}"`:''} ${f.maxlength?`maxlength="${esc(f.maxlength)}"`:''}>`; }
      html+=`<div class="field${full}">${label}${control}${f.help?`<span class="field-help">${esc(f.help)}</span>`:''}</div>`;
    }
    html+='</div>';return html;
  }
  function openModal(title,subtitle,body,kind,submitLabel='Save',data={}) {
    modalReturnFocus=document.activeElement;modalDirty=false;
    // Lock the document behind the dialog so wheel/touch input cannot scroll the page.
    if(!document.documentElement.classList.contains('modal-scroll-lock'))modalScrollY=window.scrollY||window.pageYOffset||0;
    document.documentElement.classList.add('modal-scroll-lock');document.body.classList.add('modal-scroll-lock');
    const extraAttrs=Object.entries(data||{}).map(([k,v])=>`data-${k.replace(/[A-Z]/g,m=>'-'+m.toLowerCase())}="${esc(v)}"`).join(' ');
    $('#modalRoot').innerHTML=`<div class="modal-backdrop" data-action="modal-backdrop"><section class="modal-card" role="dialog" aria-modal="true" aria-labelledby="modalTitle"><header class="modal-head"><div><h2 id="modalTitle">${esc(title)}</h2><p>${esc(subtitle||'')}</p></div><button type="button" class="modal-close" data-action="close-modal" aria-label="Close dialog">×</button></header><form data-modal-form="${esc(kind)}" ${extraAttrs}><div class="modal-body">${body}</div><footer class="modal-foot"><button type="button" class="btn btn-quiet" data-action="close-modal">Cancel</button><button type="submit" class="btn btn-primary">${esc(submitLabel)}</button></footer></form></section></div>`;
    const first=$('#modalRoot input:not([type=hidden]), #modalRoot textarea, #modalRoot select'); if(first)first.focus();
  }
  function openRecordEditor(route,id='',quick=false) {
    const collection=COLLECTION[route];if(!collection||!SCHEMAS[route])return;
    const record=id?(state[collection]||[]).find(r=>r.id===id):null;if(id&&!record)return;
    let fields=SCHEMAS[route];
    let body=fieldsHtml(fields,record||{});
    if(route==='notes')body+=`<div class="field" style="margin-top:14px"><label class="field-label" for="noteAttachments">Attachments (optional)</label><input class="form-control" type="file" id="noteAttachments" name="attachments" multiple><span class="field-help">Note attachments use browser storage and are not included in JSON backups.</span></div>`;
    if(route==='library')body+=`<div class="field full" style="margin-top:14px"><label class="field-label" for="libraryAttachments">Upload files (optional)</label><input class="form-control" type="file" id="libraryAttachments" name="libraryAttachments" multiple accept=".pdf,.doc,.docx,.odt,.rtf,.txt,.md,.csv,.xls,.xlsx,.ppt,.pptx,.png,.jpg,.jpeg,.gif,.webp,.bmp,.mp4,.webm,.mov,.m4v"><span class="field-help">Documents, images and videos are stored in OMNI-GO/data/library_files on this PC (50 MB per file). Keep that folder when backing up or moving the project.</span></div>`;
    if(route==='games')body+=`<div class="info-note" style="margin-top:12px">Enter a full Windows .exe or .lnk path when adding or editing a game. Press Play to launch it. OMNI-GO only sends a launch request after you click Play; the local Windows server validates the path and never runs arbitrary shell commands. This will be unavailable on non-Windows systems.</div>`;
    if(route==='anime' && !state.discovery.animeUrl)body+=`<div class="info-note" style="margin-top:12px">Anime discovery is not configured. Add a URL under Settings when you decide which site to use.</div>`;
    if(quick&&route==='notes')body=fieldsHtml([{key:'title',label:'Quick note',required:true,placeholder:'What do you want to remember?'},{key:'body',label:'Note',type:'textarea',full:true,placeholder:'Write it down now…'}],{});
    openModal(record?`Edit ${ROUTES[route].label.slice(0,-1)||ROUTES[route].label}`:`Add ${route==='finance'?'finance entry':route==='courses'?'course':route==='movies'?'movie or series':route==='tools'?'custom tool':route==='library'?'library item':route==='anime'?'anime title':route==='games'?'game':route==='habits'?'habit':route==='notes'?'note':route==='tasks'?'task':route==='reminders'?'reminder':'record'}`,route==='tasks'?'A task should describe a clear next action.':route==='reminders'?'Pick a date and time. Repeating reminders keep completed occurrences in your history.':route==='library'?'Attach documents, images and videos to this item. Files are saved to the project folder.':'Saved in your local OMNI-GO workspace.',body,'record-save',record?'Save changes':'Save',{route,id:record?.id||''});
  }
  function closeModal(force=false) {
    if(!$('#modalRoot').innerHTML)return;
    if(modalDirty&&!force&&!window.confirm('Discard unsaved changes in this dialog?'))return;
    $('#modalRoot').innerHTML='';modalDirty=false;
    document.documentElement.classList.remove('modal-scroll-lock');document.body.classList.remove('modal-scroll-lock');
    window.scrollTo(0,modalScrollY);
    if(modalReturnFocus&&document.contains(modalReturnFocus))modalReturnFocus.focus();
  }
  function recordSubmit(form) {
    const route=form.dataset.route,collection=COLLECTION[route];if(!collection)return;
    const oldId=form.dataset.id||'', existing=(state[collection]||[]).find(r=>r.id===oldId);
    const fd=new FormData(form), values={};
    for(const f of SCHEMAS[route]){
      let v=fd.get(f.key);if(v==null)v='';if(typeof v==='string')v=v.trim();
      if(f.required&&!String(v).trim())throw new Error(`${f.label} is required.`);
      if(f.type==='number'&&v!==''){v=Number(v);if(!Number.isFinite(v))throw new Error(`${f.label} must be a number.`);if(f.min!==undefined&&v<f.min)throw new Error(`${f.label} must be at least ${f.min}.`);if(f.max!==undefined&&v>f.max)throw new Error(`${f.label} must be no more than ${f.max}.`);}
      if(f.type==='url'&&v){const safe=M.safeUrl(v);if(!safe)throw new Error(`${f.label} must be a valid HTTP(S) URL.`);v=safe;}
      values[f.key]=v;
    }
    if(route==='finance'&&Number(values.amount)<=0)throw new Error('Amount must be greater than zero.');
    if(route==='reminders'&&(!values.dueAt||!parseDate(values.dueAt)))throw new Error('Choose a valid reminder date and time.');
    if(route==='exams'&&(!values.dateTime||!parseDate(values.dateTime)))throw new Error('Choose a valid exam date and time.');
    const now=new Date().toISOString();
    let obj={...(existing||{}),...values,id:existing?.id||M.id(route),createdAt:existing?.createdAt||now,updatedAt:now};
    if(route==='tasks'){obj.completed=existing?.completed||false;obj.completedAt=existing?.completedAt||'';}
    if(route==='reminders'){obj.completed=existing?.completed||false;obj.completedAt=existing?.completedAt||'';obj.seriesId=existing?.seriesId||obj.id;obj.nextCreated=existing?.nextCreated||false;obj.notificationSent=existing?.notificationSent||false;obj.occurrenceId=existing?.occurrenceId||obj.id;}
    if(route==='habits'){obj.completedDates=Array.isArray(existing?.completedDates)?existing.completedDates:[];obj.active=true;}
    if(route==='notes'){obj.attachments=Array.isArray(existing?.attachments)?existing.attachments:[];}
    if(route==='anime'){obj.watched=Math.max(0,Number(obj.watched||0));obj.total=obj.total===''?null:Math.max(0,Number(obj.total||0));}
    if(route==='courses')obj.progress=Math.max(0,Math.min(100,Number(obj.progress||0)));
    if(route==='finance')obj.amount=Number(obj.amount);
    const files=route==='notes'?Array.from(form.querySelector('#noteAttachments')?.files||[]):[];
    const libraryFiles=route==='library'?Array.from(form.querySelector('#libraryAttachments')?.files||[]):[];
    if(libraryFiles.some(file=>file.size>50*1024*1024))throw new Error('Each library file must be 50 MB or smaller.');
    const doSave=async()=>{
      const newAttachments=[], uploadedLibraryFiles=[];
      try{
        for(const file of files){const aid=M.id('attachment');const attachment={id:aid,ownerId:obj.id,name:file.name,type:file.type||'application/octet-stream',size:file.size,createdAt:now,blob:file};await S.putAttachment(attachment);newAttachments.push({id:aid,name:file.name,type:file.type||'application/octet-stream',size:file.size,createdAt:now});}
        for(const file of libraryFiles){const ext=file.name.split('.').pop().toLowerCase();const allowed=['pdf','doc','docx','odt','rtf','txt','md','csv','xls','xlsx','ppt','pptx','png','jpg','jpeg','gif','webp','bmp','mp4','webm','mov','m4v'];if(!allowed.includes(ext))throw new Error(`Unsupported file type: ${file.name}`);const aid=M.id('libfile');const url=`/api/library-file?id=${encodeURIComponent(aid)}&name=${encodeURIComponent(file.name)}`;const response=await fetch(url,{method:'PUT',headers:{'Content-Type':file.type||'application/octet-stream'},body:file});if(!response.ok)throw new Error(`${file.name}: upload failed (HTTP ${response.status}).`);uploadedLibraryFiles.push(await response.json());}
      }catch(err){for(const a of newAttachments){try{await S.deleteAttachment(a.id);}catch(_){}}for(const a of uploadedLibraryFiles){try{await fetch(`/api/library-file?id=${encodeURIComponent(a.id)}`,{method:'DELETE'});}catch(_){}}throw new Error(`Attachment could not be saved: ${err.message}`);}
      if(route==='notes'&&newAttachments.length)obj.attachments=[...(obj.attachments||[]),...newAttachments];
      if(route==='library'&&uploadedLibraryFiles.length)obj.attachments=[...(obj.attachments||[]),...uploadedLibraryFiles];
      const ok=commit(draft=>{
        const arr=draft[collection],idx=arr.findIndex(r=>r.id===obj.id);if(idx>=0)arr[idx]=obj;else arr.unshift(obj);
        if(route==='tasks'&&!existing&&obj.completed)M.addProgress(draft,'tasks',localDate(),1);
        M.recordActivity(draft,existing?'updated':'created',`${existing?'Updated':'Added'} ${titleForRecord(route,obj)}`);
      },`${titleForRecord(route,obj)} ${existing?'updated':'saved'}.`);
      if(!ok){for(const a of newAttachments){try{await S.deleteAttachment(a.id);}catch(_){}}for(const a of uploadedLibraryFiles){try{await fetch(`/api/library-file?id=${encodeURIComponent(a.id)}`,{method:'DELETE'});}catch(_){}}return;}
      closeModal(true);
    };
    return doSave();
  }
  function titleForRecord(route,obj) { return obj.title||obj.description||obj.topic||({finance:'finance entry',notes:'note',habits:'habit',reminders:'reminder',tasks:'task'}[route])||ROUTES[route]?.label||'record'; }
  function formDataObject(form) { const fd=new FormData(form), out={};for(const [k,v] of fd.entries())if(!(v instanceof File))out[k]=typeof v==='string'?v.trim():v;return out; }
  async function handleModalSubmit(form) {
    const kind=form.dataset.modalForm;
    try {
      if(kind==='attachment-list') { closeModal(true); return; }
      if(kind==='record-save') { await recordSubmit(form); return; }
      if(kind==='add-subjects') {
        const raw=String(new FormData(form).get('names')||'');const names=raw.split(/[\n,;]+/).map(n=>n.trim()).filter(Boolean);if(!names.length)throw new Error('Enter at least one subject name.');
        const added=[];const updated=commit(draft=>{const seen=new Set(draft.subjects.map(s=>s.name.trim().toLocaleLowerCase()));for(const name of names){const key=name.toLocaleLowerCase();if(seen.has(key))continue;seen.add(key);const now=new Date().toISOString();draft.subjects.push({id:M.id('subject'),name,createdAt:now,updatedAt:now});added.push(name);}M.recordActivity(draft,'subjects',`Added ${added.length} subject${added.length===1?'':'s'}`);},'Subject list saved.');if(updated){closeModal(true);if(!added.length)toast('No new subjects were needed; duplicates were skipped.','info');}return;
      }
      if(kind==='subject-edit') {
        const name=String(new FormData(form).get('name')||'').trim();if(!name)throw new Error('Subject name is required.');const id=form.dataset.id;
        if(state.subjects.some(s=>s.id!==id&&s.name.trim().toLocaleLowerCase()===name.toLocaleLowerCase()))throw new Error('A subject with that name already exists.');
        const ok=commit(draft=>{const s=draft.subjects.find(x=>x.id===id);if(!s)throw new Error('Subject no longer exists.');s.name=name;s.updatedAt=new Date().toISOString();draft.timetable.forEach(c=>{if(c.subjectId===id)c.subjectName=name;});Object.values(draft.attendanceLog).forEach(r=>{if(r.subjectId===id)r.subjectName=name;});M.recordActivity(draft,'subjects',`Renamed subject to ${name}`);},'Subject renamed.');if(ok)closeModal(true);return;
      }
      if(kind==='class-add'||kind==='class-edit') {
        const v=formDataObject(form), id=form.dataset.id||'';if(!v.subjectId)throw new Error('Choose a subject.');if(!v.start||!v.end||v.end<=v.start)throw new Error('End time must be later than start time.');const subj=state.subjects.find(s=>s.id===v.subjectId);if(!subj)throw new Error('That subject is no longer available.');v.day=Number(v.day);v.classType=v.classType||'Lecture';
        const other=state.timetable.filter(c=>c.id!==id).find(c=>{
          const sameDay = v.date ? (c.date ? c.date===v.date : Number(c.day)===weekdayIndex(new Date(`${v.date}T12:00:00`))) : (!c.date&&Number(c.day)===v.day);
          return sameDay && v.start<c.end && v.end>c.start;
        });if(other&&!window.confirm(`This time overlaps with ${classSubject(other)} (${fmtTime(other.start)}–${fmtTime(other.end)}). Save anyway?`))return;
        const now=new Date().toISOString();const item={...(state.timetable.find(c=>c.id===id)||{}),...v,id:id||M.id('class'),subjectName:subj.name,createdAt:state.timetable.find(c=>c.id===id)?.createdAt||now,updatedAt:now};
        const ok=commit(draft=>{const idx=draft.timetable.findIndex(c=>c.id===item.id);if(idx>=0)draft.timetable[idx]=item;else draft.timetable.push(item);draft.timetable.sort((a,b)=>Number(a.day)-Number(b.day)||String(a.start).localeCompare(String(b.start)));M.recordActivity(draft,'timetable',`${idx>=0?'Updated':'Added'} class: ${subj.name}`);},'Class saved.');if(ok)closeModal(true);return;
      }
      if(kind==='manual-attendance-save') {
        const v=formDataObject(form), id=form.dataset.id;if(v.mode==='percent'){const p=Number(v.percent);if(v.percent===''||!Number.isFinite(p)||p<0||p>100)throw new Error('Percentage must be from 0 to 100.');}else{const attended=Number(v.attended),total=Number(v.total);if(!Number.isInteger(attended)||!Number.isInteger(total)||attended<0||total<0||attended>total)throw new Error('Counts must be non-negative whole numbers, and attended cannot exceed total.');}
        const ok=commit(draft=>{draft.attendanceManual[id]=v.mode==='percent'?{mode:'percent',percent:Number(v.percent)}:{mode:'count',attended:Number(v.attended),total:Number(v.total)};M.recordActivity(draft,'attendance','Updated manual attendance totals');},'Manual attendance totals saved.');if(ok)closeModal(true);return;
      }
      if(kind==='settings-save') {
        const v=formDataObject(form);for(const k of ['animeUrl','movieUrl','seriesUrl'])if(v[k]&&!M.safeUrl(v[k]))throw new Error(`${k.replace('Url','')} discovery must be a valid HTTP(S) URL.`);
        const focus=Number(v.focus),shortBreak=Number(v.shortBreak),longBreak=Number(v.longBreak);if(focus<1||focus>180||shortBreak<1||shortBreak>60||longBreak<1||longBreak>120)throw new Error('Timer durations must be within their supported ranges.');
        const ok=commit(draft=>{draft.profile={...draft.profile,name:v.name||'',city:v.city||'',birthday:v.birthday||'',email:v.email||'',phone:v.phone||'',focus,shortBreak,longBreak};draft.discovery={animeUrl:M.safeUrl(v.animeUrl)||'',animeLabel:v.animeLabel||'Anime discovery',movieUrl:M.safeUrl(v.movieUrl)||'',movieLabel:v.movieLabel||'Movie discovery',seriesUrl:M.safeUrl(v.seriesUrl)||'',seriesLabel:v.seriesLabel||'Series discovery'};timerMode='focus';if(!timerRunning)timerRemaining=durationForMode('focus');M.recordActivity(draft,'settings','Updated profile and preferences');},'Settings saved.');if(ok){closeModal(true);loadWeatherForCity(v.city||'',true);}return;
      }
      if(kind==='syllabus-add'||kind==='syllabus-edit') {
        const v=formDataObject(form);if(!v.topic)throw new Error('Topic is required.');if(v.url&&!M.safeUrl(v.url))throw new Error('Resource URL must be a valid HTTP(S) URL.');const id=form.dataset.id||'',old=state.syllabus.find(s=>s.id===id),now=new Date().toISOString();const item={...old,...v,id:id||M.id('syllabus'),createdAt:old?.createdAt||now,updatedAt:now,completed:old?.completed||false};const ok=commit(d=>{const i=d.syllabus.findIndex(s=>s.id===item.id);if(i>=0)d.syllabus[i]=item;else d.syllabus.unshift(item);M.recordActivity(d,'syllabus',`${old?'Updated':'Added'} topic: ${item.topic}`);},'Syllabus topic saved.');if(ok)closeModal(true);return;
      }
      if(kind==='workout-plan-save') {
        const fd=new FormData(form),day=Number(fd.get('day')),exerciseIds=fd.getAll('exerciseIds').map(String),notes=String(fd.get('notes')||'').trim();const known=new Set(exerciseLibrary().map(e=>e.id));if(exerciseIds.some(id=>!known.has(id)))throw new Error('An exercise was not recognized.');const dedup=[...new Set(exerciseIds)];const ok=commit(d=>{d.gymPlan[day]=dedup;d.gymDayMuscles[day]=notes||((dedup.length&&(!d.gymDayMuscles[day]||String(d.gymDayMuscles[day]).toLowerCase()==='rest'))?'Workout':(!dedup.length&&String(d.gymDayMuscles[day]||'').toLowerCase()==='workout'?'Rest':(d.gymDayMuscles[day]||'')));M.recordActivity(d,'workout-plan',`Planned workout for ${WEEKDAYS[day]}`);},'Workout plan saved.');if(ok)closeModal(true);return;
      }
      if(kind==='workout-template-save') {
        const v=formDataObject(form),definition=workoutTemplateDefinitions()[v.template];if(!definition)throw new Error('Choose a valid workout plan.');if(v.mode==='replace'&&!window.confirm('Replace will clear all current weekly exercise assignments and apply this complete plan. Continue?'))return;
        const known=new Set(exerciseLibrary().map(e=>e.id));
        const ok=commit(d=>{d.gymPlan=d.gymPlan||{};d.gymDayMuscles=d.gymDayMuscles||{};for(let i=0;i<7;i++){const planIds=definition.days[i].names.map(workoutExerciseId).filter(id=>known.has(id));const current=Array.isArray(d.gymPlan[i])?d.gymPlan[i]:[];if(v.mode==='replace'||current.length===0)d.gymPlan[i]=[...new Set(planIds)];d.gymDayMuscles[i]=definition.days[i].focus;}M.recordActivity(d,'workout-template',`Applied ${definition.label} (${v.mode})`);},'Full workout plan applied. Every training day has exercises assigned.');if(ok)closeModal(true);return;
      }
            if(kind==='workout-log-save') {
        const fd=new FormData(form),title=String(fd.get('title')||'').trim()||'Workout',date=String(fd.get('date')||localDate()),notes=String(fd.get('notes')||'').trim(),ids=fd.getAll('exerciseIds').map(String),library=exerciseLibrary();const names=ids.map(id=>library.find(e=>e.id===id)?.name).filter(Boolean);const item={id:M.id('workout'),title,date,notes,exerciseIds:ids,exerciseNames:names,createdAt:new Date().toISOString()};const ok=commit(d=>{d.workoutLogs.unshift(item);M.addProgress(d,'workouts',date,1);M.recordActivity(d,'workout',`Logged workout: ${title}`,date);},'Completed workout logged.');if(ok)closeModal(true);return;
      }
      if(kind==='sports-log-save') {
        const v=formDataObject(form);if(!v.activity)throw new Error('Activity is required.');const item={...v,id:M.id('sports'),duration:v.duration?Number(v.duration):0,createdAt:new Date().toISOString()};const ok=commit(d=>{d.sportsLogs.unshift(item);M.recordActivity(d,'sports',`Logged ${item.activity}`,item.date);},'Sports activity logged.');if(ok)closeModal(true);return;
      }
      if(kind==='import-confirm') {
        if(!pendingImport)throw new Error('No import is waiting for confirmation.');const replacement=pendingImport;S.save(replacement);state=replacement;pendingImport=null;persistenceBlocked=false;corruptRaw=null;closeModal(true);refreshShell();renderPage();toast('Workspace imported. Existing local records were replaced.');return;
      }
      if(kind==='reset-confirm') {
        const typed=String(new FormData(form).get('confirmation')||'');if(typed!=='RESET')throw new Error('Type RESET exactly to confirm.');localStorage.removeItem(S.KEY);state=M.defaultState();S.save(state);pendingImport=null;corruptRaw=null;persistenceBlocked=false;closeModal(true);navigate('today');toast('Workspace reset. The local data for this origin has been removed.');return;
      }
      toast('This form is not available.','error');
    } catch(err) { console.error(err);toast(err.message||'Could not save.','error'); }
  }
  function openWorkoutLogModal() {
    const planIds=[...new Set(Object.values(state.gymPlan).flat())],items=exerciseLibrary();
    openModal('Log a completed workout','Only a completed session belongs here; your planned routine is kept separately.',`<div class="field-grid"><div class="field"><label class="field-label" for="workoutTitle">Session title</label><input class="form-control" name="title" id="workoutTitle" value="Workout" required></div><div class="field"><label class="field-label" for="workoutDate">Date</label><input class="form-control" type="date" name="date" id="workoutDate" value="${localDate()}" required></div><div class="field full"><label class="field-label">Exercises completed</label><div class="exercise-options">${items.map(e=>`<label class="exercise-option"><input type="checkbox" name="exerciseIds" value="${e.id}" ${planIds.includes(e.id)?'':''}><span>${esc(e.name)} <small class="muted">· ${esc(e.muscle)}</small></span></label>`).join('')}</div></div><div class="field full"><label class="field-label" for="workoutLogNotes">Notes</label><textarea class="form-control" id="workoutLogNotes" name="notes" rows="3" placeholder="Sets, reps, load, or how it felt"></textarea></div></div>`,'workout-log-save','Save completed workout');
  }
  function openSportsLogModal() {
    openModal('Log sports activity','Keep sports sessions separate from gym workout programming.',`<div class="field-grid"><div class="field"><label class="field-label" for="sportsActivity">Activity</label><input class="form-control" id="sportsActivity" name="activity" required placeholder="Kabaddi, running, football…"></div><div class="field"><label class="field-label" for="sportsDate">Date</label><input class="form-control" id="sportsDate" type="date" name="date" value="${localDate()}" required></div><div class="field"><label class="field-label" for="sportsDuration">Duration (minutes)</label><input class="form-control" id="sportsDuration" type="number" name="duration" min="0" max="1440"></div><div class="field full"><label class="field-label" for="sportsNotes">Notes</label><textarea class="form-control" id="sportsNotes" name="notes" rows="3"></textarea></div></div>`,'sports-log-save','Save activity');
  }
  function markDailyAttendance(date,status) {
    if(!/^\d{4}-\d{2}-\d{2}$/.test(String(date||''))) { toast('Choose a valid date first.','error'); return; }
    if(date>localDate()) { toast('Daily attendance can only be marked for today or an earlier date.','error'); return; }
    if(!['present','absent','holiday'].includes(status))return;
    commit(d=>{d.dailyAttendance=d.dailyAttendance||{};d.dailyAttendance[date]={date,status,updatedAt:new Date().toISOString()};M.recordActivity(d,'daily-attendance',`Marked ${date} as ${status}`,date);},`Daily attendance marked ${status}.`);
  }
  function clearDailyAttendance(date) {
    if(!state.dailyAttendance?.[date])return;
    commit(d=>{delete d.dailyAttendance[date];M.recordActivity(d,'daily-attendance',`Cleared daily attendance marker for ${date}`,date);},'Daily attendance marker cleared.');
  }
  function toggleWorkoutExercise(exerciseId,checked) {
    const day=weekdayIndex(new Date()), planned=Array.isArray(state.gymPlan[day])?state.gymPlan[day]:[];
    if(!planned.includes(exerciseId)){toast('This exercise is not in today’s planned workout.','error');return;}
    const date=localDate(), prior=state.workoutCheckins?.[date]||{};
    if(prior.completed){toast('Today’s workout is already marked completed.','info');return;}
    commit(d=>{d.workoutCheckins=d.workoutCheckins||{};const item=d.workoutCheckins[date]||{date,day,checks:{},completed:false,completedAt:'',logId:''};item.checks=item.checks||{};if(checked)item.checks[exerciseId]=true;else delete item.checks[exerciseId];d.workoutCheckins[date]=item;},checked?'Exercise checked off.':'Exercise unchecked.');
  }
  function completeTodaysWorkout() {
    const date=localDate(), day=weekdayIndex(new Date()), ids=[...new Set(Array.isArray(state.gymPlan[day])?state.gymPlan[day]:[])];
    if(!ids.length){toast('There are no exercises planned for today. Add exercises to today’s split first.','info');return;}
    const existing=state.workoutCheckins?.[date]||{};if(existing.completed){toast('Today’s workout is already marked completed.','info');return;}
    const checked=ids.filter(id=>existing.checks?.[id]), remaining=ids.length-checked.length;
    if(remaining&&!window.confirm(`${remaining} planned exercise(s) are still unchecked. Mark today’s workout complete anyway? Only checked exercises will be included in the completed-workout log.`))return;
    const library=exerciseLibrary(), names=checked.map(id=>library.find(e=>e.id===id)?.name).filter(Boolean), logId=M.id('workout');
    const ok=commit(d=>{d.workoutCheckins=d.workoutCheckins||{};const item=d.workoutCheckins[date]||{date,day,checks:{}};if(item.completed)return;item.completed=true;item.completedAt=new Date().toISOString();item.logId=logId;d.workoutCheckins[date]=item;d.workoutLogs.unshift({id:logId,title:state.gymDayMuscles[day]||`${WEEKDAYS[day]} workout`,date,notes:`Daily workout check-in · ${checked.length}/${ids.length} exercises checked`,exerciseIds:checked,exerciseNames:names,createdAt:new Date().toISOString()});M.addProgress(d,'workouts',date,1);M.recordActivity(d,'workout',`Completed today’s workout (${checked.length}/${ids.length} exercises)`,date);},'Today’s workout marked completed.');
    if(ok)toast(`${checked.length} of ${ids.length} exercises recorded in your workout log.`, 'success');
  }
  async function launchGame(id) {
    const game=state.games.find(g=>g.id===id);if(!game)return;
    const path=String(game.localPath||'').trim();if(!path){toast('Edit this game and add its .exe or .lnk path first.','info');openRecordEditor('games',id);return;}
    if(!window.confirm(`Launch ${game.title} from this local path?\n\n${path}`))return;
    try{
      const response=await fetch('/api/launch-game',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path})});
      const data=await response.json().catch(()=>({}));
      if(!response.ok||!data.ok)throw new Error(data.reason||`Launch request failed (HTTP ${response.status}).`);
      toast(`Launch request sent for ${game.title}.`, 'success');
    }catch(err){toast(`Could not launch game: ${err.message}`, 'error');}
  }
  function markAttendance(classId,date,status) {
    const cls=state.timetable.find(c=>c.id===classId);if(!cls)return;
    const key=`${classId}|${date}`,prior=state.attendanceLog[key];if(prior?.status===status){toast(`Already marked ${status}.`,'info');return;}
    commit(d=>{d.attendanceLog[key]={id:prior?.id||M.id('attendance'),classId,subjectId:cls.subjectId,subjectName:classSubject(cls),className:cls.classType||'Class',date,status,createdAt:prior?.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()};if(prior?.status==='present')M.addProgress(d,'attendance',date,-1);if(status==='present')M.addProgress(d,'attendance',date,1);M.recordActivity(d,'attendance',`Marked ${classSubject(cls)} ${status}`,date);},`Marked ${classSubject(cls)} ${status}.`);
  }
  function toggleTask(id) {
    const task=state.tasks.find(t=>t.id===id);if(!task)return;const nextComplete=!task.completed;
    commit(d=>{const t=d.tasks.find(x=>x.id===id);t.completed=nextComplete;t.completedAt=nextComplete?new Date().toISOString():'';t.updatedAt=new Date().toISOString();M.addProgress(d,'tasks',localDate(),nextComplete?1:-1);M.recordActivity(d,'task',`${nextComplete?'Completed':'Reopened'} task: ${t.title}`);},nextComplete?'Task completed.':'Task reopened.');
  }
  function toggleHabit(id) {
    const date=localDate(),habit=state.habits.find(h=>h.id===id);if(!habit)return;const done=(habit.completedDates||[]).includes(date);
    commit(d=>{const h=d.habits.find(x=>x.id===id);h.completedDates=Array.isArray(h.completedDates)?h.completedDates:[];h.completedDates=done?h.completedDates.filter(x=>x!==date):[...h.completedDates,date];M.addProgress(d,'habits',date,done?-1:1);M.recordActivity(d,'habit',`${done?'Unchecked':'Checked in'} habit: ${h.title}`,date);},done?'Habit check-in undone.':'Habit checked in.');
  }
  function completeReminder(id) {
    const r=state.reminders.find(x=>x.id===id);if(!r||r.completed)return;
    commit(d=>{const item=d.reminders.find(x=>x.id===id);item.completed=true;item.completedAt=new Date().toISOString();item.updatedAt=new Date().toISOString();if(item.repeat&&item.repeat!=='none'&&!item.nextCreated&&item.dueAt){const due=new Date(item.dueAt);due.setDate(due.getDate()+(item.repeat==='daily'?1:7));const next={...item,id:M.id('reminder'),dueAt:due.toISOString(),completed:false,completedAt:'',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),nextCreated:false,notificationSent:false,occurrenceId:M.id('occurrence'),parentOccurrenceId:item.id,seriesId:item.seriesId||item.id};item.nextCreated=true;d.reminders.unshift(next);}M.recordActivity(d,'reminder',`Completed reminder: ${item.title}`);},'Reminder completed.');
  }
  function toggleReminder(id) {
    const r=state.reminders.find(x=>x.id===id);if(!r)return;
    commit(d=>{const item=d.reminders.find(x=>x.id===id);item.completed=!item.completed;item.completedAt=item.completed?new Date().toISOString():'';item.updatedAt=new Date().toISOString();M.recordActivity(d,'reminder',`${item.completed?'Completed':'Reopened'} reminder: ${item.title}`);},r.completed?'Reminder reopened.':'Reminder completed.');
  }
  function snoozeReminder(id) {
    const r=state.reminders.find(x=>x.id===id);if(!r||r.completed)return;const base=parseDate(r.dueAt)||new Date();base.setMinutes(base.getMinutes()+10);
    commit(d=>{const item=d.reminders.find(x=>x.id===id);item.dueAt=base.toISOString();item.notificationSent=false;item.updatedAt=new Date().toISOString();M.recordActivity(d,'reminder',`Snoozed reminder: ${item.title}`);},'Reminder snoozed by 10 minutes.');
  }
  function deleteRecord(route,id) {
    const collection=COLLECTION[route];if(!collection)return;const record=(state[collection]||[]).find(r=>r.id===id);if(!record)return;
    if(!window.confirm(`Delete “${titleForRecord(route,record)}”? This cannot be undone. Export a backup first if you may need it.`))return;
    const ok=commit(d=>{d[collection]=d[collection].filter(r=>r.id!==id);M.recordActivity(d,'deleted',`Deleted ${titleForRecord(route,record)}`);},'Record deleted.');
    if(!ok)return;
    if(route==='notes'&&record.attachments?.length)record.attachments.forEach(a=>S.deleteAttachment(a.id).catch(console.warn));
    if(route==='library'&&record.attachments?.length)record.attachments.forEach(a=>fetch(`/api/library-file?id=${encodeURIComponent(a.id)}`,{method:'DELETE'}).catch(err=>console.warn('Could not remove library file:',err)));
  }
  function deleteSubject(id) {
    const s=state.subjects.find(x=>x.id===id);if(!s)return;
    const classes=state.timetable.filter(c=>c.subjectId===id).length, logs=Object.values(state.attendanceLog).filter(r=>r.subjectId===id).length;
    const message=`Remove subject “${s.name}”? ${classes} timetable class(es) and ${logs} attendance log(s) will be preserved as historical records. The subject will no longer be available in new class builders.`;
    if(!window.confirm(message))return;
    commit(d=>{d.subjects=d.subjects.filter(x=>x.id!==id);d.timetable.forEach(c=>{if(c.subjectId===id)c.subjectName=s.name;});M.recordActivity(d,'subjects',`Removed subject: ${s.name}`);},'Subject removed; class and attendance history preserved.');
  }
  function deleteClass(id) {
    const c=state.timetable.find(x=>x.id===id);if(!c)return;
    const related=Object.values(state.attendanceLog).filter(r=>r.classId===id).length;
    if(!window.confirm(`Delete this class from the timetable? ${related} existing attendance log(s) will be preserved.`))return;
    commit(d=>{d.timetable=d.timetable.filter(x=>x.id!==id);M.recordActivity(d,'timetable',`Removed class: ${classSubject(c)}`);},'Class removed; attendance history preserved.');
  }
  function deleteSyllabus(id) {
    const item=state.syllabus.find(s=>s.id===id);if(!item||!window.confirm(`Delete topic “${item.topic||item.title}”?`))return;
    commit(d=>{d.syllabus=d.syllabus.filter(s=>s.id!==id);M.recordActivity(d,'syllabus',`Deleted topic: ${item.topic||item.title}`);},'Syllabus topic deleted.');
  }
  function deleteActivityLog(kind,id) {
    const arrKey=kind==='workout'?'workoutLogs':'sportsLogs',item=state[arrKey].find(x=>x.id===id);if(!item||!window.confirm(`Delete this ${kind==='workout'?'workout':'sports'} log?`))return;
    commit(d=>{d[arrKey]=d[arrKey].filter(x=>x.id!==id);if(kind==='workout'){M.addProgress(d,'workouts',item.date,-1);const checkin=d.workoutCheckins?.[item.date];if(checkin?.logId===id){checkin.completed=false;checkin.completedAt='';checkin.logId='';}}M.recordActivity(d,'deleted',`Deleted ${kind} log`);},'Log deleted.');
  }
  function toggleSyllabus(id) {
    commit(d=>{const item=d.syllabus.find(s=>s.id===id);if(!item)return;item.completed=!item.completed;item.updatedAt=new Date().toISOString();M.recordActivity(d,'syllabus',`${item.completed?'Completed':'Reopened'} topic: ${item.topic||item.title}`);},'Syllabus progress updated.');
  }
  function startTimer() {
    if(timerRunning)return;if(timerRemaining<=0)timerRemaining=durationForMode(timerMode);timerRunning=true;timerDeadline=Date.now()+timerRemaining*1000;
    if(timerInterval)clearInterval(timerInterval);timerInterval=setInterval(tickTimer,250);syncTimerUI();toast('Timer started.','success');
  }
  function pauseTimer() { if(!timerRunning)return;timerRemaining=Math.max(0,Math.ceil((timerDeadline-Date.now())/1000));timerRunning=false;if(timerInterval)clearInterval(timerInterval);timerInterval=null;syncTimerUI();toast('Timer paused.','info'); }
  function resetTimer() { timerRunning=false;if(timerInterval)clearInterval(timerInterval);timerInterval=null;timerRemaining=durationForMode(timerMode);syncTimerUI();if(currentRoute==='timer'||currentRoute==='today')renderPage();toast('Timer reset.','info'); }
  function switchTimerMode(mode) { if(!['focus','short','long'].includes(mode))return;timerRunning=false;if(timerInterval)clearInterval(timerInterval);timerInterval=null;timerMode=mode;timerRemaining=durationForMode(mode);refreshTheaterVisualMode();syncTimerUI();if(currentRoute==='timer'||currentRoute==='today')renderPage(); }
  function skipTimer() { const next=timerMode==='focus'?'short':timerMode==='short'?'focus':'focus';switchTimerMode(next);toast('Moved to the next timer mode.','info'); }
  function tickTimer() {
    if(!timerRunning)return;timerRemaining=Math.max(0,Math.ceil((timerDeadline-Date.now())/1000));syncTimerUI();
    if(timerRemaining<=0){timerRunning=false;if(timerInterval)clearInterval(timerInterval);timerInterval=null;const completedMode=timerMode;if(completedMode==='focus'){const minutes=Number(state.profile.focus)||25;commit(d=>{M.addProgress(d,'studyMinutes',localDate(),minutes);M.recordActivity(d,'focus',`Completed a ${minutes}-minute focus session`);},`Focus complete — ${minutes} minutes logged.`);}else toast('Break complete. Ready when you are.','success');timerMode=completedMode==='focus'?'short':'focus';timerRemaining=durationForMode(timerMode);if(currentRoute==='timer'||currentRoute==='today')renderPage();else syncTimerUI();}
  }
  function syncTimerUI() {
    const digits=$('#timerDigits');if(digits)digits.textContent=formatTimer(timerRemaining);
    refreshTheaterVisualMode();const ring=$('.timer-ring');if(ring){const total=durationForMode(timerMode),pct=Math.max(0,Math.min(100,((total-timerRemaining)/total)*100));ring.style.setProperty('--timer-progress',`${pct}%`);}
    const primary=$('.timer-controls [data-action="start-timer"], .timer-controls [data-action="pause-timer"]');if(primary){primary.dataset.action=timerRunning?'pause-timer':'start-timer';primary.textContent=timerRunning?'Ⅱ Pause':'▶ Start';}
  }
  function ensureTheaterVisual() {
    if(theaterCanvas)return;
    const host=document.createElement('div');host.className='theater-backdrop';host.id='theaterBackdrop';host.setAttribute('aria-hidden','true');
    theaterCanvas=document.createElement('canvas');theaterCanvas.id='theaterBackdropCanvas';host.appendChild(theaterCanvas);
    const shell=document.querySelector('.app-shell');(shell||document.body).prepend(host);theaterCtx=theaterCanvas.getContext('2d');
    theaterPointer={x:-1000,y:-1000,down:false};
    resizeTheaterCanvas();window.addEventListener('resize',resizeTheaterCanvas);
    theaterStars=Array.from({length:210},()=>({x:Math.random(),y:Math.random(),r:.25+Math.random()*1.15,tw:Math.random()*6.28,speed:.000012+Math.random()*.000075,drift:(Math.random()-.5)*.000035,blue:Math.random()>.36}));
    // The entire planet is painted procedurally with Canvas; no wallpaper/photo is loaded.
    // Soft, narrow clouds create a layered atmosphere without random continent-shaped blobs.
    theaterSurfaceForms=Array.from({length:118},()=>({
      x:.015+Math.random()*.97,y:.025+Math.random()*.93,
      rx:.018+Math.random()*.095,ry:.0025+Math.random()*.012,
      rotation:(Math.random()-.5)*.16,alpha:.012+Math.random()*.055,
      kind:'cloud',phase:Math.random()*6.28
    }));
    // Fine ocean grain is also generated in code and slowly drifts with the surface.
    theaterOceanGrain=Array.from({length:460},()=>({
      x:.015+Math.random()*.97,y:.04+Math.random()*.92,
      length:.5+Math.random()*4.2,thickness:.25+Math.random()*.65,
      alpha:.018+Math.random()*.075,phase:Math.random()*6.28,
      speed:.12+Math.random()*.65,bright:Math.random()>.72
    }));
    theaterShootingStars=[];theaterNextShootingAt=performance.now()+1000+Math.random()*2200;
    if(!theaterEventsBound){
      document.addEventListener('pointermove',e=>{if(timerTheater){theaterPointer.x=e.clientX;theaterPointer.y=e.clientY;}});
      document.addEventListener('click',e=>{if(timerTheater&&!e.target.closest('.focus-widget button,.focus-widget input,.focus-widget select,.focus-widget a')){theaterPointer.x=e.clientX;theaterPointer.y=e.clientY;}});
      theaterEventsBound=true;
    }
    drawTheaterFrame();
  }
  function resizeTheaterCanvas(){if(!theaterCanvas)return;const dpr=Math.min(window.devicePixelRatio||1,2);theaterCanvas.width=Math.round(window.innerWidth*dpr);theaterCanvas.height=Math.round(window.innerHeight*dpr);theaterCanvas.style.width=`${window.innerWidth}px`;theaterCanvas.style.height=`${window.innerHeight}px`;theaterCtx?.setTransform(dpr,0,0,dpr,0,0);}
  function refreshTheaterVisualMode(){if(theaterCanvas)theaterCanvas.dataset.mode='procedural-planet';}
  function drawProceduralPlanet(ctx,w,h,t,reduced){
    const cx=w*.5,topY=h*.535,radius=Math.max(w*.9,h*.84),cy=topY+radius;
    const inset=Math.min(.999,w/(2*radius)),spread=Math.asin(inset),leftAngle=Math.PI+spread,rightAngle=Math.PI*2-spread;
    const drawHorizon=()=>{ctx.beginPath();ctx.arc(cx,cy,radius,leftAngle,rightAngle);};
    // A deep, almost-black sky with a restrained cobalt nebula.
    const sky=ctx.createLinearGradient(0,0,0,h);sky.addColorStop(0,'#020308');sky.addColorStop(.42,'#030814');sky.addColorStop(.7,'#061020');sky.addColorStop(1,'#010208');ctx.fillStyle=sky;ctx.fillRect(0,0,w,h);
    const nebula=ctx.createRadialGradient(w*(.49+(reduced?0:Math.sin(t*.09)*.018)),h*.60,0,w*.5,h*.57,Math.max(w,h)*.72);nebula.addColorStop(0,'rgba(18,70,135,.18)');nebula.addColorStop(.42,'rgba(12,43,92,.095)');nebula.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=nebula;ctx.fillRect(0,0,w,h);
    // Draw the planetary surface as a large clipped circle.
    ctx.save();ctx.beginPath();ctx.arc(cx,cy,radius,leftAngle,rightAngle);ctx.lineTo(w+2,h+2);ctx.lineTo(-2,h+2);ctx.closePath();ctx.clip();
    const sea=ctx.createLinearGradient(0,topY-10,0,h*1.06);sea.addColorStop(0,'#c5e7ff');sea.addColorStop(.012,'#4fb9ff');sea.addColorStop(.032,'#0c5ba9');sea.addColorStop(.09,'#0c5889');sea.addColorStop(.22,'#073b6e');sea.addColorStop(.47,'#05254b');sea.addColorStop(.72,'#03162f');sea.addColorStop(1,'#010711');ctx.fillStyle=sea;ctx.fillRect(0,topY-20,w,h-topY+50);
    const lightX=theaterPointer.x>-500&&!reduced?theaterPointer.x:cx-w*.12;
    const lightY=theaterPointer.y>-500&&!reduced?Math.max(topY,Math.min(h,theaterPointer.y)):topY+h*.12;
    const oceanLight=ctx.createRadialGradient(lightX,lightY,2,cx,cy,radius*1.15);oceanLight.addColorStop(0,'rgba(116,207,255,.34)');oceanLight.addColorStop(.22,'rgba(29,135,223,.16)');oceanLight.addColorStop(.66,'rgba(7,51,103,.08)');oceanLight.addColorStop(1,'rgba(0,0,8,.58)');ctx.fillStyle=oceanLight;ctx.fillRect(0,topY-20,w,h-topY+50);
    // Wispy cloud structures move slowly over the ocean. Everything below is drawn with Canvas APIs.
    for(const form of theaterSurfaceForms){
      const drift=reduced?0:Math.sin(t*.13+form.phase)*w*.0035;
      const fx=form.x*w+drift,fy=topY+form.y*(h-topY+radius*.05),rx=form.rx*w,ry=form.ry*h;
      ctx.save();ctx.translate(fx,fy);ctx.rotate(form.rotation+(reduced?0:Math.sin(t*.08+form.phase)*.009));
      const cloud=ctx.createRadialGradient(-rx*.2,-ry*.15,1,0,0,Math.max(rx,ry)*1.25);
      cloud.addColorStop(0,`rgba(220,244,255,${form.alpha*1.8})`);cloud.addColorStop(.35,`rgba(113,190,231,${form.alpha*1.15})`);cloud.addColorStop(1,'rgba(10,79,142,0)');
      ctx.fillStyle=cloud;ctx.beginPath();ctx.ellipse(0,0,rx,ry,0,0,Math.PI*2);ctx.fill();ctx.restore();
    }
    // Subtle moving flecks add a fine, ocean-like texture without using a raster image.
    for(const grain of theaterOceanGrain){
      const drift=reduced?0:Math.sin(t*grain.speed+grain.phase)*w*.0018;
      const gx=grain.x*w+drift,gy=topY+grain.y*(h-topY+radius*.05);
      ctx.beginPath();ctx.moveTo(gx,gy);ctx.lineTo(gx+grain.length,gy+grain.thickness*.35);
      ctx.strokeStyle=grain.bright?`rgba(173,224,255,${grain.alpha*.72})`:`rgba(37,135,190,${grain.alpha})`;ctx.lineWidth=grain.thickness;ctx.stroke();
    }
    // Fine curved ocean-current lines make the sphere feel textured without a bitmap.
    ctx.globalAlpha=1;for(let i=0;i<82;i++){
      const base=topY+(h-topY)*(i/82),amp=1.5+(i/82)*7,phase=i*.71+(reduced?0:t*.11),drift=reduced?0:t*(.6+(i%7)*.13);
      ctx.beginPath();ctx.moveTo(-20,base);
      for(let seg=1;seg<=10;seg++){const x=-20+(w+40)*seg/10;const y=base+Math.sin(seg*.72+phase+drift*.012)*amp+Math.sin(seg*.22+phase*.3)*amp*.45;ctx.lineTo(x,y);}
      ctx.strokeStyle=i<13?`rgba(177,229,255,${.08+(13-i)*.008})`:`rgba(54,151,210,${.018+(i%5)*.009})`;ctx.lineWidth=i<4?1.05:.45;ctx.stroke();
    }
    // Darken the limb and deepen the lower part of the planet.
    const limb=ctx.createLinearGradient(0,topY,0,h);limb.addColorStop(0,'rgba(201,239,255,.06)');limb.addColorStop(.18,'rgba(3,27,56,.02)');limb.addColorStop(.68,'rgba(0,3,14,.40)');limb.addColorStop(1,'rgba(0,1,7,.82)');ctx.fillStyle=limb;ctx.fillRect(0,topY-20,w,h-topY+50);ctx.restore();
    // Atmospheric rim: a cool blue arc plus a much finer icy highlight.
    const pulse=reduced?0.5:.5+.5*Math.sin(t*.7);ctx.save();drawHorizon();ctx.strokeStyle=`rgba(24,111,255,${.5+pulse*.3})`;ctx.lineWidth=5;ctx.shadowBlur=30;ctx.shadowColor='#167dff';ctx.stroke();ctx.shadowBlur=0;drawHorizon();ctx.strokeStyle=`rgba(135,224,255,${.72+pulse*.22})`;ctx.lineWidth=1.2;ctx.stroke();drawHorizon();ctx.strokeStyle='rgba(232,248,255,.36)';ctx.lineWidth=.55;ctx.stroke();ctx.restore();
    // A faint radial horizon bloom adds depth behind the star layer.
    const bloom=ctx.createRadialGradient(cx,topY,0,cx,topY,Math.max(w*.46,h*.55));bloom.addColorStop(0,'rgba(51,147,255,.10)');bloom.addColorStop(.3,'rgba(25,101,227,.045)');bloom.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=bloom;ctx.fillRect(0,0,w,h);
  }
  function drawTheaterFrame(){
    if(!theaterCanvas||!theaterCtx||!timerTheater)return;
    const ctx=theaterCtx,w=window.innerWidth,h=window.innerHeight;
    const reduced=state.settings.reducedMotion==='reduce'||window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const t=reduced?0:performance.now()*.001;
    drawProceduralPlanet(ctx,w,h,t,reduced);
    const planetRadius=Math.max(w*.9,h*.84),planetTop=h*.535,planetCy=planetTop+planetRadius,planetCx=w*.5;
    for(const star of theaterStars){
      if(!reduced){star.x+=star.drift;star.y-=star.speed*.42;if(star.x>1)star.x=0;if(star.x<0)star.x=1;if(star.y<0)star.y=1;}
      const pulse=.22+.78*(.5+.5*Math.sin(t*1.6+star.tw)),x=star.x*w,y=star.y*h,dx=x-planetCx;
      // Keep stars in open space instead of drawing them over the planet's surface.
      const horizonY=planetCy-Math.sqrt(Math.max(0,planetRadius*planetRadius-dx*dx));if(y>horizonY-1)continue;
      ctx.beginPath();ctx.arc(x,y,star.r*(.72+pulse*.55),0,Math.PI*2);ctx.fillStyle=star.blue?`rgba(95,190,255,${.24+pulse*.68})`:`rgba(235,247,255,${.18+pulse*.72})`;ctx.fill();
      if(star.r>1.05&&pulse>.9){ctx.strokeStyle=`rgba(160,220,255,${pulse*.30})`;ctx.lineWidth=.5;ctx.beginPath();ctx.moveTo(x-3,y);ctx.lineTo(x+3,y);ctx.moveTo(x,y-3);ctx.lineTo(x,y+3);ctx.stroke();}
    }
    if(!reduced&&performance.now()>theaterNextShootingAt){theaterShootingStars.push({x:Math.random()*w*.85,y:Math.random()*h*.44,vx:4+Math.random()*5,vy:1.5+Math.random()*2.5,life:0,max:26+Math.random()*18});theaterNextShootingAt=performance.now()+2600+Math.random()*4800;}
    ctx.globalCompositeOperation='lighter';
    for(const star of theaterShootingStars){star.x+=star.vx;star.y+=star.vy;star.life++;const alpha=Math.max(0,1-star.life/star.max);ctx.beginPath();ctx.moveTo(star.x,star.y);ctx.lineTo(star.x-star.vx*5.5,star.y-star.vy*5.5);ctx.strokeStyle=`rgba(128,210,255,${alpha*.82})`;ctx.lineWidth=1.2;ctx.shadowBlur=9;ctx.shadowColor='#58baff';ctx.stroke();}
    theaterShootingStars=theaterShootingStars.filter(s=>s.life<s.max);ctx.shadowBlur=0;
    if(theaterPointer.x>-500){const radius=190,g=ctx.createRadialGradient(theaterPointer.x,theaterPointer.y,0,theaterPointer.x,theaterPointer.y,radius);g.addColorStop(0,'rgba(90,165,255,.10)');g.addColorStop(.35,'rgba(65,120,255,.04)');g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.fillRect(theaterPointer.x-radius,theaterPointer.y-radius,radius*2,radius*2);}
    ctx.globalCompositeOperation='source-over';theaterFrame=requestAnimationFrame(drawTheaterFrame);
  }
  function stopTheaterVisual(){if(theaterFrame)cancelAnimationFrame(theaterFrame);theaterFrame=0;theaterCanvas?.parentElement?.remove();theaterCanvas=null;theaterCtx=null;theaterStars=[];theaterShootingStars=[];theaterSurfaceForms=[];theaterOceanGrain=[];window.removeEventListener('resize',resizeTheaterCanvas);}
  function toggleTheater() {
    timerTheater=!timerTheater;document.body.classList.toggle('timer-theater',timerTheater);
    // The timer dock is positioned by the theater layout; never scroll the page behind it.
    if(timerTheater){ensureTheaterVisual();refreshTheaterVisualMode();}
    else{document.body.classList.remove('timer-theater');stopTheaterVisual();}
    if(currentRoute!=='timer'&&currentRoute!=='today'){navigate('timer');}
    syncTimerUI();
  }
  function openTimerSettings() {
    const fields=[{key:'focus',label:'Focus duration (minutes)',type:'number',min:1,max:180,default:state.profile.focus},{key:'shortBreak',label:'Short break (minutes)',type:'number',min:1,max:60,default:state.profile.shortBreak},{key:'longBreak',label:'Long break (minutes)',type:'number',min:1,max:120,default:state.profile.longBreak}];
    openModal('Timer settings','The same moving planet-and-star scene stays in the background for focus and breaks.',fieldsHtml(fields,state.profile),'timer-settings-save','Save timer settings');
  }
  function openSearch() {
    $('#searchRoot').innerHTML=`<div class="search-overlay" data-action="close-search"><section class="search-dialog" role="dialog" aria-modal="true" aria-label="Universal search"><div class="search-dialog-head"><span>⌕</span><input id="universalSearch" type="search" placeholder="Search pages, tasks, notes, subjects…" autocomplete="off"><kbd>ESC</kbd></div><div id="searchResults" class="search-results">${searchResultsHtml('')}</div><div class="search-foot"><span>Search saved local data</span><span><kbd>↑</kbd><kbd>↓</kbd> navigate · <kbd>Enter</kbd> open · <kbd>Esc</kbd> close</span></div></section></div>`;
    const input=$('#universalSearch');input.focus();
  }
  function searchResults(query) {
    const q=query.toLowerCase().trim(), out=[];
    NAV.forEach(g=>g.items.forEach(([key,icon,label])=>{if(!q||label.toLowerCase().includes(q))out.push({route:key,icon,title:label,category:'Page',sub:'Open workspace page'});}));
    const collections=[['tasks','tasks','Task','☷'],['reminders','reminders','Reminder','◷'],['notes','notes','Note','▤'],['timetable','timetable','Class','▦'],['attendance','subjects','Subject','♟'],['habits','habits','Habit','◇'],['exams','exams','Exam','▣'],['exams','syllabus','Syllabus topic','▤'],['courses','coursesOnline','Course','⌘'],['library','library','Library item','▣'],['anime','anime','Anime','✦'],['movies','movies','Movie / series','▣'],['games','games','Game','♧'],['finance','expenses','Finance entry','₹'],['tools','customTools','Custom tool','⊞']];
    for(const [route,col,cat,icon] of collections){for(const r of state[col]||[]){const title=r.title||r.topic||r.description||r.activity||'';const text=Object.values(r).filter(v=>typeof v==='string'||typeof v==='number').join(' ').toLowerCase();if(!q||text.includes(q))out.push({route,icon,title:title||cat,category:cat,sub:r.subject||r.category||r.provider||r.status||r.description||'',id:r.id});}}
    for(const c of state.timetable){const text=`${classSubject(c)} ${c.room||''} ${c.classType||''} ${c.start||''} ${c.end||''} ${WEEKDAYS[c.day]||''}`.toLowerCase();if(!q||text.includes(q))out.push({route:'timetable',icon:'▦',title:classSubject(c),category:'Class',sub:`${c.date||WEEKDAYS[c.day]} · ${c.start||''}–${c.end||''} · ${c.room||''}`,id:c.id});}
    return out.slice(0,40);
  }
  function searchResultsHtml(query) {
    const results=searchResults(query);if(!results.length)return `<div class="search-empty">No matches found. Try another word.</div>`;
    return results.map((r,i)=>`<button class="search-result ${i===0?'active':''}" data-action="search-open" data-route="${esc(r.route)}" ${r.id?`data-id="${esc(r.id)}"`:''} data-index="${i}"><span class="result-symbol">${esc(r.icon)}</span><span class="result-main"><span class="result-title">${esc(r.title)}</span><span class="result-sub">${esc(r.sub||'')}</span></span><span class="result-category">${esc(r.category)}</span></button>`).join('');
  }
  let searchActiveIndex=0;
  function updateSearchResults() { const input=$('#universalSearch');if(!input)return;$('#searchResults').innerHTML=searchResultsHtml(input.value);searchActiveIndex=0; }
  function closeSearch(){ $('#searchRoot').innerHTML=''; }
  function unlockAlarmAudio() {
    try {
      if (!alarmAudioContext) alarmAudioContext = new (window.AudioContext || window.webkitAudioContext)();
      if (alarmAudioContext.state === 'suspended') alarmAudioContext.resume().catch(()=>{});
    } catch (_) {}
  }
  document.addEventListener('pointerdown', unlockAlarmAudio, {once:true, passive:true});
  document.addEventListener('keydown', unlockAlarmAudio, {once:true});
  function playAlarmPing() {
    try {
      unlockAlarmAudio(); if(!alarmAudioContext || alarmAudioContext.state!=='running')return;
      const ctx=alarmAudioContext, osc=ctx.createOscillator(), gain=ctx.createGain(), now=ctx.currentTime;
      osc.type='sine';osc.frequency.setValueAtTime(880,now);osc.frequency.exponentialRampToValueAtTime(660,now+.24);
      gain.gain.setValueAtTime(.0001,now);gain.gain.exponentialRampToValueAtTime(.22,now+.025);gain.gain.setValueAtTime(.16,now+.16);gain.gain.exponentialRampToValueAtTime(.0001,now+.48);
      osc.connect(gain);gain.connect(ctx.destination);osc.start(now);osc.stop(now+.5);
    } catch (_) {}
  }
  function startAlarmSound() { stopAlarmSound();playAlarmPing();alarmSoundInterval=setInterval(playAlarmPing,1200); }
  function stopAlarmSound() { if(alarmSoundInterval)clearInterval(alarmSoundInterval);alarmSoundInterval=null; }
  function testAlarmSound() { playAlarmPing();setTimeout(playAlarmPing,350);setTimeout(playAlarmPing,700);toast('Alarm sound test played. Your system volume controls the level.','info'); }
  function saveReminderNotified(id) {
    const next=clone(state), item=next.reminders.find(r=>r.id===id);if(!item)return;
    item.notificationSent=true;item.updatedAt=new Date().toISOString();
    state=M.normalizeState(next);S.save(state);refreshShell();
  }
  function showNextReminderAlarm() {
    if(activeReminderAlarm)return;
    while(reminderAlarmQueue.length){
      const queued=reminderAlarmQueue.shift(), r=state.reminders.find(item=>item.id===queued.id);
      if(!r||r.completed||r.dueAt!==queued.dueAt||new Date(r.dueAt).getTime()>Date.now()||r.notificationSent)continue;
      activeReminderAlarm={id:r.id,key:queued.key};
      const root=$('#alarmRoot');if(!root)return;
      root.innerHTML=`<div class="alarm-overlay" role="alertdialog" aria-modal="true" aria-labelledby="reminderAlarmTitle"><section class="alarm-card"><div class="alarm-signal" aria-hidden="true">◷</div><div class="eyebrow">REMINDER ALARM</div><h2 id="reminderAlarmTitle">${esc(r.title)}</h2><p>${esc(r.details||r.category||'Your reminder is due now.')}</p><div class="alarm-due">${esc(fmtDateTime(r.dueAt))}</div><div class="alarm-actions">${btn('Snooze 10 minutes','alarm-snooze',`data-id="${esc(r.id)}"`,'btn btn-quiet')}${btn('Dismiss sound','alarm-dismiss',`data-id="${esc(r.id)}"`,'btn btn-quiet')}${btn('Mark complete','alarm-complete',`data-id="${esc(r.id)}"`,'btn btn-primary')}</div><small>Alarm sound repeats until you choose an action.</small></section></div>`;
      saveReminderNotified(r.id);startAlarmSound();
      try { if(window.pywebview?.api?.reminder_alarm_started) window.pywebview.api.reminder_alarm_started(r.id,r.title,r.dueAt).catch(()=>{}); } catch (_) {}
      $('#alarmRoot button')?.focus();return;
    }
  }
  function finishReminderAlarm(action,id) {
    const target=id||activeReminderAlarm?.id;
    stopAlarmSound();$('#alarmRoot').innerHTML='';activeReminderAlarm=null;
    if(action==='snooze'&&target)snoozeReminder(target);
    else if(action==='complete'&&target)completeReminder(target);
    showNextReminderAlarm();
  }
  function checkNotifications() {
    if(!state?.settings?.reminders)return;
    const now=Date.now();
    for(const r of state.reminders){
      if(r.completed||!r.dueAt||new Date(r.dueAt).getTime()>now||r.notificationSent)continue;
      const key=`${r.id}|${r.dueAt}`;
      if(notificationSent.has(key)||queuedReminderAlarmKeys.has(key)||activeReminderAlarm?.key===key)continue;
      notificationSent.add(key);queuedReminderAlarmKeys.add(key);reminderAlarmQueue.push({id:r.id,dueAt:r.dueAt,key});
    }
    showNextReminderAlarm();
  }
  function importBackup() { $('#importFileInput').value='';$('#importFileInput').click(); }
  async function handleImportFile(file) {
    if(!file)return;if(file.size>10*1024*1024){toast('Backup file is over 10 MB. Choose a smaller file.','error');return;}
    try{const parsed=JSON.parse(await file.text());pendingImport=S.validateImport(parsed);const counts=['tasks','reminders','notes','subjects','timetable','habits','exams','expenses'].map(k=>`${k}: ${Array.isArray(pendingImport[k])?pendingImport[k].length:Object.keys(pendingImport[k]||{}).length}`).join(' · ');
      openModal('Review workspace import','This replaces the current workspace state after you confirm. Attachment binaries are not included in JSON.',`<div class="info-note">Selected file: <strong>${esc(file.name)}</strong><br>File size: ${Math.ceil(file.size/1024)} KB<br>Schema version: ${pendingImport.schemaVersion}<br><br>${esc(counts)}</div><div class="warning-note" style="margin-top:12px">Import replaces your current records. Export the current workspace first if you want to keep a rollback copy.</div>`,'import-confirm','Replace workspace');
    }catch(err){pendingImport=null;toast(`Import failed: ${err.message}`,'error');}
  }
  async function showAttachments(id,route='notes') {
    const record=route==='library'?state.library.find(n=>n.id===id):state.notes.find(n=>n.id===id);if(!record)return;
    const list=record.attachments||[];if(!list.length){toast('This item has no attachments.','info');return;}
    const body=`<div class="settings-list">${list.map(a=>{
      if(route==='library'){
        const url=String(a.url||'');const safe=/^\/data\/library_files\/[A-Za-z0-9_-]+--[A-Za-z0-9._() -]+$/.test(url)?url:'';
        return `<div class="settings-row"><div><strong>${esc(a.name)}</strong><p>${esc(a.type||'File')} · ${Math.max(1,Math.ceil((a.size||0)/1024))} KB · Saved on this PC</p></div><div class="inline-actions">${safe?`<a class="btn btn-small btn-quiet" href="${esc(safe)}" target="_blank" rel="noopener noreferrer">Open / preview ↗</a><a class="btn btn-small" href="${esc(safe)}" download="${esc(a.name)}">Download</a>`:''}${btn('Remove','remove-attachment',`data-id="${esc(a.id)}" data-note-id="${esc(record.id)}" data-route="library"`,'btn btn-small btn-danger')}</div></div>`;
      }
      return `<div class="settings-row"><div><strong>${esc(a.name)}</strong><p>${esc(a.type)} · ${Math.max(1,Math.ceil((a.size||0)/1024))} KB</p></div><div class="inline-actions">${btn('Open / download','download-attachment',`data-id="${esc(a.id)}"`,'btn btn-small btn-quiet')}${btn('Remove','remove-attachment',`data-id="${esc(a.id)}" data-note-id="${esc(record.id)}" data-route="notes"`,'btn btn-small btn-danger')}</div></div>`;
    }).join('')}</div>`;
    openModal(`Files · ${record.title||'Library item'}`,route==='library'?'Files are stored under data/library_files in your extracted OMNI-GO folder. Keep that folder with your workspace.':'Note attachments are kept in browser IndexedDB and excluded from JSON backups.',body,'attachment-list','Done',{id,route});
  }
  async function downloadAttachment(id) {
    try{const a=await S.getAttachment(id);if(!a||!a.blob){toast('Attachment data is missing from browser storage.','error');return;}const url=URL.createObjectURL(a.blob);const link=document.createElement('a');link.href=url;link.download=a.name||'attachment';document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);}catch(err){toast(`Could not open attachment: ${err.message}`,'error');}
  }
  async function removeAttachment(id,ownerId,route='notes') {
    if(!window.confirm('Remove this attachment and its saved file?'))return;
    try{
      if(route==='library'){const response=await fetch(`/api/library-file?id=${encodeURIComponent(id)}`,{method:'DELETE'});if(!response.ok)throw new Error(`Server returned HTTP ${response.status}`);const ok=commit(d=>{const r=d.library.find(x=>x.id===ownerId);if(r)r.attachments=(r.attachments||[]).filter(a=>a.id!==id);},'Library file removed.');if(ok){const remaining=state.library.find(x=>x.id===ownerId)?.attachments||[];if(remaining.length)showAttachments(ownerId,'library');else closeModal(true);}return;}
      await S.deleteAttachment(id);const ok=commit(d=>{const n=d.notes.find(x=>x.id===ownerId);if(n)n.attachments=(n.attachments||[]).filter(a=>a.id!==id);},'Attachment removed.');if(ok)showAttachments(ownerId,'notes');
    }catch(err){toast(`Could not remove attachment: ${err.message}`,'error');}
  }
  function openResetModal() {
    openModal('Reset workspace','This replaces data/workspace.json with an empty workspace. Timestamped backups remain under data/backups/, My Library files remain under data/library_files/, and note attachments stored in IndexedDB are not deleted. Export a backup first.',`<div class="warning-note">Reset cannot be undone. Type <strong>RESET</strong> exactly to confirm.</div><div class="field" style="margin-top:14px"><label class="field-label" for="resetConfirmation">Confirmation</label><input class="form-control" id="resetConfirmation" name="confirmation" autocomplete="off" placeholder="Type RESET" required></div>`,'reset-confirm','Reset workspace');
  }
  function actionFromClick(action,el,event) {
    const route=el.dataset.route, id=el.dataset.id;
    switch(action) {
      case 'navigate': navigate(route);break;
      case 'open-sidebar': document.body.classList.add('sidebar-open');break;
      case 'close-sidebar': document.body.classList.remove('sidebar-open');break;
      case 'open-search': openSearch();break;
      case 'close-search': if(event.target.classList.contains('search-overlay'))closeSearch();break;
      case 'close-modal': closeModal(false);break;
      case 'modal-backdrop': if(event.target.classList.contains('modal-backdrop'))closeModal(false);break;
      case 'add-record': openRecordEditor(route,'',el.dataset.quick==='true');break;
      case 'edit-record': openRecordEditor(route,id);break;
      case 'prepare-exam': prepareForExam(id);break;
      case 'delete-record': deleteRecord(route,id);break;
      case 'toggle-task': break; // handled by change event
      case 'task-filter': filters.tasksTab=el.dataset.filter;navigate('tasks');break;
      case 'reminder-filter': filters.remindersTab=el.dataset.filter;navigate('reminders');break;
      case 'complete-reminder': completeReminder(id);break;
      case 'toggle-reminder': toggleReminder(id);break;
      case 'snooze-reminder': snoozeReminder(id);break;
      case 'manage-subjects': openSubjectManager();break;
      case 'edit-subject': openSubjectEditor(id);break;
      case 'delete-subject': deleteSubject(id);break;
      case 'add-class': openClassEditor('',el.dataset.day===''?null:el.dataset.day??null);break;
      case 'edit-class': openClassEditor(id);break;
      case 'delete-class': deleteClass(id);break;
      case 'mark-attendance': markAttendance(el.dataset.classId,el.dataset.date||localDate(),el.dataset.status);break;
      case 'mark-daily-attendance': markDailyAttendance(el.dataset.date||dailyAttendanceDate,el.dataset.status);break;
      case 'clear-daily-attendance': clearDailyAttendance(el.dataset.date||dailyAttendanceDate);break;
      case 'select-daily-attendance-date': dailyAttendanceDate=el.dataset.date||localDate();navigate('attendance');break;
      case 'launch-game': launchGame(id);break;
      case 'manual-attendance': openManualAttendance(id);break;
      case 'clear-manual-attendance': if(state.attendanceManual[id]&&window.confirm('Clear manual totals and return to dated class logs?'))commit(d=>{delete d.attendanceManual[id];},'Manual totals cleared.');break;
      case 'add-syllabus': openSyllabusEditor('');break;
      case 'edit-syllabus': openSyllabusEditor(id);break;
      case 'delete-syllabus': deleteSyllabus(id);break;
      case 'toggle-syllabus': break; // handled by change event
      case 'exam-tab': examTab=el.dataset.tab;renderPage();break;
      case 'attendance-calculation': break; // handled by change event
      case 'task-complete': toggleTask(id);break;
      case 'toggle-habit': toggleHabit(id);break;
      case 'start-timer': startTimer();break;
      case 'pause-timer': pauseTimer();break;
      case 'reset-timer': resetTimer();break;
      case 'skip-timer': skipTimer();break;
      case 'timer-mode': switchTimerMode(el.dataset.mode);break;
      case 'toggle-theater': toggleTheater();break;
      case 'timer-settings': openTimerSettings();break;
      case 'timer-settings-save': break;
      case 'test-alarm': testAlarmSound();break;
      case 'alarm-snooze': finishReminderAlarm('snooze',id);break;
      case 'alarm-complete': finishReminderAlarm('complete',id);break;
      case 'alarm-dismiss': finishReminderAlarm('dismiss',id);break;
      case 'export-data': safeDownload(`omni-go-backup-${localDate()}.json`,S.exportData(state));toast('Workspace backup exported. Attachments are excluded.');break;
      case 'import-data': importBackup();break;
      case 'reset-workspace': openResetModal();break;
      case 'export-corrupt': if(corruptRaw!==null)safeDownload(`omni-go-recovery-${localDate()}.txt`,corruptRaw,'text/plain');else toast('No raw recovery data is available.','error');break;
      case 'start-fresh': if(window.prompt('Export the raw recovery copy first if you may need it. Type RESET to discard the unreadable saved value and start fresh:')==='RESET'){localStorage.removeItem(S.KEY);state=M.defaultState();S.save(state);persistenceBlocked=false;corruptRaw=null;navigate('today');toast('Fresh workspace created.','info');}break;
      case 'edit-settings': openSettingsEditor();break;
      case 'open-url': {const url=M.safeUrl(el.dataset.url);if(url)window.open(url,'_blank','noopener,noreferrer');else toast('This link is not a valid HTTP(S) URL.','error');break;}
      case 'graph-range': graphRange=Number(el.dataset.range)||7;renderPage();break;
      case 'graph-metric': break; // handled by change event
      case 'finance-filter': break; // handled by change event
      case 'workout-builder': openWorkoutBuilder(el.dataset.day??0);break;
      case 'workout-template': openWorkoutTemplate();break;
      case 'log-workout': openWorkoutLogModal();break;
      case 'complete-todays-workout': completeTodaysWorkout();break;
      case 'edit-todays-workout': openWorkoutBuilder(String(weekdayIndex(new Date())));break;
      case 'log-sports': openSportsLogModal();break;
      case 'workout-logs': navigate('sports');toast(`${state.workoutLogs.length} completed workout log(s) are listed below the plan.`,'info');break;
      case 'delete-workout-log': deleteActivityLog('workout',id);break;
      case 'delete-sports-log': deleteActivityLog('sports',id);break;
      case 'calculator-key': calculatorKey(el.dataset.key);break;
      case 'search-open': closeSearch();navigate(route);if(id&&route==='timetable'){setTimeout(()=>{$(`[data-action="edit-class"][data-id="${CSS.escape(id)}"]`)?.focus();},0);}break;
      case 'show-attachments': showAttachments(id,route||'notes');break;
      case 'download-attachment': downloadAttachment(id);break;
      case 'remove-attachment': removeAttachment(id,el.dataset.noteId,route||'notes');break;
      case 'refresh-weather': loadWeatherForCity(state.profile.city||'',true);break;
      case 'media-choose': $('#mediaFiles')?.click();break;
      case 'media-play': toggleMediaPlayback();break;
      case 'media-prev': stepMedia(-1);break;
      case 'media-next': stepMedia(1);break;
      case 'setting-toggle': break; // handled by change event
      default: console.warn('Unhandled action:',action);
    }
  }
  document.addEventListener('click',event=>{
    const el=event.target.closest('[data-action]');if(!el)return;
    if(el.matches('input[type=checkbox][data-action],select[data-action],input[type=date][data-action]'))return;
    actionFromClick(el.dataset.action,el,event);
  });
  document.addEventListener('change',event=>{
    const el=event.target;
    if(el.matches('[data-action="toggle-task"]')){toggleTask(el.dataset.id);return;}
    if(el.matches('[data-action="workout-exercise"]')){toggleWorkoutExercise(el.dataset.exerciseId,el.checked);return;}
    if(el.matches('[data-action="daily-attendance-date"]')){dailyAttendanceDate=el.value||localDate();renderPage();return;}
    if(el.matches('[data-action="toggle-syllabus"]')){toggleSyllabus(el.dataset.id);return;}
    if(el.matches('[data-action="desktop-close-behavior"]')){const previous=desktopCloseBehavior,value=el.value;if(!window.pywebview?.api?.set_close_behavior){el.value=previous;toast('System-tray close behavior is available in the Windows desktop app only.','info');return;}window.pywebview.api.set_close_behavior(value).then(saved=>{desktopCloseBehavior=saved;toast(saved==='tray'?'Close behavior saved: minimize to tray.':saved==='quit'?'Close behavior saved: exit completely.':'The next close will ask again.','success');}).catch(err=>{el.value=previous;toast(`Could not save desktop preference: ${err.message||err}`,'error');});return;}
    if(el.matches('[data-action="setting-toggle"]')){const key=el.dataset.setting;commit(d=>{if(['ambient','compact','reminders'].includes(key))d.settings[key]=el.checked;},'Preference updated.');if(key==='reminders'&&!el.checked){stopAlarmSound();$('#alarmRoot').innerHTML='';activeReminderAlarm=null;reminderAlarmQueue=[];queuedReminderAlarmKeys.clear();}return;}
    if(el.matches('[data-action="attendance-calculation"]')){commit(d=>{d.attendanceCalculation=el.value==='equal'?'equal':'weighted';},'Attendance calculation updated.');return;}
    if(el.matches('[data-action="graph-metric"]')){graphMetric=el.value;renderPage();return;}
    if(el.matches('[data-action="finance-filter"]')){filters.financeType=el.value;renderPage();return;}
    if(el.matches('#importFileInput')){handleImportFile(el.files?.[0]);return;}
    if(el.matches('#mediaFiles')){loadMediaFiles(el.files);return;}
    if(el.matches('#mediaSeek')){const a=$('#mediaAudio');if(a&&a.duration)a.currentTime=(Number(el.value)/1000)*a.duration;return;}
  });
  document.addEventListener('input',event=>{
    const el=event.target;
    if(el.closest('[data-modal-form]'))modalDirty=true;
    if(el.matches('[data-filter-route]')){const route=el.dataset.filterRoute, value=el.value, start=el.selectionStart;if(route==='notes')filters.notesSubject='';filters[route]=value;renderPage();const next=$(`[data-filter-route="${route}"]`);if(next){next.focus();try{next.setSelectionRange(start,start);}catch(_){}}return;}
    if(el.matches('[data-filter-timetable]')){classSearch=el.value;renderPage();const next=$('[data-filter-timetable]');next?.focus();if(next)next.setSelectionRange(classSearch.length,classSearch.length);return;}
    if(el.matches('[data-filter-attendance]')){attendanceSearch=el.value;renderPage();const next=$('[data-filter-attendance]');next?.focus();if(next)next.setSelectionRange(attendanceSearch.length,attendanceSearch.length);return;}
    if(el.matches('#calcDisplay')){calculatorExpression=el.value;calculatorError='';calculatorResult='';syncCalculatorUI();return;}
    if(el.matches('#universalSearch')){updateSearchResults();return;}
  });
  document.addEventListener('submit',event=>{
    const form=event.target.closest('[data-modal-form]');if(!form)return;event.preventDefault();handleModalSubmit(form);
  });
  document.addEventListener('keydown',event=>{
    if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'){event.preventDefault();if($('#searchRoot').innerHTML)closeSearch();else openSearch();return;}
    if($('#searchRoot').innerHTML){
      if(event.key==='Escape'){event.preventDefault();closeSearch();return;}
      if(['ArrowDown','ArrowUp'].includes(event.key)){event.preventDefault();const rows=$$('.search-result');if(!rows.length)return;searchActiveIndex=(searchActiveIndex+(event.key==='ArrowDown'?1:-1)+rows.length)%rows.length;rows.forEach((r,i)=>r.classList.toggle('active',i===searchActiveIndex));rows[searchActiveIndex].scrollIntoView({block:'nearest'});return;}
      if(event.key==='Enter'){event.preventDefault();const rows=$$('.search-result');(rows[searchActiveIndex]||rows[0])?.click();return;}
    }
    if(event.key==='Escape'&&$('#modalRoot').innerHTML){event.preventDefault();closeModal(false);return;}
    if(currentRoute==='tools'&&!$('#searchRoot').innerHTML&&!$('#modalRoot').innerHTML&&!event.ctrlKey&&!event.metaKey&&!event.altKey){
      const active=document.activeElement, calcFocused=!!active?.closest?.('.calculator');
      const calcDisplayFocused=active?.id==='calcDisplay';
      const otherField=active&&(active.matches('input,textarea,select,[contenteditable="true"]')&&!calcDisplayFocused);
      // A clicked calculator button keeps keyboard focus. Treat the keypad as calculator focus,
      // while leaving every unrelated input and control completely alone.
      if(!otherField&&(calcDisplayFocused||calcFocused||active===document.body||active===document.documentElement)){
        if(event.key==='Enter'){event.preventDefault();calculatorKey('=');}
        else if(event.key==='Escape'){event.preventDefault();calculatorKey('AC');}
        else if(event.key==='Backspace'&&!calcDisplayFocused){event.preventDefault();calculatorKey('⌫');}
        else if(!calcDisplayFocused&&/^[0-9.+\-*/%^()]$/.test(event.key)){event.preventDefault();calculatorKey(event.key);}
      }
    }
  });
  document.addEventListener('change',event=>{
    const el=event.target;
    if(el.matches('#splitTemplate')){
      const definition=workoutTemplateDefinitions()[el.value]||workoutTemplateDefinitions().ppl3;const preview=$('#templatePreview');if(preview)preview.innerHTML=templatePreviewMarkup(definition);
    }
  });

  // Local music player. File URLs are created only after the user explicitly selects audio files.
  let mediaPlaylist=[], mediaIndex=0, systemMediaAvailable=false, systemMediaIsPlaying=false;
  function mediaTime(seconds){if(!Number.isFinite(seconds))return '0:00';const m=Math.floor(seconds/60),s=Math.floor(seconds%60);return `${m}:${String(s).padStart(2,'0')}`;}
  function loadMediaFiles(fileList){const files=Array.from(fileList||[]).filter(f=>f.type.startsWith('audio/'));if(!files.length){toast('Choose one or more supported audio files.','error');return;}mediaPlaylist.forEach(x=>URL.revokeObjectURL(x.url));mediaPlaylist=files.map(file=>({file,url:URL.createObjectURL(file)}));mediaIndex=0;playMediaAtIndex(true);}
  function playMediaAtIndex(autoplay=false){const audio=$('#mediaAudio'),title=$('#mediaTrackTitle'),sub=$('#mediaTrackSub');if(!audio||!mediaPlaylist.length)return;audio.ontimeupdate=syncMediaControls;audio.onplay=syncMediaControls;audio.onpause=syncMediaControls;audio.onended=()=>{if(mediaPlaylist.length>1)stepMedia(1);else syncMediaControls();};const track=mediaPlaylist[mediaIndex];audio.src=track.url;if(title)title.textContent=track.file.name;if(sub)sub.textContent=`Track ${mediaIndex+1} of ${mediaPlaylist.length} · ${(track.file.size/1048576).toFixed(1)} MB`;const status=$('#mediaStatus');if(status)status.textContent='Playing from your selected local playlist.';if(autoplay)audio.play().catch(()=>{if(status)status.textContent='Press Play to start this track.';});syncMediaControls();}
  function toggleMediaPlayback(){if(systemMediaAvailable){sendSystemMediaCommand(systemMediaIsPlaying?'pause':'play');return;}const audio=$('#mediaAudio');if(!audio)return;if(!mediaPlaylist.length){$('#mediaFiles')?.click();return;}if(audio.paused)audio.play().catch(()=>toast('Your browser could not play this audio format.','error'));else audio.pause();syncMediaControls();}
  async function sendSystemMediaCommand(command){try{const r=await fetch('/api/media-control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({command})});const data=await r.json();if(!r.ok||!data.ok)toast(data.reason||'Windows media control is unavailable.','error');else setTimeout(pollSystemMedia,350);}catch(_){toast('Windows media control is unavailable.','error');}}
  async function pollSystemMedia(){try{const r=await fetch('/api/media-session',{cache:'no-store'});if(!r.ok)return;const d=await r.json();const title=$('#mediaTrackTitle'),sub=$('#mediaTrackSub'),status=$('#mediaStatus'),play=$('[data-action="media-play"]');if(!title)return;if(d.available){systemMediaAvailable=true;systemMediaIsPlaying=String(d.status).includes('playing');title.textContent=d.title||'Unknown title';sub.textContent=[d.artist,d.album,d.source].filter(Boolean).join(' · ');if(status)status.textContent='Windows media session detected · controls target the active PC media app.';if(play)play.textContent=systemMediaIsPlaying?'Ⅱ Pause':'▶ Play';}else{systemMediaAvailable=false;if(!mediaPlaylist.length){if(status)status.textContent=d.reason||'No active Windows media session. Choose local music to play it here.';}}}catch(_){systemMediaAvailable=false;}}
  function stepMedia(delta){if(systemMediaAvailable){sendSystemMediaCommand(delta<0?'previous':'next');return;}if(!mediaPlaylist.length)return;mediaIndex=(mediaIndex+delta+mediaPlaylist.length)%mediaPlaylist.length;playMediaAtIndex(true);}
  function syncMediaControls(){const audio=$('#mediaAudio'),play=$('[data-action="media-play"]'),seek=$('#mediaSeek'),cur=$('#mediaCurrent'),dur=$('#mediaDuration');if(!audio)return;if(play)play.textContent=audio.paused?'▶ Play':'Ⅱ Pause';if(seek&&audio.duration)seek.value=String(Math.round(audio.currentTime/audio.duration*1000));if(cur)cur.textContent=mediaTime(audio.currentTime);if(dur)dur.textContent=mediaTime(audio.duration);}
  setInterval(syncMediaControls,500);
  setInterval(pollSystemMedia,5000);
  window.addEventListener('load',pollSystemMedia,{once:true});
  document.addEventListener('ended',()=>{if(mediaPlaylist.length>1)stepMedia(1);else syncMediaControls();});
  document.addEventListener('play',event=>{if(event.target?.id==='mediaAudio')syncMediaControls();},true);
  document.addEventListener('pause',event=>{if(event.target?.id==='mediaAudio')syncMediaControls();},true);

  // Timer-specific settings form handler kept separate from the profile form.
  const originalSubmit = handleModalSubmit;
  handleModalSubmit = async function(form) {
    if(form.dataset.modalForm==='timer-settings-save'){
      try{const v=formDataObject(form),focus=Number(v.focus),shortBreak=Number(v.shortBreak),longBreak=Number(v.longBreak);if(!Number.isInteger(focus)||focus<1||focus>180||!Number.isInteger(shortBreak)||shortBreak<1||shortBreak>60||!Number.isInteger(longBreak)||longBreak<1||longBreak>120)throw new Error('Timer values must be whole minutes within the displayed ranges.');const ok=commit(d=>{d.profile.focus=focus;d.profile.shortBreak=shortBreak;d.profile.longBreak=longBreak;M.recordActivity(d,'settings','Updated timer durations');},'Timer settings saved.');if(ok&&timerTheater)refreshTheaterVisualMode();if(ok){closeModal(true);if(!timerRunning)timerRemaining=durationForMode(timerMode);renderPage();}return;}catch(err){toast(err.message,'error');return;}
    }
    return originalSubmit(form);
  };

  // Load the file-backed workspace first. If this is a first launch, migrate any legacy browser data once.
  // After migration, the Python server writes workspace.json and timestamped copies in data/backups/.
  (async()=>{
    try {
      const serverData = await S.loadServer();
      if(serverData && serverData.exists && serverData.state) {
        state=M.normalizeState(serverData.state);
        try { localStorage.removeItem(S.KEY); } catch (_) {}
      } else if(!persistenceBlocked) {
        await S.flush(); S.save(state); // migrate legacy browser data or initialize a fresh file workspace
      }
    } catch(err) { console.warn('File-backed workspace is unavailable; using the current in-memory workspace.',err); toast('File backup is unavailable. Keep the local server running and check folder permissions.','error'); }
    renderNav();refreshShell();renderPage();loadWeatherForCity(state.profile.city||'');
  })();
  setInterval(()=>{
    const now=new Date(),clock=$('#heroClock'),date=$('#heroDate');
    if(clock)clock.textContent=now.toLocaleTimeString(undefined,{hour:'numeric',minute:'2-digit'});
    if(date)date.textContent=now.toLocaleDateString(undefined,{weekday:'short',month:'short',day:'2-digit',year:'numeric'});
  },1000);
  setInterval(checkNotifications,1000);
  // Exposed only to the local pywebview bridge. The native watcher alerts while the window is in the tray;
  // this callback also lets a restored window show its in-app alarm without requesting browser permissions.
  window.omniDesktopReceiveAlarm=function(reminderId){const item=state.reminders.find(r=>r.id===reminderId);if(item&&!item.completed&&item.dueAt&&new Date(item.dueAt).getTime()<=Date.now()&&!item.notificationSent){checkNotifications();}};
  if(persistenceBlocked)toast('Saved data could not be read. It has not been overwritten; visit Settings to export a recovery copy or deliberately start fresh.','error');
  if('serviceWorker' in navigator){/* No service worker is installed; the app does not cache data in the background. */}
})();
