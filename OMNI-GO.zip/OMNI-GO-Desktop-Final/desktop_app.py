"""Native-window OMNI-GO shell with system-tray close behavior and local alarm support."""
from __future__ import annotations

import ctypes
import json
import os
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

APP_PORT = 8765


def app_root() -> Path:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent


def user_data_dir() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local" / "share")))
    return base / "OMNI-GO" / "data"


def preferences_path() -> Path:
    return user_data_dir().parent / "desktop-preferences.json"


def read_preferences() -> dict:
    try:
        value = json.loads(preferences_path().read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def write_preferences(value: dict) -> None:
    path = preferences_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def prompt_close_choice() -> str:
    """First-close native prompt: Yes = tray, No = fully quit."""
    text = (
        "What should OMNI-GO do when you close this window?\n\n"
        "YES  — Minimize to the system tray and keep reminders running\n"
        "NO   — Close OMNI-GO completely\n\n"
        "Your choice is saved. You can change it later in Settings."
    )
    if os.name == "nt":
        flags = 0x00000004 | 0x00000020 | 0x00010000 | 0x00040000  # YES/NO, question, foreground, topmost
        result = ctypes.windll.user32.MessageBoxW(None, text, "OMNI-GO", flags)
        return "tray" if result == 6 else "quit"
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk(); root.withdraw(); root.attributes("-topmost", True)
        keep = messagebox.askyesno("OMNI-GO", text, parent=root)
        root.destroy()
        return "tray" if keep else "quit"
    except Exception:
        return "quit"


class DesktopApi:
    """Small, allow-listed bridge exposed to the app's own local WebView."""
    def __init__(self):
        self.window = None
        self.tray = None
        self.hidden = False
        self.allow_close = False
        self._lock = threading.RLock()
        self._alerted_keys: set[str] = set()
        self._stop = threading.Event()
        self.tray_ready = threading.Event()

    def get_close_behavior(self):
        behavior = str(read_preferences().get("close_behavior", "ask"))
        return behavior if behavior in {"ask", "tray", "quit"} else "ask"

    def set_close_behavior(self, behavior):
        behavior = str(behavior or "").strip().lower()
        if behavior not in {"ask", "tray", "quit"}:
            raise ValueError("Choose Ask next time, Minimize to tray, or Close completely.")
        prefs = read_preferences(); prefs["close_behavior"] = behavior; write_preferences(prefs)
        return behavior

    def show_window(self):
        self.hidden = False
        if self.tray:
            try: self.tray.visible = False
            except Exception: pass
        if self.window:
            try:
                self.window.show()
                try: self.window.restore()
                except Exception: pass
            except Exception: pass
        return True

    def hide_window_to_tray(self):
        if not self.tray:
            raise RuntimeError("System tray support is unavailable in this build.")
        self.tray_ready.wait(timeout=3)
        try: self.tray.visible = True
        except Exception: pass
        self.hidden = True
        if self.window:
            self.window.hide()
        return True

    def reminder_alarm_started(self, reminder_id, title, due_at):
        """Called by the UI as an alarm appears; OS alert is only needed while hidden."""
        key = f"{str(reminder_id)[:100]}|{str(due_at)[:80]}"
        with self._lock:
            if not self.hidden or key in self._alerted_keys:
                return {"ok": True, "notified": False}
            self._alerted_keys.add(key)
        self._notify_tray(str(title or "Reminder")[:140], "OMNI-GO reminder is due. Open OMNI-GO to snooze or complete it.")
        return {"ok": True, "notified": True}

    def _notify_tray(self, title: str, message: str):
        if self.tray:
            try:
                self.tray.visible = True
                self.tray.notify(message[:240], title=title[:63])
            except Exception:
                pass
        threading.Thread(target=self._alarm_sound, daemon=True, name="OMNI-GO-reminder-sound").start()

    @staticmethod
    def _alarm_sound():
        if os.name != "nt":
            return
        try:
            import winsound
            for frequency in (880, 660, 880):
                winsound.Beep(frequency, 240)
                time.sleep(0.12)
        except Exception:
            try: ctypes.windll.user32.MessageBeep(0x00000030)
            except Exception: pass

    def start_reminder_watcher(self, state_file: Path):
        def watch():
            while not self._stop.wait(2.0):
                if not self.hidden:
                    continue
                try:
                    payload = json.loads(state_file.read_text(encoding="utf-8"))
                    if not isinstance(payload, dict) or not payload.get("settings", {}).get("reminders", True):
                        continue
                    now = datetime.now().astimezone()
                    for reminder in payload.get("reminders", []):
                        if not isinstance(reminder, dict) or reminder.get("completed") or reminder.get("notificationSent"):
                            continue
                        due = reminder.get("dueAt")
                        if not due:
                            continue
                        try:
                            due_time = datetime.fromisoformat(str(due).replace("Z", "+00:00"))
                            if due_time.tzinfo is None:
                                due_time = due_time.astimezone()
                        except (ValueError, TypeError):
                            continue
                        if due_time > now:
                            continue
                        key = f"{str(reminder.get('id',''))[:100]}|{str(due)[:80]}"
                        with self._lock:
                            if key in self._alerted_keys:
                                continue
                            self._alerted_keys.add(key)
                        title = str(reminder.get("title") or "Reminder")[:140]
                        self._notify_tray(title, "Your reminder is due. Open OMNI-GO to snooze or complete it.")
                        if self.window:
                            try:
                                safe_id = json.dumps(str(reminder.get("id", "")))
                                self.window.evaluate_js(f"window.omniDesktopReceiveAlarm && window.omniDesktopReceiveAlarm({safe_id})")
                            except Exception:
                                pass
                except (OSError, json.JSONDecodeError, TypeError):
                    continue
        threading.Thread(target=watch, daemon=True, name="OMNI-GO-reminder-watcher").start()

    def stop(self):
        self._stop.set()
        if self.tray:
            try: self.tray.stop()
            except Exception: pass


def main() -> int:
    data_dir = user_data_dir().resolve()
    data_dir.mkdir(parents=True, exist_ok=True)
    os.environ["OMNIGO_DATA_DIR"] = str(data_dir)
    os.environ["OMNIGO_PORT"] = str(APP_PORT)

    try:
        import webview
        import server as omni_server
        import pystray
        from PIL import Image, ImageDraw
    except ImportError as exc:
        message = ("OMNI-GO Desktop dependencies are missing.\n\nRun build_windows_app.bat on Windows to install them.\n\n"
                   f"Details: {exc}")
        try:
            import tkinter.messagebox as messagebox
            messagebox.showerror("OMNI-GO Desktop", message)
        except Exception:
            print(message, file=sys.stderr)
        return 2

    try:
        httpd = omni_server.ThreadingHTTPServer((omni_server.HOST, APP_PORT), omni_server.Handler)
    except OSError as exc:
        message = f"OMNI-GO could not use local app port {APP_PORT}. Close another OMNI-GO instance and retry.\n\nDetails: {exc}"
        try:
            import tkinter.messagebox as messagebox
            messagebox.showerror("OMNI-GO Desktop", message)
        except Exception: print(message, file=sys.stderr)
        return 3

    port = httpd.server_address[1]
    threading.Thread(target=httpd.serve_forever, name="OMNI-GO-local-service", daemon=True).start()
    api = DesktopApi()

    def tray_open(icon, item):
        api.show_window()

    def tray_exit(icon, item):
        api.allow_close = True
        api.stop()
        if api.window:
            try: api.window.destroy()
            except Exception: pass

    icon_path = app_root() / "assets" / "omni-go.ico"
    try:
        tray_image = Image.open(icon_path).convert("RGBA")
    except Exception:
        tray_image = Image.new("RGBA", (64, 64), (8, 9, 11, 255))
        draw = ImageDraw.Draw(tray_image); draw.polygon([(32, 5), (58, 32), (32, 59), (6, 32)], outline=(210, 225, 255, 255), width=3)
    menu = pystray.Menu(
        pystray.MenuItem("Open OMNI-GO", tray_open, default=True),
        pystray.MenuItem("Exit OMNI-GO", tray_exit),
    )
    api.tray = pystray.Icon("omni-go", tray_image, "OMNI-GO", menu=menu)
    def setup_tray(icon):
        try: icon.visible = False
        finally: api.tray_ready.set()
    threading.Thread(target=lambda: api.tray.run(setup=setup_tray),
                     name="OMNI-GO-system-tray", daemon=True).start()
    api.start_reminder_watcher(omni_server.STATE_FILE)
    url = f"http://127.0.0.1:{port}/"

    try:
        window = webview.create_window(
            "OMNI-GO — Personal Command Center", url=url,
            width=1440, height=920, min_size=(960, 640),
            background_color="#08090b", text_select=True, js_api=api,
        )
        api.window = window

        def handle_closing():
            if api.allow_close:
                return True
            behavior = api.get_close_behavior()
            if behavior == "ask":
                behavior = prompt_close_choice()
                try: api.set_close_behavior(behavior)
                except Exception: pass
            if behavior == "tray":
                try:
                    api.hide_window_to_tray()
                    return False  # pywebview cancels close, leaving the process alive in the tray
                except Exception as exc:
                    try:
                        import tkinter.messagebox as messagebox
                        messagebox.showerror("OMNI-GO", f"Could not minimize to the tray. OMNI-GO will close instead.\n\n{exc}")
                    except Exception: pass
                    api.allow_close = True
                    api.stop()
                    return True
            api.allow_close = True
            api.stop()
            return True

        window.events.closing += handle_closing
        window.events.closed += api.stop
        webview.start(debug=False)
    except Exception as exc:
        message = f"OMNI-GO could not open its desktop window.\n\nDetails: {type(exc).__name__}: {exc}"
        try:
            import tkinter.messagebox as messagebox
            messagebox.showerror("OMNI-GO Desktop", message)
        except Exception: print(message, file=sys.stderr)
        return 4
    finally:
        api.stop()
        try:
            httpd.shutdown(); httpd.server_close()
        except Exception: pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
