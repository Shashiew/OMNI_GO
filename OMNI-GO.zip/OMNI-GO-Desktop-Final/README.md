# OMNI-GO

OMNI-GO is a personal command center for tasks, reminders, notes, timetable, attendance, exams, habits, study time, workouts, media, games and everyday tracking. The Study Timer planet horizon and stars are drawn with Canvas code; no wallpaper image is used.

## Windows

1. Install Python 3.10+ and Microsoft Edge WebView2 Runtime.
2. Run `build_windows_app.bat`. It installs the required desktop and Windows system-media dependencies, builds and installs OMNI-GO, and creates Desktop and Start Menu shortcuts.
3. The builder also creates `OMNI-GO-Tester-App.zip` for sharing with a new Windows tester. They extract it and run `Install-OMNI-GO.bat`; Python is not required on their PC.

Workspace data is stored in `%LOCALAPPDATA%\OMNI-GO\data`. Keep the installed `OMNI-GO` folder and `_internal` folder together. Reminders run while the app is open or minimized to the tray, not after a full exit.
