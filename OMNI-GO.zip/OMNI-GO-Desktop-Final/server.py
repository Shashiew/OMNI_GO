"""Minimal loopback-only static server for OMNI-GO with narrowly-scoped local features."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from datetime import datetime
import json
import asyncio
import os
import sys
import re
import subprocess
from urllib.parse import urlparse, parse_qs, unquote, urlencode
import urllib.request
import urllib.error
import mimetypes

HOST = "127.0.0.1"
PORT = int(os.environ.get("OMNIGO_PORT", "8000"))
ROOT = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("OMNIGO_DATA_DIR", str(ROOT / "data"))).expanduser().resolve()
BACKUP_DIR = DATA_DIR / "backups"
STATE_FILE = DATA_DIR / "workspace.json"
MAX_BODY = 8 * 1024 * 1024
MAX_LIBRARY_FILE = 100 * 1024 * 1024
LIBRARY_FILE_DIR = DATA_DIR / "library_files"
ALLOWED_LIBRARY_EXTENSIONS = {".pdf", ".doc", ".docx", ".odt", ".rtf", ".txt", ".md", ".csv", ".xls", ".xlsx", ".ppt", ".pptx", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".mp4", ".webm", ".mov", ".m4v"}

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def _media_session(self):
        try:
            from winsdk.windows.media.control import GlobalSystemMediaTransportControlsSessionManager
            async def read_session():
                manager = await GlobalSystemMediaTransportControlsSessionManager.request_async()
                session = manager.get_current_session()
                if session is None: return {"available": False, "reason": "No active Windows media session."}
                props = await session.try_get_media_properties_async()
                playback = session.get_playback_info().playback_status
                return {"available": True, "title": props.title or "Unknown title", "artist": props.artist or "Unknown artist", "album": props.album_title or "", "status": str(playback).split(".")[-1].lower(), "source": session.source_app_user_model_id or "Windows media session"}
            return asyncio.run(read_session())
        except ImportError:
            return {"available": False, "reason": "Windows media integration is unavailable in this build."}
        except Exception as exc:
            return {"available": False, "reason": f"Windows media session unavailable: {type(exc).__name__}."}

    def _weather_lookup(self, parsed):
        if not self._same_local_origin():
            self._json_response(403, {"ok": False, "error": "Weather lookup is available only from the local OMNI-GO app."})
            return
        city = parse_qs(parsed.query).get("city", [""])[0].strip()
        if not city or len(city) > 120 or "\x00" in city:
            self._json_response(400, {"ok": False, "error": "Enter a city or place name (up to 120 characters) in Settings."})
            return
        # Open-Meteo supports anonymous lookups; only this fixed provider is contacted.
        # The browser talks to localhost, avoiding cross-origin fetch restrictions.
        query_name = city.split(",", 1)[0].strip() or city
        geo_url = "https://geocoding-api.open-meteo.com/v1/search?" + urlencode({"name": query_name, "count": 5, "language": "en", "format": "json"})
        headers = {"Accept": "application/json", "User-Agent": "OMNI-GO local weather helper/1.0"}
        try:
            req = urllib.request.Request(geo_url, headers=headers)
            with urllib.request.urlopen(req, timeout=9) as response:
                geo = json.loads(response.read(2_000_000).decode("utf-8"))
            places = geo.get("results") or []
            if not places:
                self._json_response(404, {"ok": False, "error": f"Could not find “{city}”. Try a city name such as “Visakhapatnam”."})
                return
            # If the input contains a country, prefer a matching result when possible.
            country_hint = city.split(",", 1)[1].strip().casefold() if "," in city else ""
            place = next((p for p in places if country_hint and country_hint in str(p.get("country", "")).casefold()), places[0])
            params = urlencode({"latitude": str(place["latitude"]), "longitude": str(place["longitude"]), "current": "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m", "timezone": "auto"})
            weather_url = "https://api.open-meteo.com/v1/forecast?" + params
            req = urllib.request.Request(weather_url, headers=headers)
            with urllib.request.urlopen(req, timeout=9) as response:
                forecast = json.loads(response.read(2_000_000).decode("utf-8"))
            current = forecast.get("current")
            if not isinstance(current, dict) or not isinstance(current.get("temperature_2m"), (int, float)):
                self._json_response(502, {"ok": False, "error": "The weather provider returned no current conditions. Try again later."})
                return
            label = ", ".join(dict.fromkeys(str(p) for p in (place.get("name"), place.get("admin1"), place.get("country")) if p))
            self._json_response(200, {"ok": True, "place": label or city, "current": current})
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            # Never disguise an upstream connectivity problem as a missing forecast.
            self._json_response(502, {"ok": False, "error": "OMNI-GO could not reach Open-Meteo from this computer. Check internet access, VPN, DNS or firewall settings, then retry."})
        except (json.JSONDecodeError, KeyError, TypeError, ValueError):
            self._json_response(502, {"ok": False, "error": "The weather provider returned an unreadable response. Please retry shortly."})

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/weather":
            self._weather_lookup(parsed)
            return
        if self.path == "/api/media-session":
            raw = json.dumps(self._media_session()).encode("utf-8")
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw); return
        if parsed.path.startswith("/data/library_files/"):
            # Do not let unrelated websites read local library attachments via fetch.
            origin = self.headers.get("Origin")
            if origin and not self._same_local_origin():
                self.send_error(403, "Local-origin requests only.")
                return
            requested = unquote(parsed.path[len("/data/library_files/"):])
            filename = Path(requested).name
            if not requested or filename != requested or filename in {".", ".."}:
                self.send_error(400, "Invalid library file path.")
                return
            base = LIBRARY_FILE_DIR.resolve()
            target = (base / filename).resolve()
            if target.parent != base or not target.is_file():
                self.send_error(404, "Library file not found.")
                return
            try:
                body = target.read_bytes()
                content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
                self.send_response(200)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Content-Disposition", "inline; filename=\"" + target.name.replace('"', '') + "\"")
                self.end_headers()
                self.wfile.write(body)
            except OSError:
                self.send_error(500, "Could not read the saved library file.")
            return
        if self.path == "/api/state":
            payload = {"exists": STATE_FILE.exists(), "state": None}
            if STATE_FILE.exists():
                try:
                    payload["state"] = json.loads(STATE_FILE.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    self.send_error(500, "Saved workspace file is unreadable; it was not overwritten.")
                    return
            raw = json.dumps(payload).encode("utf-8")
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw); return
        return super().do_GET()

    def _loopback_only(self):
        # Accept only the exact IPv4 loopback host, optionally with a numeric port.
        # Avoid permissive prefix checks such as 127.0.0.1.attacker.example.
        host = self.headers.get("Host", "").strip()
        match = re.fullmatch(r"127\.0\.0\.1(?::([0-9]{1,5}))?", host)
        if not match:
            return False
        port_text = match.group(1)
        return port_text is None or 1 <= int(port_text) <= 65535

    def do_PUT(self):
        parsed = urlparse(self.path)
        if parsed.path != "/api/library-file":
            self.send_error(404); return
        if not self._same_local_origin():
            self.send_error(403, "Local-origin requests only."); return
        query = parse_qs(parsed.query)
        file_id = query.get("id", [""])[0]
        display_name = unquote(query.get("name", [""])[0]).replace("\\", "/").split("/")[-1].strip()
        suffix = Path(display_name).suffix.lower()
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", file_id) or not display_name or suffix not in ALLOWED_LIBRARY_EXTENSIONS:
            self.send_error(400, "Invalid file ID or unsupported library file type."); return
        try: size = int(self.headers.get("Content-Length", "0"))
        except ValueError: size = 0
        if size < 1 or size > MAX_LIBRARY_FILE:
            self.send_error(413, "Library files must be between 1 byte and 100 MB."); return
        try:
            raw = self.rfile.read(size)
            if len(raw) != size: raise OSError("Upload ended before all file bytes arrived.")
            safe_name = re.sub(r"[^A-Za-z0-9._() -]", "_", display_name).strip(" .") or ("file" + suffix)
            stored_name = f"{file_id}--{safe_name}"
            LIBRARY_FILE_DIR.mkdir(parents=True, exist_ok=True)
            target = LIBRARY_FILE_DIR / stored_name
            target.write_bytes(raw)
            response = json.dumps({"ok": True, "id": file_id, "name": display_name, "type": self.headers.get("Content-Type", "application/octet-stream"), "size": size, "url": "/data/library_files/" + stored_name, "createdAt": datetime.now().astimezone().isoformat()}).encode("utf-8")
            self.send_response(201); self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(response))); self.end_headers(); self.wfile.write(response)
        except OSError as exc:
            self.send_error(500, f"Could not save library file: {exc}")

    def do_DELETE(self):
        parsed = urlparse(self.path)
        if parsed.path != "/api/library-file":
            self.send_error(404); return
        if not self._same_local_origin():
            self.send_error(403, "Local-origin requests only."); return
        file_id = parse_qs(parsed.query).get("id", [""])[0]
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", file_id):
            self.send_error(400, "Invalid library file ID."); return
        try:
            removed = False
            if LIBRARY_FILE_DIR.exists():
                for candidate in LIBRARY_FILE_DIR.glob(file_id + "--*"):
                    if candidate.is_file(): candidate.unlink(); removed = True
            response = json.dumps({"ok": True, "removed": removed}).encode("utf-8")
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(response))); self.end_headers(); self.wfile.write(response)
        except OSError as exc:
            self.send_error(500, f"Could not remove library file: {exc}")

    def _json_response(self, status, payload):
        raw = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def _same_local_origin(self):
        if not self._loopback_only():
            return False
        origin = self.headers.get("Origin")
        if not origin:
            # Non-browser local callers may omit Origin. Browsers send Origin for
            # cross-site POST/PUT/DELETE requests, which are denied below.
            return True
        parsed = urlparse(origin)
        host = self.headers.get("Host", "")
        return (
            parsed.scheme == "http"
            and parsed.hostname == "127.0.0.1"
            and parsed.netloc == host
            and parsed.username is None
            and parsed.password is None
        )

    def _launch_game(self):
        if not self._same_local_origin():
            self._json_response(403, {"ok": False, "reason": "Local-origin requests only."})
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size < 2 or size > 8192:
                self._json_response(413, {"ok": False, "reason": "Game launch request is too large or empty."})
                return
            data = json.loads(self.rfile.read(size).decode("utf-8"))
            if not isinstance(data, dict) or not isinstance(data.get("path"), str):
                raise ValueError("Choose a valid game path.")
            raw_path = data["path"].strip().strip('"')
            if not raw_path or "\x00" in raw_path:
                raise ValueError("Game path is empty or invalid.")
            suffix = Path(raw_path).suffix.lower()
            if suffix not in {".exe", ".lnk"}:
                raise ValueError("Only Windows .exe and .lnk paths can be launched.")
            if sys.platform != "win32":
                self._json_response(501, {"ok": False, "reason": "Game launching is only supported by the Windows desktop build."})
                return
            path = Path(raw_path).expanduser()
            if not path.is_absolute():
                raise ValueError("Enter a full absolute Windows path, such as C:\\Games\\Game.exe.")
            path = path.resolve(strict=True)
            if not path.is_file():
                raise ValueError("The selected game path is not a file.")
            if path.suffix.lower() not in {".exe", ".lnk"}:
                raise ValueError("The resolved game path must still be a .exe or .lnk file.")
            if path.suffix.lower() == ".lnk":
                # Use Windows ShellExecute via os.startfile, not a shell command.
                os.startfile(str(path))
            else:
                # Launch the explicitly selected executable with its own path and no shell interpolation.
                subprocess.Popen([str(path)], cwd=str(path.parent), close_fds=True)
            self._json_response(200, {"ok": True, "message": "Launch request sent.", "filename": path.name})
        except FileNotFoundError:
            self._json_response(404, {"ok": False, "reason": "That game file was not found. Check the saved path."})
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            self._json_response(400, {"ok": False, "reason": str(exc)})
        except OSError as exc:
            self._json_response(500, {"ok": False, "reason": f"Windows could not start that game ({type(exc).__name__})."})

    def do_POST(self):
        request_path = urlparse(self.path).path
        mutating_json_paths = {"/api/launch-game", "/api/media-control", "/api/state", "/api/backup"}
        if request_path in mutating_json_paths:
            if not self._same_local_origin():
                self._json_response(403, {"ok": False, "error": "Local-origin requests only."})
                return
            content_type = self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
            if content_type != "application/json":
                self._json_response(415, {"ok": False, "error": "This endpoint requires an application/json request."})
                return
        if request_path == "/api/launch-game":
            self._launch_game()
            return
        if self.path == "/api/media-control":
            if not self._same_local_origin():
                self._json_response(403, {"ok": False, "reason": "Local-origin requests only."})
                return
            try:
                size = int(self.headers.get("Content-Length", "0"))
                if size < 2 or size > 1024: raise ValueError("Invalid request size.")
                command = json.loads(self.rfile.read(size).decode("utf-8")).get("command")
                methods = {"play": "try_play_async", "pause": "try_pause_async", "next": "try_skip_next_async", "previous": "try_skip_previous_async"}
                if command not in methods: raise ValueError("Unsupported media command.")
                from winsdk.windows.media.control import GlobalSystemMediaTransportControlsSessionManager
                async def control():
                    manager = await GlobalSystemMediaTransportControlsSessionManager.request_async()
                    session = manager.get_current_session()
                    if session is None: return {"ok": False, "reason": "No active Windows media session."}
                    result = await getattr(session, methods[command])()
                    return {"ok": bool(result)}
                result = asyncio.run(control())
                raw = json.dumps(result).encode("utf-8")
                self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw)
            except ImportError:
                raw = json.dumps({"ok": False, "reason": "Windows media integration is unavailable in this build."}).encode("utf-8")
                self.send_response(501); self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw)
            except Exception as exc:
                raw = json.dumps({"ok": False, "reason": str(exc)}).encode("utf-8")
                self.send_response(400); self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw)
            return
        if self.path not in ("/api/state", "/api/backup"):
            self.send_error(404); return
        host = self.headers.get("Host", "")
        if not (host.startswith("127.0.0.1:") or host == "127.0.0.1"):
            self.send_error(403, "Loopback requests only."); return
        try: size = int(self.headers.get("Content-Length", "0"))
        except ValueError: size = 0
        if size < 2 or size > MAX_BODY:
            self.send_error(413, "Workspace JSON must be between 2 bytes and 8 MB."); return
        try:
            raw = self.rfile.read(size)
            data = json.loads(raw.decode("utf-8"))
            if not isinstance(data, dict) or not isinstance(data.get("schemaVersion"), int):
                raise ValueError("Expected a workspace JSON object with schemaVersion.")
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            self.send_error(400, str(exc)); return
        try:
            BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
            snapshot = BACKUP_DIR / f"omni-go-{stamp}.json"
            snapshot.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            STATE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            # Preserve the portable build's historical API path, while desktop builds
            # report a user-data-relative path outside the packaged application folder.
            try:
                backup_label = str(snapshot.relative_to(ROOT)) if DATA_DIR == (ROOT / "data").resolve() else str(snapshot.relative_to(DATA_DIR))
            except ValueError:
                backup_label = snapshot.name
            response = json.dumps({"ok": True, "backup": backup_label}).encode("utf-8")
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(response))); self.end_headers(); self.wfile.write(response)
        except OSError as exc:
            self.send_error(500, f"Could not write workspace backup: {exc}")

    def end_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        self.send_header("Content-Security-Policy", "default-src 'self' data: blob:; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")
        super().end_headers()

    def log_message(self, fmt, *args):
        sys.stdout.write("[OMNI-GO] " + (fmt % args) + "\n")

if __name__ == "__main__":
    try:
        server = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError as exc:
        print(f"Could not start OMNI-GO on http://{HOST}:{PORT}/: {exc}")
        print("If port 8000 is in use, close the other local server or run set OMNIGO_PORT=8001 before launching.")
        input("Press Enter to close...")
        raise SystemExit(1)
    print("=" * 58)
    print(" OMNI-GO — Personal Command Center")
    print(f" Local URL: http://{HOST}:{PORT}/")
    print(" Bound to 127.0.0.1 only. Keep this window open while using the app.")
    print(" Press Ctrl+C here to stop the local server.")
    print("=" * 58)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping OMNI-GO...")
    finally:
        server.server_close()
